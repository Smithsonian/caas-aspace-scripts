-- MySQL dump 10.13  Distrib 8.0.38, for macos14 (arm64)
--
-- Host: 127.0.0.1    Database: archivesspace
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accession`
--

DROP TABLE IF EXISTS `accession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accession` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `identifier` varchar(255) NOT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `display_string` text,
  `publish` int DEFAULT NULL,
  `content_description` text,
  `condition_description` text,
  `disposition` text,
  `inventory` text,
  `provenance` text,
  `general_note` text,
  `resource_type_id` int DEFAULT NULL,
  `acquisition_type_id` int DEFAULT NULL,
  `accession_date` date DEFAULT NULL,
  `restrictions_apply` int DEFAULT NULL,
  `retention_rule` text,
  `access_restrictions` int DEFAULT NULL,
  `access_restrictions_note` text,
  `use_restrictions` int DEFAULT NULL,
  `use_restrictions_note` text,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accession_unique_identifier` (`repo_id`,`identifier`),
  KEY `resource_type_id` (`resource_type_id`),
  KEY `acquisition_type_id` (`acquisition_type_id`),
  KEY `accession_system_mtime_index` (`system_mtime`),
  KEY `accession_user_mtime_index` (`user_mtime`),
  KEY `accession_suppressed_index` (`suppressed`),
  CONSTRAINT `accession_ibfk_1` FOREIGN KEY (`resource_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `accession_ibfk_2` FOREIGN KEY (`acquisition_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `accession_ibfk_3` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accession`
--

LOCK TABLES `accession` WRITE;
/*!40000 ALTER TABLE `accession` DISABLE KEYS */;
INSERT INTO `accession` VALUES (1,1,1,2,0,'[\"5\",null,null,null]','Test accession 5','Test accession 5',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-07-18',0,NULL,0,NULL,0,NULL,'admin','admin','2026-02-27 23:18:03','2026-03-06 20:48:47','2026-02-27 23:18:03',NULL,1,NULL,NULL),(2,0,1,2,0,'[\"4\",null,null,null]','Test accession 4','Test accession 4',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-07-18',0,NULL,0,NULL,0,NULL,'admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03',NULL,1,NULL,NULL),(3,0,1,2,0,'[\"3\",null,null,null]','Test accession 3','Test accession 3',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-07-18',0,NULL,0,NULL,0,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',NULL,1,NULL,NULL),(4,0,1,2,0,'[\"2\",null,null,null]','Test accession 2','Test accession 2',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-07-18',0,NULL,0,NULL,0,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',NULL,1,NULL,NULL),(5,0,1,2,0,'[\"1\",null,null,null]','Test accession 1','Test accession 1',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-07-18',0,NULL,0,NULL,0,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',NULL,1,NULL,NULL),(6,0,1,2,0,'[\"0\",null,null,null]','Test accession 0','Test accession 0',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-07-18',0,NULL,0,NULL,0,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `accession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accession_component_links_rlshp`
--

DROP TABLE IF EXISTS `accession_component_links_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accession_component_links_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `suppressed` int DEFAULT '0',
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `accession_component_links_rlshp_system_mtime_index` (`system_mtime`),
  KEY `accession_component_links_rlshp_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `archival_object_id` (`archival_object_id`),
  CONSTRAINT `accession_component_links_rlshp_ibfk_1` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `accession_component_links_rlshp_ibfk_2` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accession_component_links_rlshp`
--

LOCK TABLES `accession_component_links_rlshp` WRITE;
/*!40000 ALTER TABLE `accession_component_links_rlshp` DISABLE KEYS */;
/*!40000 ALTER TABLE `accession_component_links_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `active_edit`
--

DROP TABLE IF EXISTS `active_edit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `active_edit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `operator` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `active_edit_timestamp_index` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_edit`
--

LOCK TABLES `active_edit` WRITE;
/*!40000 ALTER TABLE `active_edit` DISABLE KEYS */;
/*!40000 ALTER TABLE `active_edit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_alternate_set`
--

DROP TABLE IF EXISTS `agent_alternate_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_alternate_set` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_version_xlink_actuate_attribute_id` int DEFAULT NULL,
  `file_version_xlink_show_attribute_id` int DEFAULT NULL,
  `set_component` varchar(255) DEFAULT NULL,
  `descriptive_note` text,
  `file_uri` varchar(255) DEFAULT NULL,
  `xlink_title_attribute` varchar(255) DEFAULT NULL,
  `xlink_role_attribute` varchar(255) DEFAULT NULL,
  `xlink_arcrole_attribute` varchar(255) DEFAULT NULL,
  `last_verified_date` datetime DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_alternate_set_system_mtime_index` (`system_mtime`),
  KEY `agent_alternate_set_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_alternate_set_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_alternate_set_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_alternate_set_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_alternate_set_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_alternate_set`
--

LOCK TABLES `agent_alternate_set` WRITE;
/*!40000 ALTER TABLE `agent_alternate_set` DISABLE KEYS */;
INSERT INTO `agent_alternate_set` VALUES (7,925,930,'Set Component 1','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Role Attribute','2025-07-18 00:00:00',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(8,927,931,'Set Component 2','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(9,925,930,'Set Component 1','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Role Attribute','2025-07-18 00:00:00',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(10,927,931,'Set Component 2','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(11,925,930,'Set Component 1','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Role Attribute','2025-07-18 00:00:00',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(12,927,931,'Set Component 2','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_alternate_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_contact`
--

DROP TABLE IF EXISTS `agent_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `name` text NOT NULL,
  `salutation_id` int DEFAULT NULL,
  `address_1` text,
  `address_2` text,
  `address_3` text,
  `city` text,
  `region` text,
  `country` text,
  `post_code` text,
  `email` text,
  `email_signature` text,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `is_representative` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `agent_person_one_representative_contact` (`is_representative`,`agent_person_id`),
  UNIQUE KEY `agent_corporate_entity_one_representative_contact` (`is_representative`,`agent_corporate_entity_id`),
  UNIQUE KEY `agent_family_one_representative_contact` (`is_representative`,`agent_family_id`),
  UNIQUE KEY `agent_software_one_representative_contact` (`is_representative`,`agent_software_id`),
  KEY `salutation_id` (`salutation_id`),
  KEY `agent_contact_system_mtime_index` (`system_mtime`),
  KEY `agent_contact_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_contact_ibfk_1` FOREIGN KEY (`salutation_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `agent_contact_ibfk_2` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_contact_ibfk_3` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_contact_ibfk_4` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_contact_ibfk_5` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_contact`
--

LOCK TABLES `agent_contact` WRITE;
/*!40000 ALTER TABLE `agent_contact` DISABLE KEYS */;
INSERT INTO `agent_contact` VALUES (1,0,1,NULL,NULL,1,NULL,'test_repo_37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03',NULL),(5,0,1,3,NULL,NULL,NULL,'Contact Name',328,'Address 1','Address 2','Address 3','City','State','Country','PostCode','Email',NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL),(6,0,1,NULL,NULL,3,NULL,'Contact Name',328,'Address 1','Address 2','Address 3','City','State','Country','PostCode','Email',NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL),(7,0,1,NULL,2,NULL,NULL,'Contact Name',328,'Address 1','Address 2','Address 3','City','State','Country','PostCode','Email',NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL);
/*!40000 ALTER TABLE `agent_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_conventions_declaration`
--

DROP TABLE IF EXISTS `agent_conventions_declaration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_conventions_declaration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name_rule_id` int DEFAULT NULL,
  `file_version_xlink_actuate_attribute_id` int DEFAULT NULL,
  `file_version_xlink_show_attribute_id` int DEFAULT NULL,
  `citation` varchar(255) DEFAULT NULL,
  `descriptive_note` text NOT NULL,
  `file_uri` varchar(255) DEFAULT NULL,
  `xlink_title_attribute` varchar(255) DEFAULT NULL,
  `xlink_role_attribute` varchar(255) DEFAULT NULL,
  `xlink_arcrole_attribute` varchar(255) DEFAULT NULL,
  `last_verified_date` datetime DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_conventions_declaration_system_mtime_index` (`system_mtime`),
  KEY `agent_conventions_declaration_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_conventions_declaration_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_conventions_declaration_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_conventions_declaration_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_conventions_declaration_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_conventions_declaration`
--

LOCK TABLES `agent_conventions_declaration` WRITE;
/*!40000 ALTER TABLE `agent_conventions_declaration` DISABLE KEYS */;
INSERT INTO `agent_conventions_declaration` VALUES (7,243,925,931,'Citation 1','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(8,241,925,931,'Citation 2','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(9,243,925,931,'Citation 1','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(10,241,925,931,'Citation 2','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(11,243,925,931,'Citation 1','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(12,241,925,931,'Citation 2','Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_conventions_declaration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_corporate_entity`
--

DROP TABLE IF EXISTS `agent_corporate_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_corporate_entity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `publish` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `agent_sha1` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sha1_agent_corporate_entity` (`agent_sha1`),
  KEY `agent_corporate_entity_system_mtime_index` (`system_mtime`),
  KEY `agent_corporate_entity_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_corporate_entity`
--

LOCK TABLES `agent_corporate_entity` WRITE;
/*!40000 ALTER TABLE `agent_corporate_entity` DISABLE KEYS */;
INSERT INTO `agent_corporate_entity` VALUES (1,1,1,0,'admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:08','2026-02-27 23:18:03','c72239b862e4a5de4a33da0e389730f6c6a17dd4',NULL,1),(3,0,1,1,'admin','admin','2026-03-06 20:48:44','2026-03-06 20:48:44','2026-03-06 20:48:44','94126ec45d9faec9a351c9e6287811ec869eae43',NULL,1);
/*!40000 ALTER TABLE `agent_corporate_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_family`
--

DROP TABLE IF EXISTS `agent_family`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_family` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `publish` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `agent_sha1` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sha1_agent_family` (`agent_sha1`),
  KEY `agent_family_system_mtime_index` (`system_mtime`),
  KEY `agent_family_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_family`
--

LOCK TABLES `agent_family` WRITE;
/*!40000 ALTER TABLE `agent_family` DISABLE KEYS */;
INSERT INTO `agent_family` VALUES (2,0,1,1,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46','0eefa24c448679bad21c974f075dcae1053d07aa',NULL,1);
/*!40000 ALTER TABLE `agent_family` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_function`
--

DROP TABLE IF EXISTS `agent_function`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_function` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `suppressed` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_function_system_mtime_index` (`system_mtime`),
  KEY `agent_function_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_function_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_function_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_function_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_function_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_function`
--

LOCK TABLES `agent_function` WRITE;
/*!40000 ALTER TABLE `agent_function` DISABLE KEYS */;
INSERT INTO `agent_function` VALUES (1,3,NULL,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(2,NULL,NULL,3,NULL,1,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(3,NULL,2,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_function` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_gender`
--

DROP TABLE IF EXISTS `agent_gender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_gender` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gender_id` int NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_gender_system_mtime_index` (`system_mtime`),
  KEY `agent_gender_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  CONSTRAINT `agent_gender_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_gender`
--

LOCK TABLES `agent_gender` WRITE;
/*!40000 ALTER TABLE `agent_gender` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_gender` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_identifier`
--

DROP TABLE IF EXISTS `agent_identifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_identifier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier_type_id` int DEFAULT NULL,
  `entity_identifier` varchar(255) NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_identifier_system_mtime_index` (`system_mtime`),
  KEY `agent_identifier_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_identifier_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_identifier_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_identifier_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_identifier_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_identifier`
--

LOCK TABLES `agent_identifier` WRITE;
/*!40000 ALTER TABLE `agent_identifier` DISABLE KEYS */;
INSERT INTO `agent_identifier` VALUES (1,1751,'Entity IDs 1',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(2,1752,'Entity IDs 2',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(3,1751,'Entity IDs 1',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(4,1752,'Entity IDs 2',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(5,1751,'Entity IDs 1',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(6,1752,'Entity IDs 2',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_identifier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_maintenance_history`
--

DROP TABLE IF EXISTS `agent_maintenance_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_maintenance_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maintenance_event_type_id` int NOT NULL,
  `maintenance_agent_type_id` int NOT NULL,
  `event_date` datetime NOT NULL,
  `agent` varchar(255) NOT NULL,
  `descriptive_note` text NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_maintenance_history_system_mtime_index` (`system_mtime`),
  KEY `agent_maintenance_history_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_maintenance_history_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_maintenance_history_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_maintenance_history_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_maintenance_history_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `agent_maintenance_history_ibfk_5` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_maintenance_history_ibfk_6` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_maintenance_history_ibfk_7` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_maintenance_history_ibfk_8` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_maintenance_history`
--

LOCK TABLES `agent_maintenance_history` WRITE;
/*!40000 ALTER TABLE `agent_maintenance_history` DISABLE KEYS */;
INSERT INTO `agent_maintenance_history` VALUES (7,1757,1763,'2025-07-18 00:00:00','Agent','Descriptive Note',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(8,1758,1764,'2025-07-18 00:00:00','Agent','Descriptive Note',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(9,1757,1763,'2025-07-18 00:00:00','Agent','Descriptive Note',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(10,1758,1764,'2025-07-18 00:00:00','Agent','Descriptive Note',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(11,1757,1763,'2025-07-18 00:00:00','Agent','Descriptive Note',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(12,1758,1764,'2025-07-18 00:00:00','Agent','Descriptive Note',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_maintenance_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_occupation`
--

DROP TABLE IF EXISTS `agent_occupation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_occupation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `suppressed` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_occupation_system_mtime_index` (`system_mtime`),
  KEY `agent_occupation_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_occupation_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_occupation_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_occupation_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_occupation_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_occupation`
--

LOCK TABLES `agent_occupation` WRITE;
/*!40000 ALTER TABLE `agent_occupation` DISABLE KEYS */;
INSERT INTO `agent_occupation` VALUES (1,3,NULL,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(2,NULL,NULL,3,NULL,1,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(3,NULL,2,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_occupation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_other_agency_codes`
--

DROP TABLE IF EXISTS `agent_other_agency_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_other_agency_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agency_code_type_id` int DEFAULT NULL,
  `maintenance_agency` varchar(255) NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_other_agency_codes_system_mtime_index` (`system_mtime`),
  KEY `agent_other_agency_codes_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_other_agency_codes_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_other_agency_codes_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_other_agency_codes_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_other_agency_codes_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_other_agency_codes`
--

LOCK TABLES `agent_other_agency_codes` WRITE;
/*!40000 ALTER TABLE `agent_other_agency_codes` DISABLE KEYS */;
INSERT INTO `agent_other_agency_codes` VALUES (7,NULL,'Maintenance Agency 1',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(8,1755,'Maintenance Agency 2',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(9,NULL,'Maintenance Agency 1',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(10,1755,'Maintenance Agency 2',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(11,NULL,'Maintenance Agency 1',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(12,1755,'Maintenance Agency 2',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_other_agency_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_person`
--

DROP TABLE IF EXISTS `agent_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_person` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `publish` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `agent_sha1` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sha1_agent_person` (`agent_sha1`),
  KEY `agent_person_system_mtime_index` (`system_mtime`),
  KEY `agent_person_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_person`
--

LOCK TABLES `agent_person` WRITE;
/*!40000 ALTER TABLE `agent_person` DISABLE KEYS */;
INSERT INTO `agent_person` VALUES (1,12,1,0,NULL,NULL,'2026-02-27 23:17:23','2026-03-06 20:48:47','2026-02-27 23:17:23','c60b72ce75b19b6cb4589799376f97a7',NULL,1),(3,0,1,1,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43','60c55846dba04343df9f2eb6d44852177d5040ae',NULL,1);
/*!40000 ALTER TABLE `agent_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_place`
--

DROP TABLE IF EXISTS `agent_place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_place` (
  `id` int NOT NULL AUTO_INCREMENT,
  `place_role_id` int DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `suppressed` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_place_system_mtime_index` (`system_mtime`),
  KEY `agent_place_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_place_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_place_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_place_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_place_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_place`
--

LOCK TABLES `agent_place` WRITE;
/*!40000 ALTER TABLE `agent_place` DISABLE KEYS */;
INSERT INTO `agent_place` VALUES (4,1778,3,NULL,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(5,1778,NULL,NULL,3,NULL,1,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(6,1778,NULL,2,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_place` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_record_control`
--

DROP TABLE IF EXISTS `agent_record_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_record_control` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maintenance_status_id` int NOT NULL,
  `publication_status_id` int DEFAULT NULL,
  `government_agency_type_id` int DEFAULT NULL,
  `reference_evaluation_id` int DEFAULT NULL,
  `name_type_id` int DEFAULT NULL,
  `level_of_detail_id` int DEFAULT NULL,
  `modified_record_id` int DEFAULT NULL,
  `cataloging_source_id` int DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `romanization_id` int DEFAULT NULL,
  `maintenance_agency` varchar(255) DEFAULT NULL,
  `agency_name` varchar(255) DEFAULT NULL,
  `maintenance_agency_note` text,
  `language_note` text,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_record_control_system_mtime_index` (`system_mtime`),
  KEY `agent_record_control_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_record_control_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_record_control_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_record_control_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_record_control_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_record_control`
--

LOCK TABLES `agent_record_control` WRITE;
/*!40000 ALTER TABLE `agent_record_control` DISABLE KEYS */;
INSERT INTO `agent_record_control` VALUES (4,1699,1706,1725,1729,1732,1736,1742,1746,515,1582,1707,'DLC','Agency Name','Maintenance Agency Note','Language Note',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(5,1699,1706,1725,1729,1732,1736,1742,1746,515,1582,1707,'DLC','Agency Name','Maintenance Agency Note','Language Note',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(6,1699,1706,1725,1729,1732,1736,1742,1746,515,1582,1707,'DLC','Agency Name','Maintenance Agency Note','Language Note',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_record_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_record_identifier`
--

DROP TABLE IF EXISTS `agent_record_identifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_record_identifier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identifier_type_id` int DEFAULT NULL,
  `source_id` int NOT NULL,
  `primary_identifier` int NOT NULL,
  `record_identifier` varchar(255) NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_record_identifier_system_mtime_index` (`system_mtime`),
  KEY `agent_record_identifier_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_record_identifier`
--

LOCK TABLES `agent_record_identifier` WRITE;
/*!40000 ALTER TABLE `agent_record_identifier` DISABLE KEYS */;
INSERT INTO `agent_record_identifier` VALUES (7,1751,237,1,'n  12345',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(8,1754,236,0,'l 12345',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(9,1751,237,1,'n  6789',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(10,1754,236,0,'l 6789',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(11,1751,237,1,'n  6789',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(12,1754,236,0,'l 6789',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_record_identifier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_resource`
--

DROP TABLE IF EXISTS `agent_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_resource` (
  `id` int NOT NULL AUTO_INCREMENT,
  `linked_agent_role_id` int NOT NULL,
  `linked_resource` varchar(8704) NOT NULL,
  `linked_resource_description` text,
  `file_uri` varchar(255) DEFAULT NULL,
  `file_version_xlink_actuate_attribute_id` int DEFAULT NULL,
  `file_version_xlink_show_attribute_id` int DEFAULT NULL,
  `xlink_title_attribute` varchar(255) DEFAULT NULL,
  `xlink_role_attribute` varchar(255) DEFAULT NULL,
  `xlink_arcrole_attribute` varchar(255) DEFAULT NULL,
  `last_verified_date` datetime DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `suppressed` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_resource_system_mtime_index` (`system_mtime`),
  KEY `agent_resource_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_resource_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_resource_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_resource_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_resource_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_resource`
--

LOCK TABLES `agent_resource` WRITE;
/*!40000 ALTER TABLE `agent_resource` DISABLE KEYS */;
INSERT INTO `agent_resource` VALUES (1,878,'Related External Resource 1','Description','File URI',925,931,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',3,NULL,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(2,879,'Related External Resource 2','Description','File URI',925,931,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',3,NULL,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(3,878,'Related External Resource 1','Description','File URI',925,931,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,NULL,3,NULL,1,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(4,879,'Related External Resource 2','Description','File URI',925,931,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,NULL,3,NULL,1,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(5,878,'Related External Resource 1','Description','File URI',925,931,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,2,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(6,879,'Related External Resource 2','Description','File URI',925,931,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,2,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_software`
--

DROP TABLE IF EXISTS `agent_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_software` (
  `id` int NOT NULL AUTO_INCREMENT,
  `system_role` varchar(255) NOT NULL DEFAULT 'none',
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `publish` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `agent_sha1` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sha1_agent_software` (`agent_sha1`),
  KEY `agent_software_system_role_index` (`system_role`),
  KEY `agent_software_system_mtime_index` (`system_mtime`),
  KEY `agent_software_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_software`
--

LOCK TABLES `agent_software` WRITE;
/*!40000 ALTER TABLE `agent_software` DISABLE KEYS */;
INSERT INTO `agent_software` VALUES (1,'archivesspace_agent',1,1,0,NULL,NULL,'2026-02-27 23:17:22','2026-03-06 20:48:47','2026-02-27 23:17:22','a372372cdb17730c806c1fb7f511074f69056e3a',NULL,1);
/*!40000 ALTER TABLE `agent_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_sources`
--

DROP TABLE IF EXISTS `agent_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_sources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `source_entry` varchar(255) DEFAULT NULL,
  `descriptive_note` text,
  `file_uri` varchar(255) DEFAULT NULL,
  `file_version_xlink_actuate_attribute_id` int DEFAULT NULL,
  `file_version_xlink_show_attribute_id` int DEFAULT NULL,
  `xlink_title_attribute` varchar(255) DEFAULT NULL,
  `xlink_role_attribute` varchar(255) DEFAULT NULL,
  `xlink_arcrole_attribute` varchar(255) DEFAULT NULL,
  `last_verified_date` datetime DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_sources_system_mtime_index` (`system_mtime`),
  KEY `agent_sources_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_sources_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_sources_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_sources_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_sources_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_sources`
--

LOCK TABLES `agent_sources` WRITE;
/*!40000 ALTER TABLE `agent_sources` DISABLE KEYS */;
INSERT INTO `agent_sources` VALUES (7,'Source Entry 1','Descriptive Note','File URI',928,933,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(8,'Source Entry 2','Descriptive Note','File URI',926,932,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(9,'Source Entry 1','Descriptive Note','File URI',928,933,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(10,'Source Entry 2','Descriptive Note','File URI',926,932,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(11,'Source Entry 1','Descriptive Note','File URI',928,933,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(12,'Source Entry 2','Descriptive Note','File URI',926,932,'Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00',NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_topic`
--

DROP TABLE IF EXISTS `agent_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_topic` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `suppressed` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_topic_system_mtime_index` (`system_mtime`),
  KEY `agent_topic_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `agent_topic_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `agent_topic_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `agent_topic_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `agent_topic_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_topic`
--

LOCK TABLES `agent_topic` WRITE;
/*!40000 ALTER TABLE `agent_topic` DISABLE KEYS */;
INSERT INTO `agent_topic` VALUES (1,3,NULL,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(2,NULL,NULL,3,NULL,1,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(3,NULL,2,NULL,NULL,1,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `agent_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `archival_object`
--

DROP TABLE IF EXISTS `archival_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `archival_object` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `root_record_id` int DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `parent_name` varchar(255) DEFAULT NULL,
  `position` int NOT NULL,
  `publish` int NOT NULL DEFAULT '0',
  `ref_id` varchar(255) NOT NULL,
  `component_id` varchar(255) DEFAULT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `display_string` text,
  `level_id` int NOT NULL,
  `other_level` varchar(255) DEFAULT NULL,
  `system_generated` int DEFAULT '0',
  `restrictions_apply` int DEFAULT NULL,
  `repository_processing_note` text,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ao_unique_refid` (`root_record_id`,`ref_id`),
  UNIQUE KEY `uniq_ao_pos` (`parent_name`,`position`),
  KEY `level_id` (`level_id`),
  KEY `archival_object_system_mtime_index` (`system_mtime`),
  KEY `archival_object_user_mtime_index` (`user_mtime`),
  KEY `repo_id` (`repo_id`),
  KEY `ao_parent_root_idx` (`parent_id`,`root_record_id`),
  KEY `archival_object_ref_id_index` (`ref_id`),
  KEY `archival_object_component_id_index` (`component_id`),
  CONSTRAINT `archival_object_ibfk_1` FOREIGN KEY (`level_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `archival_object_ibfk_3` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`),
  CONSTRAINT `archival_object_ibfk_4` FOREIGN KEY (`root_record_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `archival_object_ibfk_5` FOREIGN KEY (`parent_id`) REFERENCES `archival_object` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archival_object`
--

LOCK TABLES `archival_object` WRITE;
/*!40000 ALTER TABLE `archival_object` DISABLE KEYS */;
INSERT INTO `archival_object` VALUES (1,0,1,2,5,NULL,'root@/repositories/2/resources/5',1000,0,'EAD.0_ref1',NULL,'Test AO 10','Test AO 10',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05',0,NULL,1),(2,0,1,2,5,NULL,'root@/repositories/2/resources/5',2000,0,'EAD.0_ref2',NULL,'Test AO 9','Test AO 9',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05',0,NULL,1),(3,0,1,2,5,NULL,'root@/repositories/2/resources/5',3000,0,'EAD.0_ref3',NULL,'Test AO 8','Test AO 8',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05',0,NULL,1),(4,0,1,2,5,NULL,'root@/repositories/2/resources/5',4000,0,'EAD.0_ref4',NULL,'Test AO 7','Test AO 7',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:06','2026-02-27 23:18:06','2026-02-27 23:18:06',0,NULL,1),(5,0,1,2,5,NULL,'root@/repositories/2/resources/5',5000,0,'EAD.0_ref5',NULL,'Test AO 6','Test AO 6',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:06','2026-02-27 23:18:06','2026-02-27 23:18:06',0,NULL,1),(6,0,1,2,5,NULL,'root@/repositories/2/resources/5',6000,0,'EAD.0_ref6',NULL,'Test AO 5','Test AO 5',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:06','2026-02-27 23:18:06','2026-02-27 23:18:06',0,NULL,1),(7,0,1,2,5,NULL,'root@/repositories/2/resources/5',7000,0,'EAD.0_ref7',NULL,'Test AO 4','Test AO 4',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:06','2026-02-27 23:18:06','2026-02-27 23:18:06',0,NULL,1),(8,0,1,2,5,NULL,'root@/repositories/2/resources/5',8000,0,'EAD.0_ref8',NULL,'Test AO 3','Test AO 3',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:06','2026-02-27 23:18:06','2026-02-27 23:18:06',0,NULL,1),(9,0,1,2,5,NULL,'root@/repositories/2/resources/5',9000,0,'EAD.0_ref9',NULL,'Test AO 2','Test AO 2',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:06','2026-02-27 23:18:06','2026-02-27 23:18:06',0,NULL,1),(10,0,1,2,5,NULL,'root@/repositories/2/resources/5',10000,0,'EAD.0_ref10',NULL,'Test AO 1','Test AO 1',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',0,NULL,1),(11,0,1,2,5,NULL,'root@/repositories/2/resources/5',11000,0,'EAD.0_ref11',NULL,'Test AO 0','Test AO 0',890,NULL,0,0,NULL,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',0,NULL,1);
/*!40000 ALTER TABLE `archival_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ark_name`
--

DROP TABLE IF EXISTS `ark_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ark_name` (
  `id` int NOT NULL AUTO_INCREMENT,
  `archival_object_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `system_mtime` datetime DEFAULT NULL,
  `user_mtime` datetime DEFAULT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  `ark_value` varchar(255) NOT NULL,
  `is_current` int NOT NULL DEFAULT '0',
  `is_external_url` int DEFAULT '0',
  `retired_at_epoch_ms` bigint NOT NULL DEFAULT '0',
  `version_key` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ark_name_ao_uniq` (`archival_object_id`,`is_current`,`retired_at_epoch_ms`),
  UNIQUE KEY `ark_name_resource_uniq` (`resource_id`,`is_current`,`retired_at_epoch_ms`),
  KEY `ark_name_archival_object_id_index` (`archival_object_id`),
  KEY `ark_name_resource_id_index` (`resource_id`),
  KEY `ark_name_ark_value_res_idx` (`ark_value`,`resource_id`),
  KEY `ark_name_ark_value_ao_idx` (`ark_value`,`archival_object_id`),
  CONSTRAINT `ark_name_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `ark_name_ibfk_2` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ark_name`
--

LOCK TABLES `ark_name` WRITE;
/*!40000 ALTER TABLE `ark_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `ark_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ark_uniq_check`
--

DROP TABLE IF EXISTS `ark_uniq_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ark_uniq_check` (
  `id` int NOT NULL AUTO_INCREMENT,
  `record_uri` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_ark_value` (`value`),
  KEY `record_uri_uniq_check_idx` (`record_uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ark_uniq_check`
--

LOCK TABLES `ark_uniq_check` WRITE;
/*!40000 ALTER TABLE `ark_uniq_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `ark_uniq_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment`
--

DROP TABLE IF EXISTS `assessment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `accession_report` int NOT NULL DEFAULT '0',
  `appraisal` int NOT NULL DEFAULT '0',
  `container_list` int NOT NULL DEFAULT '0',
  `catalog_record` int NOT NULL DEFAULT '0',
  `control_file` int NOT NULL DEFAULT '0',
  `finding_aid_ead` int NOT NULL DEFAULT '0',
  `finding_aid_paper` int NOT NULL DEFAULT '0',
  `finding_aid_word` int NOT NULL DEFAULT '0',
  `finding_aid_spreadsheet` int NOT NULL DEFAULT '0',
  `surveyed_duration` varchar(255) DEFAULT NULL,
  `surveyed_extent` text,
  `review_required` int NOT NULL DEFAULT '0',
  `purpose` text,
  `scope` text,
  `sensitive_material` int NOT NULL DEFAULT '0',
  `general_assessment_note` text,
  `special_format_note` text,
  `exhibition_value_note` text,
  `deed_of_gift` int DEFAULT NULL,
  `finding_aid_online` int DEFAULT NULL,
  `related_eac_records` int DEFAULT NULL,
  `existing_description_notes` text,
  `survey_begin` date NOT NULL DEFAULT '1970-01-01',
  `survey_end` date DEFAULT NULL,
  `review_note` text,
  `inactive` int DEFAULT NULL,
  `monetary_value` decimal(16,2) DEFAULT NULL,
  `monetary_value_note` text,
  `conservation_note` text,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assessment_system_mtime_index` (`system_mtime`),
  KEY `assessment_user_mtime_index` (`user_mtime`),
  KEY `repo_id` (`repo_id`),
  CONSTRAINT `assessment_ibfk_1` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment`
--

LOCK TABLES `assessment` WRITE;
/*!40000 ALTER TABLE `assessment` DISABLE KEYS */;
INSERT INTO `assessment` VALUES (1,0,1,2,0,0,1,0,0,0,1,0,1,'Time it took to Complete Survey','Extent Surveyed',1,'Purpose of Assessment','Scope of Assessment',0,'General Assessment Note','Special Format Note','Exhibition Value Note',0,0,1,'Existing Description Notes','2020-01-07','2020-01-07','Review Note',0,1.00,'Monetary Value Note','Conservation Note','admin','admin','2026-02-27 23:18:09','2026-02-27 23:18:09','2026-02-27 23:18:09');
/*!40000 ALTER TABLE `assessment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_attribute`
--

DROP TABLE IF EXISTS `assessment_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_attribute` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assessment_id` int NOT NULL,
  `assessment_attribute_definition_id` int NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `assessment_attribute_definition_id` (`assessment_attribute_definition_id`),
  CONSTRAINT `assessment_attribute_ibfk_1` FOREIGN KEY (`assessment_id`) REFERENCES `assessment` (`id`),
  CONSTRAINT `assessment_attribute_ibfk_2` FOREIGN KEY (`assessment_attribute_definition_id`) REFERENCES `assessment_attribute_definition` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_attribute`
--

LOCK TABLES `assessment_attribute` WRITE;
/*!40000 ALTER TABLE `assessment_attribute` DISABLE KEYS */;
INSERT INTO `assessment_attribute` VALUES (1,1,9,'true'),(2,1,10,'true'),(3,1,11,'false'),(4,1,12,'false'),(5,1,13,'true'),(6,1,14,'false'),(7,1,15,'false'),(8,1,16,'true'),(9,1,17,'true'),(10,1,18,'true'),(11,1,19,'true'),(12,1,20,'true'),(13,1,21,'true'),(14,1,22,'false'),(15,1,23,'true'),(16,1,24,'false'),(17,1,25,'true'),(18,1,26,'false'),(19,1,27,'true'),(20,1,28,'true'),(21,1,29,'false'),(22,1,30,'true'),(23,1,31,'false'),(24,1,32,'false'),(25,1,33,'false');
/*!40000 ALTER TABLE `assessment_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_attribute_definition`
--

DROP TABLE IF EXISTS `assessment_attribute_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_attribute_definition` (
  `id` int NOT NULL AUTO_INCREMENT,
  `repo_id` int NOT NULL,
  `label` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `position` int NOT NULL,
  `readonly` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assessment_attr_unique_label` (`repo_id`,`type`,`label`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_attribute_definition`
--

LOCK TABLES `assessment_attribute_definition` WRITE;
/*!40000 ALTER TABLE `assessment_attribute_definition` DISABLE KEYS */;
INSERT INTO `assessment_attribute_definition` VALUES (1,1,'Reformatting Readiness','rating',0,0),(2,1,'Housing Quality','rating',1,0),(3,1,'Physical Condition','rating',2,0),(4,1,'Physical Access (arrangement)','rating',3,0),(5,1,'Intellectual Access (description)','rating',4,0),(6,1,'Interest','rating',5,0),(7,1,'Documentation Quality','rating',6,0),(8,1,'Research Value','rating',7,1),(9,1,'Architectural Materials','format',7,0),(10,1,'Art Originals','format',8,0),(11,1,'Artifacts','format',9,0),(12,1,'Audio Materials','format',10,0),(13,1,'Biological Specimens','format',11,0),(14,1,'Botanical Specimens','format',12,0),(15,1,'Computer Storage Units','format',13,0),(16,1,'Film (negative, slide, or motion picture)','format',14,0),(17,1,'Glass','format',15,0),(18,1,'Photographs','format',16,0),(19,1,'Scrapbooks','format',17,0),(20,1,'Technical Drawings & Schematics','format',18,0),(21,1,'Textiles','format',19,0),(22,1,'Vellum & Parchment','format',20,0),(23,1,'Video Materials','format',21,0),(24,1,'Other','format',22,0),(25,1,'Potential Mold or Mold Damage','conservation_issue',23,0),(26,1,'Recent Pest Damage','conservation_issue',24,0),(27,1,'Deteriorating Film Base','conservation_issue',25,0),(28,1,'Brittle Paper','conservation_issue',26,0),(29,1,'Metal Fasteners','conservation_issue',27,0),(30,1,'Newspaper','conservation_issue',28,0),(31,1,'Tape','conservation_issue',29,0),(32,1,'Heat-Sensitive Paper','conservation_issue',30,0),(33,1,'Water Damage','conservation_issue',31,0);
/*!40000 ALTER TABLE `assessment_attribute_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_attribute_note`
--

DROP TABLE IF EXISTS `assessment_attribute_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_attribute_note` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assessment_id` int NOT NULL,
  `assessment_attribute_definition_id` int NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assessment_id` (`assessment_id`),
  KEY `assessment_attribute_definition_id` (`assessment_attribute_definition_id`),
  CONSTRAINT `assessment_attribute_note_ibfk_1` FOREIGN KEY (`assessment_id`) REFERENCES `assessment` (`id`),
  CONSTRAINT `assessment_attribute_note_ibfk_2` FOREIGN KEY (`assessment_attribute_definition_id`) REFERENCES `assessment_attribute_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_attribute_note`
--

LOCK TABLES `assessment_attribute_note` WRITE;
/*!40000 ALTER TABLE `assessment_attribute_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_attribute_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_reviewer_rlshp`
--

DROP TABLE IF EXISTS `assessment_reviewer_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_reviewer_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assessment_id` int NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assessment_reviewer_rlshp_system_mtime_index` (`system_mtime`),
  KEY `assessment_reviewer_rlshp_user_mtime_index` (`user_mtime`),
  KEY `assessment_id` (`assessment_id`),
  KEY `agent_person_id` (`agent_person_id`),
  CONSTRAINT `assessment_reviewer_rlshp_ibfk_1` FOREIGN KEY (`assessment_id`) REFERENCES `assessment` (`id`),
  CONSTRAINT `assessment_reviewer_rlshp_ibfk_2` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_reviewer_rlshp`
--

LOCK TABLES `assessment_reviewer_rlshp` WRITE;
/*!40000 ALTER TABLE `assessment_reviewer_rlshp` DISABLE KEYS */;
INSERT INTO `assessment_reviewer_rlshp` VALUES (1,1,1,0,0,NULL,NULL,'2026-02-27 23:18:09','2026-02-27 23:18:09');
/*!40000 ALTER TABLE `assessment_reviewer_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_rlshp`
--

DROP TABLE IF EXISTS `assessment_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assessment_id` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assessment_rlshp_system_mtime_index` (`system_mtime`),
  KEY `assessment_rlshp_user_mtime_index` (`user_mtime`),
  KEY `assessment_id` (`assessment_id`),
  KEY `accession_id` (`accession_id`),
  KEY `resource_id` (`resource_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `digital_object_id` (`digital_object_id`),
  CONSTRAINT `assessment_rlshp_ibfk_1` FOREIGN KEY (`assessment_id`) REFERENCES `assessment` (`id`),
  CONSTRAINT `assessment_rlshp_ibfk_2` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `assessment_rlshp_ibfk_3` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `assessment_rlshp_ibfk_4` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `assessment_rlshp_ibfk_5` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_rlshp`
--

LOCK TABLES `assessment_rlshp` WRITE;
/*!40000 ALTER TABLE `assessment_rlshp` DISABLE KEYS */;
INSERT INTO `assessment_rlshp` VALUES (1,1,NULL,4,NULL,NULL,0,0,NULL,NULL,'2026-02-27 23:18:09','2026-02-27 23:18:09');
/*!40000 ALTER TABLE `assessment_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_db`
--

DROP TABLE IF EXISTS `auth_db`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_db` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `pwhash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `auth_db_system_mtime_index` (`system_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_db`
--

LOCK TABLES `auth_db` WRITE;
/*!40000 ALTER TABLE `auth_db` DISABLE KEYS */;
INSERT INTO `auth_db` VALUES (1,'admin','2026-02-27 23:17:23','2026-02-27 23:17:23','$2a$10$TzOqvx5/vhV95CANEHSpUOJnaM7.sOSss3CJqPzJnfxUTUe7HeeAW'),(2,'search_indexer','2026-02-27 23:17:24','2026-03-09 13:05:07','$2a$10$GnXV4l24PSXPEG4PKNNj2ObS3JkpQwGBH/Pk5nbjCoqHESszOKn5i'),(4,'public_anonymous','2026-02-27 23:17:24','2026-03-09 13:05:07','$2a$10$F831Og16iwda5Fc0jwEZoeGzx9IoEJMFhB6hGqsCMJiRWVi9U.bNq'),(6,'staff_system','2026-02-27 23:17:24','2026-03-09 13:05:07','$2a$10$OoMf.yC2vchudJ5g2PuA4.U1qxSy8JstAY6X./KUvRKXypVID2Rj6');
/*!40000 ALTER TABLE `auth_db` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caas_aspace_refid`
--

DROP TABLE IF EXISTS `caas_aspace_refid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `caas_aspace_refid` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `resource_id` int DEFAULT NULL,
  `next_refid` int NOT NULL DEFAULT '1',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `caas_aspace_refid_system_mtime_index` (`system_mtime`),
  KEY `caas_aspace_refid_user_mtime_index` (`user_mtime`),
  KEY `resource_id` (`resource_id`),
  CONSTRAINT `caas_aspace_refid_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caas_aspace_refid`
--

LOCK TABLES `caas_aspace_refid` WRITE;
/*!40000 ALTER TABLE `caas_aspace_refid` DISABLE KEYS */;
INSERT INTO `caas_aspace_refid` VALUES (1,20,1,5,12,NULL,NULL,'2026-02-27 23:18:05','2026-02-27 23:18:07','2026-02-27 23:18:07');
/*!40000 ALTER TABLE `caas_aspace_refid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caas_aspace_refid_schema_info`
--

DROP TABLE IF EXISTS `caas_aspace_refid_schema_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `caas_aspace_refid_schema_info` (
  `version` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caas_aspace_refid_schema_info`
--

LOCK TABLES `caas_aspace_refid_schema_info` WRITE;
/*!40000 ALTER TABLE `caas_aspace_refid_schema_info` DISABLE KEYS */;
INSERT INTO `caas_aspace_refid_schema_info` VALUES (2);
/*!40000 ALTER TABLE `caas_aspace_refid_schema_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classification`
--

DROP TABLE IF EXISTS `classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `repo_id` int NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `title` varchar(8704) NOT NULL,
  `description` text,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `publish` int DEFAULT '1',
  `suppressed` int DEFAULT '0',
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classification_system_mtime_index` (`system_mtime`),
  KEY `classification_user_mtime_index` (`user_mtime`),
  KEY `repo_id` (`repo_id`),
  CONSTRAINT `classification_ibfk_1` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classification`
--

LOCK TABLES `classification` WRITE;
/*!40000 ALTER TABLE `classification` DISABLE KEYS */;
INSERT INTO `classification` VALUES (1,2,1,1,'309','Test Classification 0',NULL,'admin','admin','2026-02-27 23:18:07','2026-03-06 20:48:47','2026-02-27 23:18:07',1,0,NULL,1);
/*!40000 ALTER TABLE `classification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classification_creator_rlshp`
--

DROP TABLE IF EXISTS `classification_creator_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification_creator_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_person_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `classification_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classification_creator_rlshp_system_mtime_index` (`system_mtime`),
  KEY `classification_creator_rlshp_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  KEY `classification_id` (`classification_id`),
  CONSTRAINT `classification_creator_rlshp_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `classification_creator_rlshp_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `classification_creator_rlshp_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `classification_creator_rlshp_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `classification_creator_rlshp_ibfk_5` FOREIGN KEY (`classification_id`) REFERENCES `classification` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classification_creator_rlshp`
--

LOCK TABLES `classification_creator_rlshp` WRITE;
/*!40000 ALTER TABLE `classification_creator_rlshp` DISABLE KEYS */;
INSERT INTO `classification_creator_rlshp` VALUES (1,1,NULL,NULL,NULL,1,0,NULL,NULL,'2026-02-27 23:18:07','2026-02-27 23:18:07',0);
/*!40000 ALTER TABLE `classification_creator_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classification_rlshp`
--

DROP TABLE IF EXISTS `classification_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `resource_id` int DEFAULT NULL,
  `accession_id` int DEFAULT NULL,
  `classification_id` int DEFAULT NULL,
  `classification_term_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `digital_object_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classification_rlshp_system_mtime_index` (`system_mtime`),
  KEY `classification_rlshp_user_mtime_index` (`user_mtime`),
  KEY `resource_id` (`resource_id`),
  KEY `accession_id` (`accession_id`),
  KEY `classification_id` (`classification_id`),
  KEY `classification_term_id` (`classification_term_id`),
  CONSTRAINT `classification_rlshp_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `classification_rlshp_ibfk_2` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `classification_rlshp_ibfk_3` FOREIGN KEY (`classification_id`) REFERENCES `classification` (`id`),
  CONSTRAINT `classification_rlshp_ibfk_4` FOREIGN KEY (`classification_term_id`) REFERENCES `classification_term` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classification_rlshp`
--

LOCK TABLES `classification_rlshp` WRITE;
/*!40000 ALTER TABLE `classification_rlshp` DISABLE KEYS */;
INSERT INTO `classification_rlshp` VALUES (1,7,NULL,1,NULL,0,NULL,NULL,'2026-03-06 20:48:47','2026-03-06 20:48:47',0,NULL);
/*!40000 ALTER TABLE `classification_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classification_term`
--

DROP TABLE IF EXISTS `classification_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification_term` (
  `id` int NOT NULL AUTO_INCREMENT,
  `repo_id` int NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `title` varchar(8704) NOT NULL,
  `title_sha1` varchar(255) NOT NULL,
  `description` text,
  `root_record_id` int DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `parent_name` varchar(255) DEFAULT NULL,
  `position` int NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `publish` int DEFAULT '1',
  `suppressed` int DEFAULT '0',
  `display_string` text NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `classification_term_parent_name_title_sha1_index` (`parent_name`,`title_sha1`),
  UNIQUE KEY `classification_term_parent_name_identifier_index` (`parent_name`,`identifier`),
  UNIQUE KEY `uniq_ct_pos` (`parent_name`,`position`),
  KEY `classification_term_system_mtime_index` (`system_mtime`),
  KEY `classification_term_user_mtime_index` (`user_mtime`),
  KEY `repo_id` (`repo_id`),
  CONSTRAINT `classification_term_ibfk_1` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classification_term`
--

LOCK TABLES `classification_term` WRITE;
/*!40000 ALTER TABLE `classification_term` DISABLE KEYS */;
/*!40000 ALTER TABLE `classification_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classification_term_creator_rlshp`
--

DROP TABLE IF EXISTS `classification_term_creator_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classification_term_creator_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_person_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `classification_term_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classification_term_creator_rlshp_system_mtime_index` (`system_mtime`),
  KEY `classification_term_creator_rlshp_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  KEY `classification_term_id` (`classification_term_id`),
  CONSTRAINT `classification_term_creator_rlshp_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `classification_term_creator_rlshp_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `classification_term_creator_rlshp_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `classification_term_creator_rlshp_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `classification_term_creator_rlshp_ibfk_5` FOREIGN KEY (`classification_term_id`) REFERENCES `classification_term` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classification_term_creator_rlshp`
--

LOCK TABLES `classification_term_creator_rlshp` WRITE;
/*!40000 ALTER TABLE `classification_term_creator_rlshp` DISABLE KEYS */;
/*!40000 ALTER TABLE `classification_term_creator_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collection_management`
--

DROP TABLE IF EXISTS `collection_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collection_management` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `processing_hours_per_foot_estimate` varchar(255) DEFAULT NULL,
  `processing_total_extent` varchar(255) DEFAULT NULL,
  `processing_total_extent_type_id` int DEFAULT NULL,
  `processing_hours_total` varchar(255) DEFAULT NULL,
  `processing_plan` text,
  `processing_priority_id` int DEFAULT NULL,
  `processing_status_id` int DEFAULT NULL,
  `processing_funding_source` text,
  `processors` text,
  `rights_determined` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `processing_total_extent_type_id` (`processing_total_extent_type_id`),
  KEY `processing_priority_id` (`processing_priority_id`),
  KEY `processing_status_id` (`processing_status_id`),
  KEY `collection_management_system_mtime_index` (`system_mtime`),
  KEY `collection_management_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `resource_id` (`resource_id`),
  KEY `digital_object_id` (`digital_object_id`),
  CONSTRAINT `collection_management_ibfk_1` FOREIGN KEY (`processing_total_extent_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `collection_management_ibfk_2` FOREIGN KEY (`processing_priority_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `collection_management_ibfk_3` FOREIGN KEY (`processing_status_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `collection_management_ibfk_4` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `collection_management_ibfk_5` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `collection_management_ibfk_6` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collection_management`
--

LOCK TABLES `collection_management` WRITE;
/*!40000 ALTER TABLE `collection_management` DISABLE KEYS */;
INSERT INTO `collection_management` VALUES (2,0,1,NULL,7,NULL,'230','980',274,'122','Processing Plan',252,256,'Funding Source','Processors',1,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47');
/*!40000 ALTER TABLE `collection_management` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `container_profile`
--

DROP TABLE IF EXISTS `container_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `container_profile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `extent_dimension` varchar(255) DEFAULT NULL,
  `dimension_units_id` int DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `depth` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `stacking_limit` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `container_profile_name_uniq` (`name`),
  KEY `dimension_units_id` (`dimension_units_id`),
  KEY `container_profile_system_mtime_index` (`system_mtime`),
  KEY `container_profile_user_mtime_index` (`user_mtime`),
  CONSTRAINT `container_profile_ibfk_1` FOREIGN KEY (`dimension_units_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `container_profile`
--

LOCK TABLES `container_profile` WRITE;
/*!40000 ALTER TABLE `container_profile` DISABLE KEYS */;
INSERT INTO `container_profile` VALUES (1,0,'Profile 4',NULL,'width',1350,'1.4','2.4','3.4','admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',NULL,NULL),(2,0,'Profile 3',NULL,'width',1350,'1.3','2.3','3.3','admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',NULL,NULL),(3,0,'Profile 2',NULL,'width',1350,'1.2','2.2','3.2','admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08',NULL,NULL),(4,0,'Profile 1',NULL,'width',1350,'1.1','2.1','3.1','admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08',NULL,NULL),(5,1,'Profile 0',NULL,'width',1350,'1.0','2.0','3.0','admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08',NULL,NULL);
/*!40000 ALTER TABLE `container_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_report_template`
--

DROP TABLE IF EXISTS `custom_report_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_report_template` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `data` text NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `limit` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `custom_report_template_system_mtime_index` (`system_mtime`),
  KEY `custom_report_template_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_report_template`
--

LOCK TABLES `custom_report_template` WRITE;
/*!40000 ALTER TABLE `custom_report_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_report_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `date`
--

DROP TABLE IF EXISTS `date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `date` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `deaccession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `date_type_id` int DEFAULT NULL,
  `label_id` int NOT NULL,
  `certainty_id` int DEFAULT NULL,
  `expression` varchar(255) DEFAULT NULL,
  `begin` varchar(255) DEFAULT NULL,
  `end` varchar(255) DEFAULT NULL,
  `era_id` int DEFAULT NULL,
  `calendar_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_type_id` (`date_type_id`),
  KEY `label_id` (`label_id`),
  KEY `certainty_id` (`certainty_id`),
  KEY `era_id` (`era_id`),
  KEY `calendar_id` (`calendar_id`),
  KEY `date_system_mtime_index` (`system_mtime`),
  KEY `date_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `resource_id` (`resource_id`),
  KEY `event_id` (`event_id`),
  KEY `deaccession_id` (`deaccession_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  CONSTRAINT `date_ibfk_1` FOREIGN KEY (`date_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `date_ibfk_10` FOREIGN KEY (`deaccession_id`) REFERENCES `deaccession` (`id`),
  CONSTRAINT `date_ibfk_12` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `date_ibfk_13` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`),
  CONSTRAINT `date_ibfk_2` FOREIGN KEY (`label_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `date_ibfk_3` FOREIGN KEY (`certainty_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `date_ibfk_4` FOREIGN KEY (`era_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `date_ibfk_5` FOREIGN KEY (`calendar_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `date_ibfk_6` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `date_ibfk_7` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `date_ibfk_8` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `date_ibfk_9` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `date`
--

LOCK TABLES `date` WRITE;
/*!40000 ALTER TABLE `date` DISABLE KEYS */;
INSERT INTO `date` VALUES (1,0,1,NULL,NULL,NULL,1,NULL,NULL,NULL,903,906,NULL,NULL,'1906-10-29','1907-03-03',NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(2,0,1,NULL,NULL,NULL,2,NULL,NULL,NULL,903,906,NULL,NULL,'1906-10-29','1907-03-03',NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(3,0,1,NULL,NULL,NULL,3,NULL,NULL,NULL,903,906,NULL,NULL,'1906-10-29','1907-03-03',NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(4,0,1,NULL,NULL,NULL,4,NULL,NULL,NULL,903,906,NULL,NULL,'1906-10-29','1907-03-03',NULL,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05'),(5,0,1,NULL,NULL,NULL,5,NULL,NULL,NULL,903,906,NULL,NULL,'1906-10-29','1907-03-03',NULL,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05'),(10,0,1,NULL,NULL,NULL,7,NULL,NULL,NULL,903,906,918,'1900-2000','1900-01-01','2000-12-31',258,259,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(11,0,1,NULL,NULL,NULL,7,NULL,NULL,NULL,901,904,NULL,'1900','1900-01-01',NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(12,0,1,NULL,3,NULL,NULL,NULL,NULL,NULL,901,907,918,'1900','1900-01-01',NULL,258,259,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(13,0,1,NULL,4,NULL,NULL,NULL,NULL,NULL,903,907,NULL,'1900-2000','1900-01-01','2000-12-31',NULL,NULL,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47');
/*!40000 ALTER TABLE `date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deaccession`
--

DROP TABLE IF EXISTS `deaccession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deaccession` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `scope_id` int NOT NULL,
  `description` text NOT NULL,
  `reason` text,
  `disposition` text,
  `notification` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `scope_id` (`scope_id`),
  KEY `deaccession_system_mtime_index` (`system_mtime`),
  KEY `deaccession_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `resource_id` (`resource_id`),
  CONSTRAINT `deaccession_ibfk_1` FOREIGN KEY (`scope_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `deaccession_ibfk_2` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `deaccession_ibfk_3` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deaccession`
--

LOCK TABLES `deaccession` WRITE;
/*!40000 ALTER TABLE `deaccession` DISABLE KEYS */;
INSERT INTO `deaccession` VALUES (3,0,1,NULL,7,921,'Description 1','Reason 1','Disposition 1',1,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(4,0,1,NULL,7,921,'Description 2','Reason 2','Disposition 2',0,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47');
/*!40000 ALTER TABLE `deaccession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `default_values`
--

DROP TABLE IF EXISTS `default_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `default_values` (
  `lock_version` int NOT NULL DEFAULT '0',
  `id` varchar(255) NOT NULL,
  `blob` blob NOT NULL,
  `repo_id` int NOT NULL,
  `record_type` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `default_values_system_mtime_index` (`system_mtime`),
  KEY `default_values_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `default_values`
--

LOCK TABLES `default_values` WRITE;
/*!40000 ALTER TABLE `default_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `default_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deleted_records`
--

DROP TABLE IF EXISTS `deleted_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deleted_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `operator` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `deleted_records_uri_index` (`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deleted_records`
--

LOCK TABLES `deleted_records` WRITE;
/*!40000 ALTER TABLE `deleted_records` DISABLE KEYS */;
INSERT INTO `deleted_records` VALUES (1,'/locations/1','admin','2026-02-27 23:22:09');
/*!40000 ALTER TABLE `deleted_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `digital_object`
--

DROP TABLE IF EXISTS `digital_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `digital_object` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `digital_object_id` varchar(255) NOT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `level_id` int DEFAULT NULL,
  `digital_object_type_id` int DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `restrictions` int DEFAULT NULL,
  `system_generated` int DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `digital_object_repo_id_digital_object_id_index` (`repo_id`,`digital_object_id`),
  KEY `level_id` (`level_id`),
  KEY `digital_object_type_id` (`digital_object_type_id`),
  KEY `digital_object_system_mtime_index` (`system_mtime`),
  KEY `digital_object_user_mtime_index` (`user_mtime`),
  CONSTRAINT `digital_object_ibfk_1` FOREIGN KEY (`level_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `digital_object_ibfk_2` FOREIGN KEY (`digital_object_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `digital_object_ibfk_4` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `digital_object`
--

LOCK TABLES `digital_object` WRITE;
/*!40000 ALTER TABLE `digital_object` DISABLE KEYS */;
INSERT INTO `digital_object` VALUES (1,0,1,2,'DOID_392','Test DO 3',NULL,268,1,0,0,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',0,NULL,1),(2,1,1,2,'DOID_654','Test DO 2',NULL,268,1,0,0,'admin','admin','2026-02-27 23:18:07','2026-03-06 20:48:47','2026-02-27 23:18:07',0,NULL,1),(3,2,1,2,'DOID_352','Test DO 1',NULL,268,1,0,0,'admin','admin','2026-02-27 23:18:07','2026-03-09 22:36:36','2026-03-09 22:36:35',0,NULL,1),(4,0,1,2,'DOID_442','Test DO 0',NULL,268,1,0,0,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',0,NULL,1);
/*!40000 ALTER TABLE `digital_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `digital_object_component`
--

DROP TABLE IF EXISTS `digital_object_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `digital_object_component` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `root_record_id` int DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `position` int NOT NULL,
  `parent_name` varchar(255) DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `component_id` varchar(255) DEFAULT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `display_string` text,
  `label` varchar(255) DEFAULT NULL,
  `system_generated` int DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `doc_unique_identifier` (`repo_id`,`component_id`),
  UNIQUE KEY `uniq_do_pos` (`parent_name`,`position`),
  KEY `digital_object_component_system_mtime_index` (`system_mtime`),
  KEY `digital_object_component_user_mtime_index` (`user_mtime`),
  KEY `root_record_id` (`root_record_id`),
  KEY `parent_id` (`parent_id`),
  KEY `digital_object_component_component_id_index` (`component_id`),
  CONSTRAINT `digital_object_component_ibfk_2` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`),
  CONSTRAINT `digital_object_component_ibfk_3` FOREIGN KEY (`root_record_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `digital_object_component_ibfk_4` FOREIGN KEY (`parent_id`) REFERENCES `digital_object_component` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `digital_object_component`
--

LOCK TABLES `digital_object_component` WRITE;
/*!40000 ALTER TABLE `digital_object_component` DISABLE KEYS */;
/*!40000 ALTER TABLE `digital_object_component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enumeration`
--

DROP TABLE IF EXISTS `enumeration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enumeration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `default_value` int DEFAULT NULL,
  `editable` int DEFAULT '1',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `enumeration_system_mtime_index` (`system_mtime`),
  KEY `enumeration_user_mtime_index` (`user_mtime`),
  KEY `enumeration_default_value_fk` (`default_value`),
  CONSTRAINT `enumeration_default_value_fk` FOREIGN KEY (`default_value`) REFERENCES `enumeration_value` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enumeration`
--

LOCK TABLES `enumeration` WRITE;
/*!40000 ALTER TABLE `enumeration` DISABLE KEYS */;
INSERT INTO `enumeration` VALUES (1,0,1,'linked_agent_archival_record_relators',NULL,1,NULL,NULL,'2026-02-27 23:16:40','2026-02-27 23:16:40','2026-02-27 23:16:40'),(2,0,1,'linked_event_archival_record_roles',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(3,0,1,'linked_agent_event_roles',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(4,0,1,'name_source',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(5,0,1,'name_rule',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(6,0,1,'accession_acquisition_type',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(7,0,1,'accession_resource_type',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(8,0,1,'collection_management_processing_priority',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(9,0,1,'collection_management_processing_status',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(10,0,1,'date_era',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(11,0,1,'date_calendar',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(12,0,1,'digital_object_digital_object_type',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(13,0,1,'digital_object_level',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(14,0,1,'extent_extent_type',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(15,0,1,'event_event_type',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(16,0,1,'container_type',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(17,0,1,'agent_contact_salutation',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(18,0,1,'event_outcome',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(19,0,1,'resource_resource_type',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(20,0,1,'resource_finding_aid_description_rules',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(21,1,1,'resource_finding_aid_status',NULL,1,NULL,'admin','2026-02-27 23:16:41','2026-02-27 23:18:13','2026-02-27 23:18:13'),(22,0,1,'instance_instance_type',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(23,1,1,'subject_source',NULL,1,NULL,'admin','2026-02-27 23:16:41','2026-02-27 23:18:13','2026-02-27 23:18:13'),(24,0,1,'file_version_use_statement',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(25,0,1,'file_version_checksum_methods',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(26,0,1,'language_iso639_2',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(27,0,1,'linked_agent_role',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(28,0,1,'agent_relationship_associative_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(29,0,1,'agent_relationship_earlierlater_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(30,0,1,'agent_relationship_parentchild_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(31,0,1,'agent_relationship_subordinatesuperior_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(32,0,1,'archival_record_level',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(33,0,1,'container_location_status',899,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(34,0,1,'date_type',NULL,0,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(35,0,1,'date_label',NULL,1,NULL,NULL,'2026-02-27 23:16:41','2026-02-27 23:16:41','2026-02-27 23:16:41'),(36,0,1,'date_certainty',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(37,0,1,'deaccession_scope',921,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(38,0,1,'extent_portion',923,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(39,0,1,'file_version_xlink_actuate_attribute',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(40,0,1,'file_version_xlink_show_attribute',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(41,0,1,'file_version_file_format_name',NULL,1,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(42,0,1,'location_temporary',NULL,1,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(43,0,1,'name_person_name_order',946,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(44,0,1,'note_digital_object_type',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(45,0,1,'note_multipart_type',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(46,0,1,'note_orderedlist_enumeration',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(47,0,1,'note_singlepart_type',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(48,0,1,'note_bibliography_type',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(49,0,1,'note_index_type',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(50,0,1,'note_index_item_type',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(51,0,1,'country_iso_3166',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(52,0,1,'rights_statement_rights_type',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(53,0,1,'rights_statement_ip_status',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(54,0,1,'subject_term_type',NULL,0,NULL,NULL,'2026-02-27 23:16:42','2026-02-27 23:16:42','2026-02-27 23:16:42'),(55,0,1,'user_defined_enum_1',NULL,1,NULL,NULL,'2026-02-27 23:16:43','2026-02-27 23:16:43','2026-02-27 23:16:43'),(56,0,1,'user_defined_enum_2',NULL,1,NULL,NULL,'2026-02-27 23:16:43','2026-02-27 23:16:43','2026-02-27 23:16:43'),(57,0,1,'user_defined_enum_3',NULL,1,NULL,NULL,'2026-02-27 23:16:43','2026-02-27 23:16:43','2026-02-27 23:16:43'),(58,0,1,'user_defined_enum_4',NULL,1,NULL,NULL,'2026-02-27 23:16:43','2026-02-27 23:16:43','2026-02-27 23:16:43'),(59,0,1,'accession_parts_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(60,0,1,'accession_parts_relator_type',NULL,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(61,0,1,'accession_sibling_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(62,0,1,'accession_sibling_relator_type',NULL,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(64,0,1,'telephone_number_type',NULL,1,NULL,NULL,'2026-02-27 23:16:49','2026-02-27 23:16:49','2026-02-27 23:16:49'),(65,0,1,'restriction_type',NULL,1,NULL,NULL,'2026-02-27 23:16:49','2026-02-27 23:16:49','2026-02-27 23:16:49'),(66,0,1,'dimension_units',NULL,0,NULL,NULL,'2026-02-27 23:16:49','2026-02-27 23:16:49','2026-02-27 23:16:49'),(67,0,1,'location_function_type',NULL,1,NULL,NULL,'2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(68,0,1,'rights_statement_act_type',NULL,1,NULL,NULL,'2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(69,0,1,'rights_statement_act_restriction',NULL,1,NULL,NULL,'2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(70,0,1,'note_rights_statement_act_type',NULL,0,NULL,NULL,'2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(71,0,1,'note_rights_statement_type',NULL,0,NULL,NULL,'2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(72,0,1,'rights_statement_external_document_identifier_type',NULL,1,NULL,NULL,'2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(73,0,1,'rights_statement_other_rights_basis',NULL,1,NULL,NULL,'2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(74,0,1,'script_iso15924',NULL,1,NULL,NULL,'2026-02-27 23:16:52','2026-02-27 23:16:52','2026-02-27 23:16:52'),(75,0,1,'note_langmaterial_type',NULL,0,NULL,NULL,'2026-02-27 23:16:52','2026-02-27 23:16:52','2026-02-27 23:16:52'),(76,0,1,'maintenance_status',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(77,0,1,'publication_status',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(78,0,1,'romanization',NULL,1,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(79,0,1,'transliteration',NULL,1,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(80,0,1,'government_agency_type',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(81,0,1,'reference_evaluation',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(82,0,1,'name_type',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(83,0,1,'level_of_detail',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(84,0,1,'modified_record',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(85,0,1,'cataloging_source',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(86,0,1,'identifier_type',NULL,1,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(87,0,1,'agency_code_type',NULL,1,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(88,0,1,'maintenance_event_type',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(89,0,1,'maintenance_agent_type',1763,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(90,0,1,'date_type_structured',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(91,0,1,'date_role',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(92,0,1,'date_standardized_type',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(93,0,1,'begin_date_standardized_type',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(94,0,1,'end_date_standardized_type',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(95,0,1,'place_role',NULL,1,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(96,0,1,'agent_relationship_identity_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(97,0,1,'agent_relationship_hierarchical_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(98,0,1,'agent_relationship_temporal_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(99,0,1,'agent_relationship_family_relator',NULL,0,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(100,0,1,'gender',NULL,1,NULL,NULL,'2026-02-27 23:16:53','2026-02-27 23:16:53','2026-02-27 23:16:53'),(101,0,1,'agent_relationship_specific_relator',NULL,1,NULL,NULL,'2026-02-27 23:16:54','2026-02-27 23:16:54','2026-02-27 23:16:54'),(102,0,1,'metadata_license',NULL,1,NULL,NULL,'2026-02-27 23:16:55','2026-02-27 23:16:55','2026-02-27 23:16:55');
/*!40000 ALTER TABLE `enumeration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enumeration_value`
--

DROP TABLE IF EXISTS `enumeration_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enumeration_value` (
  `id` int NOT NULL AUTO_INCREMENT,
  `enumeration_id` int NOT NULL,
  `value` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `readonly` int DEFAULT '0',
  `position` int NOT NULL DEFAULT '0',
  `suppressed` int DEFAULT '0',
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL DEFAULT '1',
  `created_by` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `last_modified_by` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `system_mtime` datetime DEFAULT NULL,
  `user_mtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `enumeration_value_uniq` (`enumeration_id`,`value`),
  UNIQUE KEY `enumeration_position_uniq` (`enumeration_id`,`position`),
  KEY `enumeration_value_enumeration_id_index` (`enumeration_id`),
  KEY `enumeration_value_value_index` (`value`),
  CONSTRAINT `enumeration_value_ibfk_1` FOREIGN KEY (`enumeration_id`) REFERENCES `enumeration` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1798 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enumeration_value`
--

LOCK TABLES `enumeration_value` WRITE;
/*!40000 ALTER TABLE `enumeration_value` DISABLE KEYS */;
INSERT INTO `enumeration_value` VALUES (1,1,'act',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(2,1,'adp',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(3,1,'anl',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(4,1,'anm',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(5,1,'ann',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(6,1,'app',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(7,1,'arc',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(8,1,'arr',0,12,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(9,1,'acp',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(10,1,'art',0,13,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(11,1,'ard',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(12,1,'asg',0,14,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(13,1,'asn',0,15,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(14,1,'att',0,16,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(15,1,'auc',0,17,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(16,1,'aut',0,21,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(17,1,'aqt',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(18,1,'aft',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(19,1,'aud',0,18,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(20,1,'aui',0,19,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(21,1,'aus',0,20,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(22,1,'ant',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(23,1,'bnd',0,27,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(24,1,'bdd',0,22,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(25,1,'blw',0,26,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(26,1,'bkd',0,24,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(27,1,'bkp',0,25,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(28,1,'bjd',0,23,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(29,1,'bpd',0,28,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(30,1,'bsl',0,29,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(31,1,'cll',0,34,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(32,1,'ctg',0,63,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(33,1,'cns',0,42,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(34,1,'chr',0,31,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(35,1,'cng',0,41,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(36,1,'cli',0,33,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(37,1,'clb',0,32,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(38,1,'col',0,44,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(39,1,'clt',0,36,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(40,1,'clr',0,35,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(41,1,'cmm',0,37,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(42,1,'cwt',0,68,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(43,1,'com',0,45,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(44,1,'cpl',0,53,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(45,1,'cpt',0,54,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(46,1,'cpe',0,51,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(47,1,'cmp',0,38,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(48,1,'cmt',0,39,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(49,1,'ccp',0,30,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(50,1,'cnd',0,40,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(51,1,'con',0,46,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(52,1,'csl',0,58,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(53,1,'csp',0,59,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(54,1,'cos',0,47,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(55,1,'cot',0,48,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(56,1,'coe',0,43,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(57,1,'cts',0,65,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(58,1,'ctt',0,66,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(59,1,'cte',0,62,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(60,1,'ctr',0,64,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(61,1,'ctb',0,61,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(62,1,'cpc',0,50,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(63,1,'cph',0,52,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(64,1,'crr',0,57,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(65,1,'crp',0,56,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(66,1,'cst',0,60,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(67,1,'cov',0,49,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(68,1,'cre',0,55,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(69,1,'cur',0,67,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(70,1,'dnc',0,76,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(71,1,'dtc',0,84,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(72,1,'dtm',0,86,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(73,1,'dte',0,85,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(74,1,'dto',0,87,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(75,1,'dfd',0,70,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(76,1,'dft',0,72,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(77,1,'dfe',0,71,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(78,1,'dgg',0,73,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(79,1,'dln',0,75,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(80,1,'dpc',0,78,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(81,1,'dpt',0,79,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(82,1,'dsr',0,82,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(83,1,'drt',0,81,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(84,1,'dis',0,74,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(85,1,'dbp',0,69,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(86,1,'dst',0,83,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(87,1,'drm',0,80,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(88,1,'dub',0,88,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(89,1,'edt',0,89,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(90,1,'elg',0,91,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(91,1,'elt',0,92,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(92,1,'eng',0,93,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(93,1,'egr',0,90,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(94,1,'etr',0,94,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(95,1,'evp',0,95,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(96,1,'exp',0,96,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(97,1,'fac',0,97,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(98,1,'fld',0,98,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(99,1,'flm',0,99,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(100,1,'fpy',0,102,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(101,1,'frg',0,103,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(102,1,'fmo',0,100,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(103,1,'dnr',0,77,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(104,1,'fnd',0,101,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(105,1,'gis',0,104,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(106,1,'grt',0,105,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(107,1,'hnr',0,106,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(108,1,'hst',0,107,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(109,1,'ilu',0,109,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(110,1,'ill',0,108,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(111,1,'ins',0,110,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(112,1,'itr',0,112,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(113,1,'ive',0,113,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(114,1,'ivr',0,114,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(115,1,'inv',0,111,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(116,1,'lbr',0,115,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(117,1,'ldr',0,117,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(118,1,'lsa',0,127,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(119,1,'led',0,118,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(120,1,'len',0,121,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(121,1,'lil',0,125,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(122,1,'lit',0,126,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(123,1,'lie',0,124,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(124,1,'lel',0,120,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(125,1,'let',0,122,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(126,1,'lee',0,119,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(127,1,'lbt',0,116,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(128,1,'lse',0,128,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(129,1,'lso',0,129,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(130,1,'lgd',0,123,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(131,1,'ltg',0,130,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(132,1,'lyr',0,131,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(133,1,'mfp',0,134,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(134,1,'mfr',0,135,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(135,1,'mrb',0,138,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(136,1,'mrk',0,139,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(137,1,'mdc',0,133,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(138,1,'mte',0,141,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(139,1,'mod',0,136,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(140,1,'mon',0,137,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(141,1,'mcp',0,132,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(142,1,'msd',0,140,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(143,1,'mus',0,142,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(144,1,'nrt',0,143,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(145,1,'opn',0,144,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(146,1,'orm',0,146,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(147,1,'org',0,145,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(148,1,'oth',0,147,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(149,1,'own',0,148,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(150,1,'ppm',0,159,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(151,1,'pta',0,170,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(152,1,'pth',0,173,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(153,1,'pat',0,149,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(154,1,'prf',0,163,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(155,1,'pma',0,156,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(156,1,'pht',0,154,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(157,1,'ptf',0,172,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(158,1,'ptt',0,174,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(159,1,'pte',0,171,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(160,1,'plt',0,155,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(161,1,'prt',0,168,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(162,1,'pop',0,158,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(163,1,'prm',0,165,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(164,1,'prc',0,161,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(165,1,'pro',0,166,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(166,1,'pmn',0,157,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(167,1,'prd',0,162,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(168,1,'prp',0,167,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(169,1,'prg',0,164,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(170,1,'pdr',0,152,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(171,1,'pfr',0,153,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(172,1,'prv',0,169,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(173,1,'pup',0,175,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(174,1,'pbl',0,151,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(175,1,'pbd',0,150,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(176,1,'ppt',0,160,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(177,1,'rcp',0,179,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(178,1,'rce',0,178,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(179,1,'rcd',0,177,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(180,1,'red',0,180,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(181,1,'ren',0,181,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(182,1,'rpt',0,185,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(183,1,'rps',0,184,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(184,1,'rth',0,191,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(185,1,'rtm',0,192,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(186,1,'res',0,182,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(187,1,'rsp',0,189,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(188,1,'rst',0,190,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(189,1,'rse',0,187,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(190,1,'rpy',0,186,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(191,1,'rsg',0,188,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(192,1,'rev',0,183,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(193,1,'rbr',0,176,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(194,1,'sce',0,194,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(195,1,'sad',0,193,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(196,1,'scr',0,196,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(197,1,'scl',0,195,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(198,1,'spy',0,204,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(199,1,'sec',0,198,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(200,1,'std',0,206,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(201,1,'stg',0,207,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(202,1,'sgn',0,199,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(203,1,'sng',0,201,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(204,1,'sds',0,197,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(205,1,'spk',0,202,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(206,1,'spn',0,203,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(207,1,'stm',0,209,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(208,1,'stn',0,210,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(209,1,'str',0,211,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(210,1,'stl',0,208,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(211,1,'sht',0,200,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(212,1,'srv',0,205,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(213,1,'tch',0,213,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(214,1,'tcd',0,212,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(215,1,'ths',0,214,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(216,1,'trc',0,215,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(217,1,'trl',0,216,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(218,1,'tyd',0,217,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(219,1,'tyg',0,218,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(220,1,'uvp',0,219,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(221,1,'vdg',0,220,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(222,1,'voc',0,221,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(223,1,'wit',0,225,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(224,1,'wde',0,224,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(225,1,'wdc',0,223,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(226,1,'wam',0,222,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(227,2,'source',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(228,2,'outcome',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(229,2,'transfer',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(230,3,'authorizer',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(231,3,'executing_program',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(232,3,'implementer',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(233,3,'recipient',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(234,3,'transmitter',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(235,3,'validator',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(236,4,'local',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(237,4,'naf',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(238,4,'nad',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(239,4,'ulan',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(240,5,'local',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(241,5,'aacr',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(242,5,'dacs',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(243,5,'rda',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(244,6,'deposit',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(245,6,'gift',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(246,6,'purchase',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(247,6,'transfer',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(248,7,'collection',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(249,7,'publications',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(250,7,'papers',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(251,7,'records',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(252,8,'high',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(253,8,'medium',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(254,8,'low',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(255,9,'new',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(256,9,'in_progress',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(257,9,'completed',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(258,10,'ce',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(259,11,'gregorian',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(260,12,'cartographic',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(261,12,'mixed_materials',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(262,12,'moving_image',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(263,12,'notated_music',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(264,12,'software_multimedia',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(265,12,'sound_recording',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(266,12,'sound_recording_musical',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(267,12,'sound_recording_nonmusical',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(268,12,'still_image',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(269,12,'text',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(270,13,'collection',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(271,13,'work',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(272,13,'image',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(273,14,'cassettes',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(274,14,'cubic_feet',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(275,14,'gigabytes',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(276,14,'leaves',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(277,14,'linear_feet',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(278,14,'megabytes',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(279,14,'photographic_prints',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(280,14,'photographic_slides',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(281,14,'reels',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(282,14,'sheets',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(283,14,'terabytes',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(284,14,'volumes',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(285,15,'accession',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(286,15,'accumulation',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(287,15,'acknowledgement_sent',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(288,15,'acknowledgement_received',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(289,15,'agreement_signed',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(290,15,'agreement_received',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(291,15,'agreement_sent',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(292,15,'appraisal',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(293,15,'assessment',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(294,15,'capture',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(295,15,'cataloged',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(296,15,'collection',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(297,15,'compression',0,13,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(298,15,'contribution',0,14,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(299,15,'component_transfer',0,12,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(300,15,'copyright_transfer',0,15,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(301,15,'custody_transfer',0,16,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(302,15,'deaccession',0,17,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(303,15,'decompression',0,18,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(304,15,'decryption',0,19,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(305,15,'deletion',0,20,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(306,15,'digital_signature_validation',0,21,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(307,15,'fixity_check',0,22,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(308,15,'ingestion',0,23,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(309,15,'message_digest_calculation',0,24,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(310,15,'migration',0,25,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(311,15,'normalization',0,26,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(312,15,'processed',0,27,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(313,15,'publication',0,28,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(314,15,'replication',0,29,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(315,15,'validation',0,30,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(316,15,'virus_check',0,31,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(317,16,'box',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(318,16,'carton',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(319,16,'case',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(320,16,'folder',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(321,16,'frame',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(322,16,'object',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(323,16,'reel',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(324,17,'mr',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(325,17,'mrs',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(326,17,'ms',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(327,17,'madame',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(328,17,'sir',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(329,18,'pass',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(330,18,'partial pass',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(331,18,'fail',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(332,19,'collection',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(333,19,'publications',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(334,19,'papers',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(335,19,'records',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(336,20,'aacr',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(337,20,'cco',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(338,20,'dacs',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(339,20,'rad',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(340,20,'isadg',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(341,21,'completed',0,0,0,1,1,NULL,'admin','2026-02-27 23:16:48','2026-02-27 23:18:13','2026-02-27 23:16:48'),(342,21,'in_progress',0,1,0,1,1,NULL,'admin','2026-02-27 23:16:48','2026-02-27 23:18:13','2026-02-27 23:16:48'),(343,21,'under_revision',0,2,0,1,1,NULL,'admin','2026-02-27 23:16:48','2026-02-27 23:18:13','2026-02-27 23:16:48'),(344,21,'unprocessed',0,3,0,1,1,NULL,'admin','2026-02-27 23:16:48','2026-02-27 23:18:13','2026-02-27 23:16:48'),(345,22,'accession',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(346,22,'audio',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(347,22,'books',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(348,22,'computer_disks',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(349,22,'digital_object',1,4,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(350,22,'graphic_materials',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(351,22,'maps',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(352,22,'microform',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(353,22,'mixed_materials',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(354,22,'moving_images',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(355,22,'realia',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(356,22,'text',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(357,23,'aat',0,0,0,1,1,NULL,'admin','2026-02-27 23:16:47','2026-02-27 23:18:13','2026-02-27 23:16:47'),(358,23,'rbgenr',0,5,0,1,1,NULL,'admin','2026-02-27 23:16:47','2026-02-27 23:18:13','2026-02-27 23:16:47'),(359,23,'tgn',0,6,0,1,1,NULL,'admin','2026-02-27 23:16:47','2026-02-27 23:18:13','2026-02-27 23:16:47'),(360,23,'lcsh',0,2,0,1,1,NULL,'admin','2026-02-27 23:16:47','2026-02-27 23:18:13','2026-02-27 23:16:47'),(361,23,'local',0,3,0,1,1,NULL,'admin','2026-02-27 23:16:47','2026-02-27 23:18:13','2026-02-27 23:16:47'),(362,23,'mesh',0,4,0,1,1,NULL,'admin','2026-02-27 23:16:47','2026-02-27 23:18:13','2026-02-27 23:16:47'),(363,23,'gmgpc',0,1,0,1,1,NULL,'admin','2026-02-27 23:16:47','2026-02-27 23:18:13','2026-02-27 23:16:47'),(364,24,'application',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(365,24,'application-pdf',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(366,24,'audio-clip',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(367,24,'audio-master',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(368,24,'audio-master-edited',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(369,24,'audio-service',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(370,24,'image-master',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(371,24,'image-master-edited',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(372,24,'image-service',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(373,24,'image-service-edited',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(374,24,'image-thumbnail',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(375,24,'text-codebook',0,12,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(376,24,'test-data',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(377,24,'text-data_definition',0,13,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(378,24,'text-georeference',0,14,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(379,24,'text-ocr-edited',0,15,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(380,24,'text-ocr-unedited',0,16,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(381,24,'text-tei-transcripted',0,17,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(382,24,'text-tei-translated',0,18,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(383,24,'video-clip',0,19,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(384,24,'video-master',0,20,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(385,24,'video-master-edited',0,21,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(386,24,'video-service',0,22,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(387,24,'video-streaming',0,23,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(388,25,'md5',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(389,25,'sha-1',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(390,25,'sha-256',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(391,25,'sha-384',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(392,25,'sha-512',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(393,26,'aar',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(394,26,'abk',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(395,26,'ace',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(396,26,'ach',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(397,26,'ada',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(398,26,'ady',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(399,26,'afa',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(400,26,'afh',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(401,26,'afr',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(402,26,'ain',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(403,26,'aka',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(404,26,'akk',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(405,26,'alb',0,12,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(406,26,'ale',0,13,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(407,26,'alg',0,14,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(408,26,'alt',0,15,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(409,26,'amh',0,16,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(410,26,'ang',0,17,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(411,26,'anp',0,18,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(412,26,'apa',0,19,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(413,26,'ara',0,20,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(414,26,'arc',0,21,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(415,26,'arg',0,22,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(416,26,'arm',0,23,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(417,26,'arn',0,24,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(418,26,'arp',0,25,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(419,26,'art',0,26,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(420,26,'arw',0,27,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(421,26,'asm',0,28,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(422,26,'ast',0,29,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(423,26,'ath',0,30,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(424,26,'aus',0,31,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(425,26,'ava',0,32,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(426,26,'ave',0,33,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(427,26,'awa',0,34,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(428,26,'aym',0,35,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(429,26,'aze',0,36,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(430,26,'bad',0,37,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(431,26,'bai',0,38,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(432,26,'bak',0,39,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(433,26,'bal',0,40,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(434,26,'bam',0,41,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(435,26,'ban',0,42,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(436,26,'baq',0,43,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(437,26,'bas',0,44,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(438,26,'bat',0,45,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(439,26,'bej',0,46,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(440,26,'bel',0,47,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(441,26,'bem',0,48,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(442,26,'ben',0,49,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(443,26,'ber',0,50,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(444,26,'bho',0,51,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(445,26,'bih',0,52,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(446,26,'bik',0,53,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(447,26,'bin',0,54,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(448,26,'bis',0,55,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(449,26,'bla',0,56,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(450,26,'bnt',0,57,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(451,26,'bos',0,58,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(452,26,'bra',0,59,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(453,26,'bre',0,60,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(454,26,'btk',0,61,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(455,26,'bua',0,62,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(456,26,'bug',0,63,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(457,26,'bul',0,64,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(458,26,'bur',0,65,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(459,26,'byn',0,66,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(460,26,'cad',0,67,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(461,26,'cai',0,68,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(462,26,'car',0,69,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(463,26,'cat',0,70,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(464,26,'cau',0,71,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(465,26,'ceb',0,72,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(466,26,'cel',0,73,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(467,26,'cha',0,74,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(468,26,'chb',0,75,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(469,26,'che',0,76,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(470,26,'chg',0,77,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(471,26,'chi',0,78,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(472,26,'chk',0,79,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(473,26,'chm',0,80,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(474,26,'chn',0,81,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(475,26,'cho',0,82,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(476,26,'chp',0,83,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(477,26,'chr',0,84,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(478,26,'chu',0,85,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(479,26,'chv',0,86,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(480,26,'chy',0,87,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(481,26,'cmc',0,88,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(482,26,'cop',0,89,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(483,26,'cor',0,90,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(484,26,'cos',0,91,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(485,26,'cpe',0,92,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(486,26,'cpf',0,93,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(487,26,'cpp',0,94,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(488,26,'cre',0,95,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(489,26,'crh',0,96,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(490,26,'crp',0,97,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(491,26,'csb',0,98,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(492,26,'cus',0,99,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(493,26,'cze',0,100,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(494,26,'dak',0,101,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(495,26,'dan',0,102,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(496,26,'dar',0,103,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(497,26,'day',0,104,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(498,26,'del',0,105,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(499,26,'den',0,106,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(500,26,'dgr',0,107,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(501,26,'din',0,108,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(502,26,'div',0,109,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(503,26,'doi',0,110,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(504,26,'dra',0,111,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(505,26,'dsb',0,112,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(506,26,'dua',0,113,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(507,26,'dum',0,114,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(508,26,'dut',0,115,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(509,26,'dyu',0,116,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(510,26,'dzo',0,117,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(511,26,'efi',0,118,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(512,26,'egy',0,119,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(513,26,'eka',0,120,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(514,26,'elx',0,121,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(515,26,'eng',0,122,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(516,26,'enm',0,123,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(517,26,'epo',0,124,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(518,26,'est',0,125,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(519,26,'ewe',0,126,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(520,26,'ewo',0,127,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(521,26,'fan',0,128,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(522,26,'fao',0,129,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(523,26,'fat',0,130,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(524,26,'fij',0,131,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(525,26,'fil',0,132,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(526,26,'fin',0,133,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(527,26,'fiu',0,134,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(528,26,'fon',0,135,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(529,26,'fre',0,136,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(530,26,'frm',0,137,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(531,26,'fro',0,138,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(532,26,'frr',0,139,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(533,26,'frs',0,140,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(534,26,'fry',0,141,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(535,26,'ful',0,142,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(536,26,'fur',0,143,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(537,26,'gaa',0,144,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(538,26,'gay',0,145,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(539,26,'gba',0,146,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(540,26,'gem',0,147,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(541,26,'geo',0,148,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(542,26,'ger',0,149,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(543,26,'gez',0,150,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(544,26,'gil',0,151,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(545,26,'gla',0,152,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(546,26,'gle',0,153,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(547,26,'glg',0,154,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(548,26,'glv',0,155,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(549,26,'gmh',0,156,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(550,26,'goh',0,157,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(551,26,'gon',0,158,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(552,26,'gor',0,159,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(553,26,'got',0,160,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(554,26,'grb',0,161,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(555,26,'grc',0,162,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(556,26,'gre',0,163,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(557,26,'grn',0,164,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(558,26,'gsw',0,165,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(559,26,'guj',0,166,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(560,26,'gwi',0,167,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(561,26,'hai',0,168,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(562,26,'hat',0,169,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(563,26,'hau',0,170,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(564,26,'haw',0,171,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(565,26,'heb',0,172,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(566,26,'her',0,173,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(567,26,'hil',0,174,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(568,26,'him',0,175,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(569,26,'hin',0,176,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(570,26,'hit',0,177,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(571,26,'hmn',0,178,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(572,26,'hmo',0,179,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(573,26,'hrv',0,180,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(574,26,'hsb',0,181,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(575,26,'hun',0,182,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(576,26,'hup',0,183,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(577,26,'iba',0,184,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(578,26,'ibo',0,185,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(579,26,'ice',0,186,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(580,26,'ido',0,187,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(581,26,'iii',0,188,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(582,26,'ijo',0,189,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(583,26,'iku',0,190,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(584,26,'ile',0,191,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(585,26,'ilo',0,192,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(586,26,'ina',0,193,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(587,26,'inc',0,194,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(588,26,'ind',0,195,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(589,26,'ine',0,196,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(590,26,'inh',0,197,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(591,26,'ipk',0,198,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(592,26,'ira',0,199,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(593,26,'iro',0,200,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(594,26,'ita',0,201,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(595,26,'jav',0,202,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(596,26,'jbo',0,203,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(597,26,'jpn',0,204,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(598,26,'jpr',0,205,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(599,26,'jrb',0,206,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(600,26,'kaa',0,207,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(601,26,'kab',0,208,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(602,26,'kac',0,209,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(603,26,'kal',0,210,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(604,26,'kam',0,211,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(605,26,'kan',0,212,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(606,26,'kar',0,213,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(607,26,'kas',0,214,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(608,26,'kau',0,215,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(609,26,'kaw',0,216,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(610,26,'kaz',0,217,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(611,26,'kbd',0,218,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(612,26,'kha',0,219,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(613,26,'khi',0,220,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(614,26,'khm',0,221,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(615,26,'kho',0,222,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(616,26,'kik',0,223,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(617,26,'kin',0,224,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(618,26,'kir',0,225,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(619,26,'kmb',0,226,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(620,26,'kok',0,227,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(621,26,'kom',0,228,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(622,26,'kon',0,229,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(623,26,'kor',0,230,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(624,26,'kos',0,231,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(625,26,'kpe',0,232,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(626,26,'krc',0,233,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(627,26,'krl',0,234,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(628,26,'kro',0,235,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(629,26,'kru',0,236,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(630,26,'kua',0,237,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(631,26,'kum',0,238,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(632,26,'kur',0,239,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(633,26,'kut',0,240,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(634,26,'lad',0,241,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(635,26,'lah',0,242,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(636,26,'lam',0,243,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(637,26,'lao',0,244,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(638,26,'lat',0,245,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(639,26,'lav',0,246,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(640,26,'lez',0,247,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(641,26,'lim',0,248,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(642,26,'lin',0,249,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(643,26,'lit',0,250,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(644,26,'lol',0,251,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(645,26,'loz',0,252,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(646,26,'ltz',0,253,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(647,26,'lua',0,254,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(648,26,'lub',0,255,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(649,26,'lug',0,256,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(650,26,'lui',0,257,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(651,26,'lun',0,258,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(652,26,'luo',0,259,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(653,26,'lus',0,260,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(654,26,'mac',0,261,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(655,26,'mad',0,262,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(656,26,'mag',0,263,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(657,26,'mah',0,264,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(658,26,'mai',0,265,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(659,26,'mak',0,266,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(660,26,'mal',0,267,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(661,26,'man',0,268,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(662,26,'mao',0,269,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(663,26,'map',0,270,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(664,26,'mar',0,271,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(665,26,'mas',0,272,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(666,26,'may',0,273,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(667,26,'mdf',0,274,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(668,26,'mdr',0,275,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(669,26,'men',0,276,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(670,26,'mga',0,277,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(671,26,'mic',0,278,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(672,26,'min',0,279,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(673,26,'mis',0,280,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(674,26,'mkh',0,281,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(675,26,'mlg',0,282,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(676,26,'mlt',0,283,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(677,26,'mnc',0,284,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(678,26,'mni',0,285,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(679,26,'mno',0,286,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(680,26,'moh',0,287,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(681,26,'mon',0,288,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(682,26,'mos',0,289,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(683,26,'mul',0,290,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(684,26,'mun',0,291,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(685,26,'mus',0,292,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(686,26,'mwl',0,293,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(687,26,'mwr',0,294,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(688,26,'myn',0,295,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(689,26,'myv',0,296,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(690,26,'nah',0,297,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(691,26,'nai',0,298,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(692,26,'nap',0,299,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(693,26,'nau',0,300,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(694,26,'nav',0,301,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(695,26,'nbl',0,302,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(696,26,'nde',0,303,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(697,26,'ndo',0,304,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(698,26,'nds',0,305,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(699,26,'nep',0,306,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(700,26,'new',0,307,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(701,26,'nia',0,308,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(702,26,'nic',0,309,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(703,26,'niu',0,310,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(704,26,'nno',0,311,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(705,26,'nob',0,312,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(706,26,'nog',0,313,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(707,26,'non',0,314,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(708,26,'nor',0,315,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(709,26,'nqo',0,316,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(710,26,'nso',0,317,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(711,26,'nub',0,318,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(712,26,'nwc',0,319,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(713,26,'nya',0,320,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(714,26,'nym',0,321,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(715,26,'nyn',0,322,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(716,26,'nyo',0,323,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(717,26,'nzi',0,324,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(718,26,'oci',0,325,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(719,26,'oji',0,326,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(720,26,'ori',0,327,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(721,26,'orm',0,328,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(722,26,'osa',0,329,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(723,26,'oss',0,330,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(724,26,'ota',0,331,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(725,26,'oto',0,332,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(726,26,'paa',0,333,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(727,26,'pag',0,334,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(728,26,'pal',0,335,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(729,26,'pam',0,336,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(730,26,'pan',0,337,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(731,26,'pap',0,338,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(732,26,'pau',0,339,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(733,26,'peo',0,340,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(734,26,'per',0,341,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(735,26,'phi',0,342,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(736,26,'phn',0,343,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(737,26,'pli',0,344,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(738,26,'pol',0,345,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(739,26,'pon',0,346,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(740,26,'por',0,347,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(741,26,'pra',0,348,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(742,26,'pro',0,349,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(743,26,'pus',0,350,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(745,26,'que',0,352,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(746,26,'raj',0,353,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(747,26,'rap',0,354,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(748,26,'rar',0,355,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(749,26,'roa',0,356,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(750,26,'roh',0,357,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(751,26,'rom',0,358,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(752,26,'rum',0,359,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(753,26,'run',0,360,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(754,26,'rup',0,361,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(755,26,'rus',0,362,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(756,26,'sad',0,363,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(757,26,'sag',0,364,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(758,26,'sah',0,365,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(759,26,'sai',0,366,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(760,26,'sal',0,367,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(761,26,'sam',0,368,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(762,26,'san',0,369,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(763,26,'sas',0,370,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(764,26,'sat',0,371,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(765,26,'scn',0,372,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(766,26,'sco',0,373,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(767,26,'sel',0,374,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(768,26,'sem',0,375,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(769,26,'sga',0,376,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(770,26,'sgn',0,377,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(771,26,'shn',0,378,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(772,26,'sid',0,379,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(773,26,'sin',0,380,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(774,26,'sio',0,381,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(775,26,'sit',0,382,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(776,26,'sla',0,383,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(777,26,'slo',0,384,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(778,26,'slv',0,385,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(779,26,'sma',0,386,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(780,26,'sme',0,387,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(781,26,'smi',0,388,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(782,26,'smj',0,389,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(783,26,'smn',0,390,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(784,26,'smo',0,391,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(785,26,'sms',0,392,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(786,26,'sna',0,393,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(787,26,'snd',0,394,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(788,26,'snk',0,395,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(789,26,'sog',0,396,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(790,26,'som',0,397,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(791,26,'son',0,398,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(792,26,'sot',0,399,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(793,26,'spa',0,400,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(794,26,'srd',0,401,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(795,26,'srn',0,402,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(796,26,'srp',0,403,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(797,26,'srr',0,404,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(798,26,'ssa',0,405,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(799,26,'ssw',0,406,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(800,26,'suk',0,407,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(801,26,'sun',0,408,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(802,26,'sus',0,409,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(803,26,'sux',0,410,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(804,26,'swa',0,411,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(805,26,'swe',0,412,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(806,26,'syc',0,413,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(807,26,'syr',0,414,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(808,26,'tah',0,415,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(809,26,'tai',0,416,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(810,26,'tam',0,417,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(811,26,'tat',0,418,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(812,26,'tel',0,419,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(813,26,'tem',0,420,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(814,26,'ter',0,421,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(815,26,'tet',0,422,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(816,26,'tgk',0,423,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(817,26,'tgl',0,424,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(818,26,'tha',0,425,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(819,26,'tib',0,426,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(820,26,'tig',0,427,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(821,26,'tir',0,428,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(822,26,'tiv',0,429,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(823,26,'tkl',0,430,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(824,26,'tlh',0,431,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(825,26,'tli',0,432,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(826,26,'tmh',0,433,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(827,26,'tog',0,434,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(828,26,'ton',0,435,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(829,26,'tpi',0,436,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(830,26,'tsi',0,437,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(831,26,'tsn',0,438,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(832,26,'tso',0,439,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(833,26,'tuk',0,440,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(834,26,'tum',0,441,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(835,26,'tup',0,442,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(836,26,'tur',0,443,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(837,26,'tut',0,444,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(838,26,'tvl',0,445,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(839,26,'twi',0,446,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(840,26,'tyv',0,447,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(841,26,'udm',0,448,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(842,26,'uga',0,449,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(843,26,'uig',0,450,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(844,26,'ukr',0,451,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(845,26,'umb',0,452,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(846,26,'und',0,453,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(847,26,'urd',0,454,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(848,26,'uzb',0,455,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(849,26,'vai',0,456,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(850,26,'ven',0,457,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(851,26,'vie',0,458,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(852,26,'vol',0,459,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(853,26,'vot',0,460,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(854,26,'wak',0,461,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(855,26,'wal',0,462,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(856,26,'war',0,463,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(857,26,'was',0,464,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(858,26,'wel',0,465,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(859,26,'wen',0,466,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(860,26,'wln',0,467,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(861,26,'wol',0,468,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(862,26,'xal',0,469,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(863,26,'xho',0,470,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(864,26,'yao',0,471,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(865,26,'yap',0,472,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(866,26,'yid',0,473,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(867,26,'yor',0,474,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(868,26,'ypk',0,475,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(869,26,'zap',0,476,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(870,26,'zbl',0,477,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(871,26,'zen',0,478,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(872,26,'zha',0,479,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(873,26,'znd',0,480,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(874,26,'zul',0,481,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(875,26,'zun',0,482,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(876,26,'zxx',0,483,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(877,26,'zza',0,484,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(878,27,'creator',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(879,27,'source',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(880,27,'subject',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(881,28,'is_associative_with',1,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(882,29,'is_earlier_form_of',1,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(883,29,'is_later_form_of',1,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(884,30,'is_parent_of',1,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(885,30,'is_child_of',1,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(886,31,'is_subordinate_to',1,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(887,31,'is_superior_of',1,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(888,32,'class',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(889,32,'collection',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(890,32,'file',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(891,32,'fonds',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(892,32,'item',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(893,32,'otherlevel',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(894,32,'recordgrp',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(895,32,'series',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(896,32,'subfonds',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(897,32,'subgrp',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(898,32,'subseries',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(899,33,'current',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(900,33,'previous',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(901,34,'single',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(902,34,'bulk',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(903,34,'inclusive',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(904,35,'broadcast',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(905,35,'copyright',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(906,35,'creation',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(907,35,'deaccession',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(908,35,'digitized',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(909,35,'event',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(910,35,'issued',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(911,35,'modified',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(912,35,'publication',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(913,35,'agent_relation',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(914,35,'other',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(915,35,'usage',0,13,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(916,35,'existence',1,7,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(917,35,'record_keeping',0,12,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(918,36,'approximate',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(919,36,'inferred',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(920,36,'questionable',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(921,37,'whole',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(922,37,'part',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(923,38,'whole',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(924,38,'part',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(925,39,'none',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(926,39,'other',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(927,39,'onLoad',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(928,39,'onRequest',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(929,40,'new',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(930,40,'replace',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(931,40,'embed',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(932,40,'other',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(933,40,'none',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(934,41,'aiff',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(935,41,'avi',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(936,41,'gif',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(937,41,'jpeg',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(938,41,'mp3',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(939,41,'pdf',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(940,41,'tiff',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(941,41,'txt',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(942,42,'conservation',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(943,42,'exhibit',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(944,42,'loan',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(945,42,'reading_room',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(946,43,'inverted',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(947,43,'direct',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(948,44,'summary',0,17,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(949,44,'bioghist',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(950,44,'accessrestrict',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(951,44,'userestrict',0,18,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(952,44,'custodhist',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(953,44,'dimensions',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(954,44,'edition',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(955,44,'extent',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(956,44,'altformavail',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(957,44,'originalsloc',0,12,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(958,44,'note',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(959,44,'acqinfo',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(960,44,'inscription',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(962,44,'legalstatus',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(963,44,'physdesc',0,13,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(964,44,'prefercite',0,14,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(965,44,'processinfo',0,15,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(966,44,'relatedmaterial',0,16,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(967,45,'accruals',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(968,45,'appraisal',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(969,45,'arrangement',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(970,45,'bioghist',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(971,45,'accessrestrict',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(972,45,'userestrict',0,20,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(973,45,'custodhist',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(974,45,'dimensions',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(975,45,'altformavail',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(976,45,'originalsloc',0,12,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(977,45,'fileplan',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(978,45,'odd',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(979,45,'acqinfo',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(980,45,'legalstatus',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(981,45,'otherfindaid',0,13,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(982,45,'phystech',0,14,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(983,45,'prefercite',0,15,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(984,45,'processinfo',0,16,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(985,45,'relatedmaterial',0,17,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(986,45,'scopecontent',0,18,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(987,45,'separatedmaterial',0,19,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(988,46,'arabic',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(989,46,'loweralpha',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(990,46,'upperalpha',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(991,46,'lowerroman',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(992,46,'upperroman',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(993,47,'abstract',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(994,47,'physdesc',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(996,47,'physloc',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(997,47,'materialspec',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(998,47,'physfacet',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(999,48,'bibliography',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1000,49,'index',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1001,50,'name',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1002,50,'person',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1003,50,'family',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1004,50,'corporate_entity',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1005,50,'subject',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1006,50,'function',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1007,50,'occupation',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1008,50,'title',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1009,50,'geographic_name',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1010,50,'genre_form',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1011,51,'AF',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1012,51,'AX',0,14,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1013,51,'AL',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1014,51,'DZ',0,61,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1015,51,'AS',0,10,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1016,51,'AD',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1017,51,'AO',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1018,51,'AI',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1019,51,'AQ',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1020,51,'AG',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1021,51,'AR',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1022,51,'AM',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1023,51,'AW',0,13,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1024,51,'AU',0,12,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1025,51,'AT',0,11,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1026,51,'AZ',0,15,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1027,51,'BS',0,31,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1028,51,'BH',0,22,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1029,51,'BD',0,18,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1030,51,'BB',0,17,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1031,51,'BY',0,35,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1032,51,'BE',0,19,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1033,51,'BZ',0,36,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1034,51,'BJ',0,24,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1035,51,'BM',0,26,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1036,51,'BT',0,32,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1037,51,'BO',0,28,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1038,51,'BQ',0,29,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1039,51,'BA',0,16,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1040,51,'BW',0,34,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1041,51,'BV',0,33,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1042,51,'BR',0,30,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1043,51,'IO',0,105,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1044,51,'BN',0,27,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1045,51,'BG',0,21,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1046,51,'BF',0,20,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1047,51,'BI',0,23,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1048,51,'KH',0,116,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1049,51,'CM',0,46,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1050,51,'CA',0,37,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1051,51,'CV',0,51,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1052,51,'KY',0,123,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1053,51,'CF',0,40,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1054,51,'TD',0,214,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1055,51,'CL',0,45,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1056,51,'CN',0,47,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1057,51,'CX',0,53,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1058,51,'CC',0,38,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1059,51,'CO',0,48,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1060,51,'KM',0,118,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1061,51,'CG',0,41,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1062,51,'CD',0,39,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1063,51,'CK',0,44,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1064,51,'CR',0,49,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1065,51,'CI',0,43,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1066,51,'HR',0,97,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1067,51,'CU',0,50,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1068,51,'CW',0,52,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1069,51,'CY',0,54,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1070,51,'CZ',0,55,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1071,51,'DK',0,58,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1072,51,'DJ',0,57,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1073,51,'DM',0,59,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1074,51,'DO',0,60,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1075,51,'EC',0,62,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1076,51,'EG',0,64,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1077,51,'SV',0,209,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1078,51,'GQ',0,87,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1079,51,'ER',0,66,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1080,51,'EE',0,63,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1081,51,'ET',0,68,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1082,51,'FK',0,71,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1083,51,'FO',0,73,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1084,51,'FJ',0,70,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1085,51,'FI',0,69,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1086,51,'FR',0,74,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1087,51,'GF',0,79,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1088,51,'PF',0,174,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1089,51,'TF',0,215,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1090,51,'GA',0,75,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1091,51,'GM',0,84,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1092,51,'GE',0,78,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1093,51,'DE',0,56,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1094,51,'GH',0,81,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1095,51,'GI',0,82,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1096,51,'GR',0,88,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1097,51,'GL',0,83,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1098,51,'GD',0,77,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1099,51,'GP',0,86,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1100,51,'GU',0,91,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1101,51,'GT',0,90,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1102,51,'GG',0,80,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1103,51,'GN',0,85,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1104,51,'GW',0,92,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1105,51,'GY',0,93,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1106,51,'HT',0,98,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1107,51,'HM',0,95,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1108,51,'VA',0,235,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1109,51,'HN',0,96,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1110,51,'HK',0,94,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1111,51,'HU',0,99,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1112,51,'IS',0,108,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1113,51,'IN',0,104,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1114,51,'ID',0,100,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1115,51,'IR',0,107,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1116,51,'IQ',0,106,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1117,51,'IE',0,101,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1118,51,'IM',0,103,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1119,51,'IL',0,102,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1120,51,'IT',0,109,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1121,51,'JM',0,111,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1122,51,'JP',0,113,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1123,51,'JE',0,110,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1124,51,'JO',0,112,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1125,51,'KZ',0,124,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1126,51,'KE',0,114,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1127,51,'KI',0,117,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1128,51,'KP',0,120,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1129,51,'KR',0,121,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1130,51,'KW',0,122,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1131,51,'KG',0,115,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1132,51,'LA',0,125,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1133,51,'LV',0,134,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1134,51,'LB',0,126,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1135,51,'LS',0,131,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1136,51,'LR',0,130,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1137,51,'LY',0,135,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1138,51,'LI',0,128,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1139,51,'LT',0,132,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1140,51,'LU',0,133,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1141,51,'MO',0,147,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1142,51,'MK',0,143,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1143,51,'MG',0,141,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1144,51,'MW',0,155,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1145,51,'MY',0,157,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1146,51,'MV',0,154,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1147,51,'ML',0,144,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1148,51,'MT',0,152,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1149,51,'MH',0,142,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1150,51,'MQ',0,149,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1151,51,'MR',0,150,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1152,51,'MU',0,153,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1153,51,'YT',0,245,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1154,51,'MX',0,156,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1155,51,'FM',0,72,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1156,51,'MD',0,138,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1157,51,'MC',0,137,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1158,51,'MN',0,146,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1159,51,'ME',0,139,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1160,51,'MS',0,151,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1161,51,'MA',0,136,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1162,51,'MZ',0,158,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1163,51,'MM',0,145,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1164,51,'NA',0,159,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1165,51,'NR',0,168,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1166,51,'NP',0,167,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1167,51,'NL',0,165,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1168,51,'NC',0,160,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1169,51,'NZ',0,170,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1170,51,'NI',0,164,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1171,51,'NE',0,161,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1172,51,'NG',0,163,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1173,51,'NU',0,169,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1174,51,'NF',0,162,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1175,51,'MP',0,148,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1176,51,'NO',0,166,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1177,51,'OM',0,171,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1178,51,'PK',0,177,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1179,51,'PW',0,184,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1180,51,'PS',0,182,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1181,51,'PA',0,172,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1182,51,'PG',0,175,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1183,51,'PY',0,185,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1184,51,'PE',0,173,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1185,51,'PH',0,176,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1186,51,'PN',0,180,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1187,51,'PL',0,178,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1188,51,'PT',0,183,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1189,51,'PR',0,181,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1190,51,'QA',0,186,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1191,51,'RE',0,187,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1192,51,'RO',0,188,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1193,51,'RU',0,190,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1194,51,'RW',0,191,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1195,51,'BL',0,25,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1196,51,'SH',0,198,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1197,51,'KN',0,119,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1198,51,'LC',0,127,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1199,51,'MF',0,140,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1200,51,'PM',0,179,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1201,51,'VC',0,236,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1202,51,'WS',0,243,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1203,51,'SM',0,203,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1204,51,'ST',0,208,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1205,51,'SA',0,192,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1206,51,'SN',0,204,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1207,51,'RS',0,189,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1208,51,'SC',0,194,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1209,51,'SL',0,202,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1210,51,'SG',0,197,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1211,51,'SX',0,210,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1212,51,'SK',0,201,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1213,51,'SI',0,199,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1214,51,'SB',0,193,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1215,51,'SO',0,205,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1216,51,'ZA',0,246,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1217,51,'GS',0,89,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1218,51,'SS',0,207,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1219,51,'ES',0,67,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1220,51,'LK',0,129,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1221,51,'SD',0,195,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1222,51,'SR',0,206,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1223,51,'SJ',0,200,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1224,51,'SZ',0,212,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1225,51,'SE',0,196,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1226,51,'CH',0,42,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1227,51,'SY',0,211,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1228,51,'TW',0,227,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1229,51,'TJ',0,218,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1230,51,'TZ',0,228,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1231,51,'TH',0,217,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1232,51,'TL',0,220,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1233,51,'TG',0,216,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1234,51,'TK',0,219,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1235,51,'TO',0,223,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1236,51,'TT',0,225,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1237,51,'TN',0,222,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1238,51,'TR',0,224,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1239,51,'TM',0,221,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1240,51,'TC',0,213,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1241,51,'TV',0,226,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1242,51,'UG',0,230,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1243,51,'UA',0,229,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1244,51,'AE',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1245,51,'GB',0,76,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1246,51,'US',0,232,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1247,51,'UM',0,231,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1248,51,'UY',0,233,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1249,51,'UZ',0,234,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1250,51,'VU',0,241,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1251,51,'VE',0,237,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1252,51,'VN',0,240,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1253,51,'VG',0,238,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1254,51,'VI',0,239,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1255,51,'WF',0,242,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1256,51,'EH',0,65,0,0,1,NULL,NULL,'2026-02-27 23:16:46','2026-02-27 23:16:46','2026-02-27 23:16:46'),(1257,51,'YE',0,244,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1258,51,'ZM',0,247,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1259,51,'ZW',0,248,0,0,1,NULL,NULL,'2026-02-27 23:16:47','2026-02-27 23:16:47','2026-02-27 23:16:47'),(1260,52,'copyright',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1261,52,'license',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1262,52,'statute',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1263,52,'other',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1264,53,'copyrighted',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1265,53,'public_domain',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1266,53,'unknown',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1267,54,'cultural_context',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1268,54,'function',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1269,54,'geographic',0,3,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1270,54,'genre_form',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1271,54,'occupation',0,4,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1272,54,'style_period',0,5,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1273,54,'technique',0,6,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1274,54,'temporal',0,7,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1275,54,'topical',0,8,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1276,54,'uniform_title',0,9,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1277,55,'novalue',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1278,56,'novalue',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1279,57,'novalue',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1280,58,'novalue',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1281,34,'range',0,2,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1282,59,'has_part',0,1,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1283,59,'forms_part_of',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1284,60,'part',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1285,61,'sibling_of',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1286,62,'bound_with',0,0,0,0,1,NULL,NULL,'2026-02-27 23:16:48','2026-02-27 23:16:48','2026-02-27 23:16:48'),(1290,1,'abr',0,226,0,0,1,NULL,NULL,NULL,NULL,NULL),(1291,1,'adi',0,227,0,0,1,NULL,NULL,NULL,NULL,NULL),(1292,1,'ape',0,228,0,0,1,NULL,NULL,NULL,NULL,NULL),(1293,1,'apl',0,229,0,0,1,NULL,NULL,NULL,NULL,NULL),(1294,1,'ato',0,230,0,0,1,NULL,NULL,NULL,NULL,NULL),(1295,1,'brd',0,231,0,0,1,NULL,NULL,NULL,NULL,NULL),(1296,1,'brl',0,232,0,0,1,NULL,NULL,NULL,NULL,NULL),(1297,1,'cas',0,233,0,0,1,NULL,NULL,NULL,NULL,NULL),(1298,1,'cor',0,234,0,0,1,NULL,NULL,NULL,NULL,NULL),(1299,1,'cou',0,235,0,0,1,NULL,NULL,NULL,NULL,NULL),(1300,1,'crt',0,236,0,0,1,NULL,NULL,NULL,NULL,NULL),(1301,1,'dgs',0,237,0,0,1,NULL,NULL,NULL,NULL,NULL),(1302,1,'edc',0,238,0,0,1,NULL,NULL,NULL,NULL,NULL),(1303,1,'edm',0,239,0,0,1,NULL,NULL,NULL,NULL,NULL),(1304,1,'enj',0,240,0,0,1,NULL,NULL,NULL,NULL,NULL),(1305,1,'fds',0,241,0,0,1,NULL,NULL,NULL,NULL,NULL),(1306,1,'fmd',0,242,0,0,1,NULL,NULL,NULL,NULL,NULL),(1307,1,'fmk',0,243,0,0,1,NULL,NULL,NULL,NULL,NULL),(1308,1,'fmp',0,244,0,0,1,NULL,NULL,NULL,NULL,NULL),(1309,1,'-grt',0,245,0,0,1,NULL,NULL,NULL,NULL,NULL),(1310,1,'his',0,246,0,0,1,NULL,NULL,NULL,NULL,NULL),(1311,1,'isb',0,247,0,0,1,NULL,NULL,NULL,NULL,NULL),(1312,1,'jud',0,248,0,0,1,NULL,NULL,NULL,NULL,NULL),(1313,1,'jug',0,249,0,0,1,NULL,NULL,NULL,NULL,NULL),(1314,1,'med',0,250,0,0,1,NULL,NULL,NULL,NULL,NULL),(1315,1,'mtk',0,251,0,0,1,NULL,NULL,NULL,NULL,NULL),(1316,1,'osp',0,252,0,0,1,NULL,NULL,NULL,NULL,NULL),(1317,1,'pan',0,253,0,0,1,NULL,NULL,NULL,NULL,NULL),(1318,1,'pra',0,254,0,0,1,NULL,NULL,NULL,NULL,NULL),(1319,1,'pre',0,255,0,0,1,NULL,NULL,NULL,NULL,NULL),(1320,1,'prn',0,256,0,0,1,NULL,NULL,NULL,NULL,NULL),(1321,1,'prs',0,257,0,0,1,NULL,NULL,NULL,NULL,NULL),(1322,1,'rdd',0,258,0,0,1,NULL,NULL,NULL,NULL,NULL),(1323,1,'rpc',0,259,0,0,1,NULL,NULL,NULL,NULL,NULL),(1324,1,'rsr',0,260,0,0,1,NULL,NULL,NULL,NULL,NULL),(1325,1,'sgd',0,261,0,0,1,NULL,NULL,NULL,NULL,NULL),(1326,1,'sll',0,262,0,0,1,NULL,NULL,NULL,NULL,NULL),(1327,1,'tld',0,263,0,0,1,NULL,NULL,NULL,NULL,NULL),(1328,1,'tlp',0,264,0,0,1,NULL,NULL,NULL,NULL,NULL),(1329,1,'vac',0,265,0,0,1,NULL,NULL,NULL,NULL,NULL),(1330,1,'wac',0,266,0,0,1,NULL,NULL,NULL,NULL,NULL),(1331,1,'wal',0,267,0,0,1,NULL,NULL,NULL,NULL,NULL),(1332,1,'wat',0,268,0,0,1,NULL,NULL,NULL,NULL,NULL),(1333,1,'win',0,269,0,0,1,NULL,NULL,NULL,NULL,NULL),(1334,1,'wpr',0,270,0,0,1,NULL,NULL,NULL,NULL,NULL),(1335,1,'wst',0,271,0,0,1,NULL,NULL,NULL,NULL,NULL),(1336,64,'business',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1337,64,'home',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1338,64,'cell',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1339,64,'fax',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1340,15,'processing_started',0,33,0,0,1,NULL,NULL,NULL,NULL,NULL),(1341,15,'processing_completed',0,34,0,0,1,NULL,NULL,NULL,NULL,NULL),(1342,15,'processing_in_progress',0,35,0,0,1,NULL,NULL,NULL,NULL,NULL),(1343,15,'processing_new',0,36,0,0,1,NULL,NULL,NULL,NULL,NULL),(1344,65,'RestrictedSpecColl',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1345,65,'RestrictedCurApprSpecColl',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1346,65,'RestrictedFragileSpecColl',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1347,65,'InProcessSpecColl',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1348,65,'ColdStorageBrbl',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1349,66,'inches',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1350,66,'feet',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1351,66,'yards',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1352,66,'millimeters',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1353,66,'centimeters',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1354,66,'meters',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1357,67,'av_materials',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1358,67,'arrivals',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1359,67,'shared',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1360,68,'delete',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1361,68,'disseminate',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1362,68,'migrate',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1363,68,'modify',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1364,68,'replicate',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1365,68,'use',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1366,69,'allow',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1367,69,'disallow',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1368,69,'conditional',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1369,70,'permissions',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1370,70,'restrictions',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1371,70,'extension',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1372,70,'expiration',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1373,70,'additional_information',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1374,71,'materials',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1375,71,'type_note',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1376,71,'additional_information',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1377,72,'agrovoc',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1378,72,'allmovie',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1379,72,'allmusic',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1380,72,'allocine',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1381,72,'amnbo',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1382,72,'ansi',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1383,72,'artsy',0,6,0,0,1,NULL,NULL,NULL,NULL,NULL),(1384,72,'bdusc',0,7,0,0,1,NULL,NULL,NULL,NULL,NULL),(1385,72,'bfi',0,8,0,0,1,NULL,NULL,NULL,NULL,NULL),(1386,72,'bnfcg',0,9,0,0,1,NULL,NULL,NULL,NULL,NULL),(1387,72,'cantic',0,10,0,0,1,NULL,NULL,NULL,NULL,NULL),(1388,72,'cgndb',0,11,0,0,1,NULL,NULL,NULL,NULL,NULL),(1389,72,'danacode',0,12,0,0,1,NULL,NULL,NULL,NULL,NULL),(1390,72,'datoses',0,13,0,0,1,NULL,NULL,NULL,NULL,NULL),(1391,72,'discogs',0,14,0,0,1,NULL,NULL,NULL,NULL,NULL),(1392,72,'dkfilm',0,15,0,0,1,NULL,NULL,NULL,NULL,NULL),(1393,72,'doi',0,16,0,0,1,NULL,NULL,NULL,NULL,NULL),(1394,72,'ean',0,17,0,0,1,NULL,NULL,NULL,NULL,NULL),(1395,72,'eidr',0,18,0,0,1,NULL,NULL,NULL,NULL,NULL),(1396,72,'fast',0,19,0,0,1,NULL,NULL,NULL,NULL,NULL),(1397,72,'filmport',0,20,0,0,1,NULL,NULL,NULL,NULL,NULL),(1398,72,'findagr',0,21,0,0,1,NULL,NULL,NULL,NULL,NULL),(1399,72,'freebase',0,22,0,0,1,NULL,NULL,NULL,NULL,NULL),(1400,72,'gec',0,23,0,0,1,NULL,NULL,NULL,NULL,NULL),(1401,72,'geogndb',0,24,0,0,1,NULL,NULL,NULL,NULL,NULL),(1402,72,'geonames',0,25,0,0,1,NULL,NULL,NULL,NULL,NULL),(1403,72,'gettytgn',0,26,0,0,1,NULL,NULL,NULL,NULL,NULL),(1404,72,'gettyulan',0,27,0,0,1,NULL,NULL,NULL,NULL,NULL),(1405,72,'gnd',0,28,0,0,1,NULL,NULL,NULL,NULL,NULL),(1406,72,'gnis',0,29,0,0,1,NULL,NULL,NULL,NULL,NULL),(1407,72,'gtin-14',0,30,0,0,1,NULL,NULL,NULL,NULL,NULL),(1408,72,'hdl',0,31,0,0,1,NULL,NULL,NULL,NULL,NULL),(1409,72,'ibdb',0,32,0,0,1,NULL,NULL,NULL,NULL,NULL),(1410,72,'idref',0,33,0,0,1,NULL,NULL,NULL,NULL,NULL),(1411,72,'imdb',0,34,0,0,1,NULL,NULL,NULL,NULL,NULL),(1412,72,'isan',0,35,0,0,1,NULL,NULL,NULL,NULL,NULL),(1413,72,'isbn',0,36,0,0,1,NULL,NULL,NULL,NULL,NULL),(1414,72,'isbn-a',0,37,0,0,1,NULL,NULL,NULL,NULL,NULL),(1415,72,'isbnre',0,38,0,0,1,NULL,NULL,NULL,NULL,NULL),(1416,72,'isil',0,39,0,0,1,NULL,NULL,NULL,NULL,NULL),(1417,72,'ismn',0,40,0,0,1,NULL,NULL,NULL,NULL,NULL),(1418,72,'isni',0,41,0,0,1,NULL,NULL,NULL,NULL,NULL),(1419,72,'iso',0,42,0,0,1,NULL,NULL,NULL,NULL,NULL),(1420,72,'isrc',0,43,0,0,1,NULL,NULL,NULL,NULL,NULL),(1421,72,'issn',0,44,0,0,1,NULL,NULL,NULL,NULL,NULL),(1422,72,'issn-l',0,45,0,0,1,NULL,NULL,NULL,NULL,NULL),(1423,72,'issue-number',0,46,0,0,1,NULL,NULL,NULL,NULL,NULL),(1424,72,'istc',0,47,0,0,1,NULL,NULL,NULL,NULL,NULL),(1425,72,'iswc',0,48,0,0,1,NULL,NULL,NULL,NULL,NULL),(1426,72,'itar',0,49,0,0,1,NULL,NULL,NULL,NULL,NULL),(1427,72,'kinopo',0,50,0,0,1,NULL,NULL,NULL,NULL,NULL),(1428,72,'lccn',0,51,0,0,1,NULL,NULL,NULL,NULL,NULL),(1429,72,'lcmd',0,52,0,0,1,NULL,NULL,NULL,NULL,NULL),(1430,72,'lcmpt',0,53,0,0,1,NULL,NULL,NULL,NULL,NULL),(1431,72,'libaus',0,54,0,0,1,NULL,NULL,NULL,NULL,NULL),(1432,72,'local',0,55,0,0,1,NULL,NULL,NULL,NULL,NULL),(1433,72,'matrix-number',0,56,0,0,1,NULL,NULL,NULL,NULL,NULL),(1434,72,'moma',0,57,0,0,1,NULL,NULL,NULL,NULL,NULL),(1435,72,'munzing',0,58,0,0,1,NULL,NULL,NULL,NULL,NULL),(1436,72,'music-plate',0,59,0,0,1,NULL,NULL,NULL,NULL,NULL),(1437,72,'music-publisher',0,60,0,0,1,NULL,NULL,NULL,NULL,NULL),(1438,72,'musicb',0,61,0,0,1,NULL,NULL,NULL,NULL,NULL),(1439,72,'natgazfid',0,62,0,0,1,NULL,NULL,NULL,NULL,NULL),(1440,72,'nga',0,63,0,0,1,NULL,NULL,NULL,NULL,NULL),(1441,72,'nipo',0,64,0,0,1,NULL,NULL,NULL,NULL,NULL),(1442,72,'nndb',0,65,0,0,1,NULL,NULL,NULL,NULL,NULL),(1443,72,'npg',0,66,0,0,1,NULL,NULL,NULL,NULL,NULL),(1444,72,'odnb',0,67,0,0,1,NULL,NULL,NULL,NULL,NULL),(1445,72,'opensm',0,68,0,0,1,NULL,NULL,NULL,NULL,NULL),(1446,72,'orcid',0,69,0,0,1,NULL,NULL,NULL,NULL,NULL),(1447,72,'oxforddnb',0,70,0,0,1,NULL,NULL,NULL,NULL,NULL),(1448,72,'porthu',0,71,0,0,1,NULL,NULL,NULL,NULL,NULL),(1449,72,'rbmsbt',0,72,0,0,1,NULL,NULL,NULL,NULL,NULL),(1450,72,'rbmsgt',0,73,0,0,1,NULL,NULL,NULL,NULL,NULL),(1451,72,'rbmspe',0,74,0,0,1,NULL,NULL,NULL,NULL,NULL),(1452,72,'rbmsppe',0,75,0,0,1,NULL,NULL,NULL,NULL,NULL),(1453,72,'rbmspt',0,76,0,0,1,NULL,NULL,NULL,NULL,NULL),(1454,72,'rbmsrd',0,77,0,0,1,NULL,NULL,NULL,NULL,NULL),(1455,72,'rbmste',0,78,0,0,1,NULL,NULL,NULL,NULL,NULL),(1456,72,'rid',0,79,0,0,1,NULL,NULL,NULL,NULL,NULL),(1457,72,'rkda',0,80,0,0,1,NULL,NULL,NULL,NULL,NULL),(1458,72,'saam',0,81,0,0,1,NULL,NULL,NULL,NULL,NULL),(1459,72,'scholaru',0,82,0,0,1,NULL,NULL,NULL,NULL,NULL),(1460,72,'scope',0,83,0,0,1,NULL,NULL,NULL,NULL,NULL),(1461,72,'scopus',0,84,0,0,1,NULL,NULL,NULL,NULL,NULL),(1462,72,'sici',0,85,0,0,1,NULL,NULL,NULL,NULL,NULL),(1463,72,'spotify',0,86,0,0,1,NULL,NULL,NULL,NULL,NULL),(1464,72,'sprfbsb',0,87,0,0,1,NULL,NULL,NULL,NULL,NULL),(1465,72,'sprfbsk',0,88,0,0,1,NULL,NULL,NULL,NULL,NULL),(1466,72,'sprfcbb',0,89,0,0,1,NULL,NULL,NULL,NULL,NULL),(1467,72,'sprfcfb',0,90,0,0,1,NULL,NULL,NULL,NULL,NULL),(1468,72,'sprfhoc',0,91,0,0,1,NULL,NULL,NULL,NULL,NULL),(1469,72,'sprfoly',0,92,0,0,1,NULL,NULL,NULL,NULL,NULL),(1470,72,'sprfpfb',0,93,0,0,1,NULL,NULL,NULL,NULL,NULL),(1471,72,'stock-number',0,94,0,0,1,NULL,NULL,NULL,NULL,NULL),(1472,72,'strn',0,95,0,0,1,NULL,NULL,NULL,NULL,NULL),(1473,72,'svfilm',0,96,0,0,1,NULL,NULL,NULL,NULL,NULL),(1474,72,'tatearid',0,97,0,0,1,NULL,NULL,NULL,NULL,NULL),(1475,72,'theatr',0,98,0,0,1,NULL,NULL,NULL,NULL,NULL),(1476,72,'trove',0,99,0,0,1,NULL,NULL,NULL,NULL,NULL),(1477,72,'upc',0,100,0,0,1,NULL,NULL,NULL,NULL,NULL),(1478,72,'uri',0,101,0,0,1,NULL,NULL,NULL,NULL,NULL),(1479,72,'urn',0,102,0,0,1,NULL,NULL,NULL,NULL,NULL),(1480,72,'viaf',0,103,0,0,1,NULL,NULL,NULL,NULL,NULL),(1481,72,'videorecording-identifier',0,104,0,0,1,NULL,NULL,NULL,NULL,NULL),(1482,72,'wikidata',0,105,0,0,1,NULL,NULL,NULL,NULL,NULL),(1483,72,'wndla',0,106,0,0,1,NULL,NULL,NULL,NULL,NULL),(1484,73,'donor',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1485,73,'policy',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1486,15,'request',1,37,0,0,1,NULL,NULL,'2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51'),(1487,18,'cancelled',1,3,0,0,1,NULL,NULL,'2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51'),(1488,18,'fulfilled',1,4,0,0,1,NULL,NULL,'2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51'),(1489,18,'pending',1,5,0,0,1,NULL,NULL,'2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51'),(1490,3,'requester',1,6,0,0,1,NULL,NULL,'2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51'),(1491,2,'context',1,3,0,0,1,NULL,NULL,'2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51'),(1492,2,'requested',1,4,0,0,1,NULL,NULL,'2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51'),(1493,26,'cnr',0,485,0,0,1,NULL,NULL,NULL,NULL,NULL),(1494,26,'zgh',0,486,0,0,1,NULL,NULL,NULL,NULL,NULL),(1495,74,'Adlm',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1496,74,'Afak',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1497,74,'Aghb',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1498,74,'Ahom',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1499,74,'Arab',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1500,74,'Aran',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1501,74,'Armi',0,6,0,0,1,NULL,NULL,NULL,NULL,NULL),(1502,74,'Armn',0,7,0,0,1,NULL,NULL,NULL,NULL,NULL),(1503,74,'Avst',0,8,0,0,1,NULL,NULL,NULL,NULL,NULL),(1504,74,'Bali',0,9,0,0,1,NULL,NULL,NULL,NULL,NULL),(1505,74,'Bamu',0,10,0,0,1,NULL,NULL,NULL,NULL,NULL),(1506,74,'Bass',0,11,0,0,1,NULL,NULL,NULL,NULL,NULL),(1507,74,'Batk',0,12,0,0,1,NULL,NULL,NULL,NULL,NULL),(1508,74,'Beng',0,13,0,0,1,NULL,NULL,NULL,NULL,NULL),(1509,74,'Bhks',0,14,0,0,1,NULL,NULL,NULL,NULL,NULL),(1510,74,'Blis',0,15,0,0,1,NULL,NULL,NULL,NULL,NULL),(1511,74,'Bopo',0,16,0,0,1,NULL,NULL,NULL,NULL,NULL),(1512,74,'Brah',0,17,0,0,1,NULL,NULL,NULL,NULL,NULL),(1513,74,'Brai',0,18,0,0,1,NULL,NULL,NULL,NULL,NULL),(1514,74,'Bugi',0,19,0,0,1,NULL,NULL,NULL,NULL,NULL),(1515,74,'Buhd',0,20,0,0,1,NULL,NULL,NULL,NULL,NULL),(1516,74,'Cakm',0,21,0,0,1,NULL,NULL,NULL,NULL,NULL),(1517,74,'Cans',0,22,0,0,1,NULL,NULL,NULL,NULL,NULL),(1518,74,'Cari',0,23,0,0,1,NULL,NULL,NULL,NULL,NULL),(1519,74,'Cham',0,24,0,0,1,NULL,NULL,NULL,NULL,NULL),(1520,74,'Cher',0,25,0,0,1,NULL,NULL,NULL,NULL,NULL),(1521,74,'Cirt',0,26,0,0,1,NULL,NULL,NULL,NULL,NULL),(1522,74,'Copt',0,27,0,0,1,NULL,NULL,NULL,NULL,NULL),(1523,74,'Cpmn',0,28,0,0,1,NULL,NULL,NULL,NULL,NULL),(1524,74,'Cprt',0,29,0,0,1,NULL,NULL,NULL,NULL,NULL),(1525,74,'Cyrl',0,30,0,0,1,NULL,NULL,NULL,NULL,NULL),(1526,74,'Cyrs',0,31,0,0,1,NULL,NULL,NULL,NULL,NULL),(1527,74,'Deva',0,32,0,0,1,NULL,NULL,NULL,NULL,NULL),(1528,74,'Dogr',0,33,0,0,1,NULL,NULL,NULL,NULL,NULL),(1529,74,'Dsrt',0,34,0,0,1,NULL,NULL,NULL,NULL,NULL),(1530,74,'Dupl',0,35,0,0,1,NULL,NULL,NULL,NULL,NULL),(1531,74,'Egyd',0,36,0,0,1,NULL,NULL,NULL,NULL,NULL),(1532,74,'Egyh',0,37,0,0,1,NULL,NULL,NULL,NULL,NULL),(1533,74,'Egyp',0,38,0,0,1,NULL,NULL,NULL,NULL,NULL),(1534,74,'Elba',0,39,0,0,1,NULL,NULL,NULL,NULL,NULL),(1535,74,'Elym',0,40,0,0,1,NULL,NULL,NULL,NULL,NULL),(1536,74,'Ethi',0,41,0,0,1,NULL,NULL,NULL,NULL,NULL),(1537,74,'Geok',0,42,0,0,1,NULL,NULL,NULL,NULL,NULL),(1538,74,'Geor',0,43,0,0,1,NULL,NULL,NULL,NULL,NULL),(1539,74,'Glag',0,44,0,0,1,NULL,NULL,NULL,NULL,NULL),(1540,74,'Gong',0,45,0,0,1,NULL,NULL,NULL,NULL,NULL),(1541,74,'Gonm',0,46,0,0,1,NULL,NULL,NULL,NULL,NULL),(1542,74,'Goth',0,47,0,0,1,NULL,NULL,NULL,NULL,NULL),(1543,74,'Gran',0,48,0,0,1,NULL,NULL,NULL,NULL,NULL),(1544,74,'Grek',0,49,0,0,1,NULL,NULL,NULL,NULL,NULL),(1545,74,'Gujr',0,50,0,0,1,NULL,NULL,NULL,NULL,NULL),(1546,74,'Guru',0,51,0,0,1,NULL,NULL,NULL,NULL,NULL),(1547,74,'Hanb',0,52,0,0,1,NULL,NULL,NULL,NULL,NULL),(1548,74,'Hang',0,53,0,0,1,NULL,NULL,NULL,NULL,NULL),(1549,74,'Hani',0,54,0,0,1,NULL,NULL,NULL,NULL,NULL),(1550,74,'Hano',0,55,0,0,1,NULL,NULL,NULL,NULL,NULL),(1551,74,'Hans',0,56,0,0,1,NULL,NULL,NULL,NULL,NULL),(1552,74,'Hant',0,57,0,0,1,NULL,NULL,NULL,NULL,NULL),(1553,74,'Hatr',0,58,0,0,1,NULL,NULL,NULL,NULL,NULL),(1554,74,'Hebr',0,59,0,0,1,NULL,NULL,NULL,NULL,NULL),(1555,74,'Hira',0,60,0,0,1,NULL,NULL,NULL,NULL,NULL),(1556,74,'Hluw',0,61,0,0,1,NULL,NULL,NULL,NULL,NULL),(1557,74,'Hmng',0,62,0,0,1,NULL,NULL,NULL,NULL,NULL),(1558,74,'Hmnp',0,63,0,0,1,NULL,NULL,NULL,NULL,NULL),(1559,74,'Hrkt',0,64,0,0,1,NULL,NULL,NULL,NULL,NULL),(1560,74,'Hung',0,65,0,0,1,NULL,NULL,NULL,NULL,NULL),(1561,74,'Inds',0,66,0,0,1,NULL,NULL,NULL,NULL,NULL),(1562,74,'Ital',0,67,0,0,1,NULL,NULL,NULL,NULL,NULL),(1563,74,'Jamo',0,68,0,0,1,NULL,NULL,NULL,NULL,NULL),(1564,74,'Java',0,69,0,0,1,NULL,NULL,NULL,NULL,NULL),(1565,74,'Jpan',0,70,0,0,1,NULL,NULL,NULL,NULL,NULL),(1566,74,'Jurc',0,71,0,0,1,NULL,NULL,NULL,NULL,NULL),(1567,74,'Kali',0,72,0,0,1,NULL,NULL,NULL,NULL,NULL),(1568,74,'Kana',0,73,0,0,1,NULL,NULL,NULL,NULL,NULL),(1569,74,'Khar',0,74,0,0,1,NULL,NULL,NULL,NULL,NULL),(1570,74,'Khmr',0,75,0,0,1,NULL,NULL,NULL,NULL,NULL),(1571,74,'Khoj',0,76,0,0,1,NULL,NULL,NULL,NULL,NULL),(1572,74,'Kitl',0,77,0,0,1,NULL,NULL,NULL,NULL,NULL),(1573,74,'Kits',0,78,0,0,1,NULL,NULL,NULL,NULL,NULL),(1574,74,'Knda',0,79,0,0,1,NULL,NULL,NULL,NULL,NULL),(1575,74,'Kore',0,80,0,0,1,NULL,NULL,NULL,NULL,NULL),(1576,74,'Kpel',0,81,0,0,1,NULL,NULL,NULL,NULL,NULL),(1577,74,'Kthi',0,82,0,0,1,NULL,NULL,NULL,NULL,NULL),(1578,74,'Lana',0,83,0,0,1,NULL,NULL,NULL,NULL,NULL),(1579,74,'Laoo',0,84,0,0,1,NULL,NULL,NULL,NULL,NULL),(1580,74,'Latf',0,85,0,0,1,NULL,NULL,NULL,NULL,NULL),(1581,74,'Latg',0,86,0,0,1,NULL,NULL,NULL,NULL,NULL),(1582,74,'Latn',0,87,0,0,1,NULL,NULL,NULL,NULL,NULL),(1583,74,'Leke',0,88,0,0,1,NULL,NULL,NULL,NULL,NULL),(1584,74,'Lepc',0,89,0,0,1,NULL,NULL,NULL,NULL,NULL),(1585,74,'Limb',0,90,0,0,1,NULL,NULL,NULL,NULL,NULL),(1586,74,'Lina',0,91,0,0,1,NULL,NULL,NULL,NULL,NULL),(1587,74,'Linb',0,92,0,0,1,NULL,NULL,NULL,NULL,NULL),(1588,74,'Lisu',0,93,0,0,1,NULL,NULL,NULL,NULL,NULL),(1589,74,'Loma',0,94,0,0,1,NULL,NULL,NULL,NULL,NULL),(1590,74,'Lyci',0,95,0,0,1,NULL,NULL,NULL,NULL,NULL),(1591,74,'Lydi',0,96,0,0,1,NULL,NULL,NULL,NULL,NULL),(1592,74,'Mahj',0,97,0,0,1,NULL,NULL,NULL,NULL,NULL),(1593,74,'Maka',0,98,0,0,1,NULL,NULL,NULL,NULL,NULL),(1594,74,'Mand',0,99,0,0,1,NULL,NULL,NULL,NULL,NULL),(1595,74,'Mani',0,100,0,0,1,NULL,NULL,NULL,NULL,NULL),(1596,74,'Marc',0,101,0,0,1,NULL,NULL,NULL,NULL,NULL),(1597,74,'Maya',0,102,0,0,1,NULL,NULL,NULL,NULL,NULL),(1598,74,'Medf',0,103,0,0,1,NULL,NULL,NULL,NULL,NULL),(1599,74,'Mend',0,104,0,0,1,NULL,NULL,NULL,NULL,NULL),(1600,74,'Merc',0,105,0,0,1,NULL,NULL,NULL,NULL,NULL),(1601,74,'Mero',0,106,0,0,1,NULL,NULL,NULL,NULL,NULL),(1602,74,'Mlym',0,107,0,0,1,NULL,NULL,NULL,NULL,NULL),(1603,74,'Modi',0,108,0,0,1,NULL,NULL,NULL,NULL,NULL),(1604,74,'Mong',0,109,0,0,1,NULL,NULL,NULL,NULL,NULL),(1605,74,'Moon',0,110,0,0,1,NULL,NULL,NULL,NULL,NULL),(1606,74,'Mroo',0,111,0,0,1,NULL,NULL,NULL,NULL,NULL),(1607,74,'Mtei',0,112,0,0,1,NULL,NULL,NULL,NULL,NULL),(1608,74,'Mult',0,113,0,0,1,NULL,NULL,NULL,NULL,NULL),(1609,74,'Mymr',0,114,0,0,1,NULL,NULL,NULL,NULL,NULL),(1610,74,'Nand',0,115,0,0,1,NULL,NULL,NULL,NULL,NULL),(1611,74,'Narb',0,116,0,0,1,NULL,NULL,NULL,NULL,NULL),(1612,74,'Nbat',0,117,0,0,1,NULL,NULL,NULL,NULL,NULL),(1613,74,'Newa',0,118,0,0,1,NULL,NULL,NULL,NULL,NULL),(1614,74,'Nkdb',0,119,0,0,1,NULL,NULL,NULL,NULL,NULL),(1615,74,'Nkgb',0,120,0,0,1,NULL,NULL,NULL,NULL,NULL),(1616,74,'Nkoo',0,121,0,0,1,NULL,NULL,NULL,NULL,NULL),(1617,74,'Nshu',0,122,0,0,1,NULL,NULL,NULL,NULL,NULL),(1618,74,'Ogam',0,123,0,0,1,NULL,NULL,NULL,NULL,NULL),(1619,74,'Olck',0,124,0,0,1,NULL,NULL,NULL,NULL,NULL),(1620,74,'Orkh',0,125,0,0,1,NULL,NULL,NULL,NULL,NULL),(1621,74,'Orya',0,126,0,0,1,NULL,NULL,NULL,NULL,NULL),(1622,74,'Osge',0,127,0,0,1,NULL,NULL,NULL,NULL,NULL),(1623,74,'Osma',0,128,0,0,1,NULL,NULL,NULL,NULL,NULL),(1624,74,'Palm',0,129,0,0,1,NULL,NULL,NULL,NULL,NULL),(1625,74,'Pauc',0,130,0,0,1,NULL,NULL,NULL,NULL,NULL),(1626,74,'Perm',0,131,0,0,1,NULL,NULL,NULL,NULL,NULL),(1627,74,'Phag',0,132,0,0,1,NULL,NULL,NULL,NULL,NULL),(1628,74,'Phli',0,133,0,0,1,NULL,NULL,NULL,NULL,NULL),(1629,74,'Phlp',0,134,0,0,1,NULL,NULL,NULL,NULL,NULL),(1630,74,'Phlv',0,135,0,0,1,NULL,NULL,NULL,NULL,NULL),(1631,74,'Phnx',0,136,0,0,1,NULL,NULL,NULL,NULL,NULL),(1632,74,'Plrd',0,137,0,0,1,NULL,NULL,NULL,NULL,NULL),(1633,74,'Piqd',0,138,0,0,1,NULL,NULL,NULL,NULL,NULL),(1634,74,'Prti',0,139,0,0,1,NULL,NULL,NULL,NULL,NULL),(1635,74,'Qaaa',0,140,0,0,1,NULL,NULL,NULL,NULL,NULL),(1636,74,'Qabx',0,141,0,0,1,NULL,NULL,NULL,NULL,NULL),(1637,74,'Rjng',0,142,0,0,1,NULL,NULL,NULL,NULL,NULL),(1638,74,'Rohg',0,143,0,0,1,NULL,NULL,NULL,NULL,NULL),(1639,74,'Roro',0,144,0,0,1,NULL,NULL,NULL,NULL,NULL),(1640,74,'Runr',0,145,0,0,1,NULL,NULL,NULL,NULL,NULL),(1641,74,'Samr',0,146,0,0,1,NULL,NULL,NULL,NULL,NULL),(1642,74,'Sara',0,147,0,0,1,NULL,NULL,NULL,NULL,NULL),(1643,74,'Sarb',0,148,0,0,1,NULL,NULL,NULL,NULL,NULL),(1644,74,'Saur',0,149,0,0,1,NULL,NULL,NULL,NULL,NULL),(1645,74,'Sgnw',0,150,0,0,1,NULL,NULL,NULL,NULL,NULL),(1646,74,'Shaw',0,151,0,0,1,NULL,NULL,NULL,NULL,NULL),(1647,74,'Shrd',0,152,0,0,1,NULL,NULL,NULL,NULL,NULL),(1648,74,'Shui',0,153,0,0,1,NULL,NULL,NULL,NULL,NULL),(1649,74,'Sidd',0,154,0,0,1,NULL,NULL,NULL,NULL,NULL),(1650,74,'Sind',0,155,0,0,1,NULL,NULL,NULL,NULL,NULL),(1651,74,'Sinh',0,156,0,0,1,NULL,NULL,NULL,NULL,NULL),(1652,74,'Sogd',0,157,0,0,1,NULL,NULL,NULL,NULL,NULL),(1653,74,'Sogo',0,158,0,0,1,NULL,NULL,NULL,NULL,NULL),(1654,74,'Sora',0,159,0,0,1,NULL,NULL,NULL,NULL,NULL),(1655,74,'Soyo',0,160,0,0,1,NULL,NULL,NULL,NULL,NULL),(1656,74,'Sund',0,161,0,0,1,NULL,NULL,NULL,NULL,NULL),(1657,74,'Sylo',0,162,0,0,1,NULL,NULL,NULL,NULL,NULL),(1658,74,'Syrc',0,163,0,0,1,NULL,NULL,NULL,NULL,NULL),(1659,74,'Syre',0,164,0,0,1,NULL,NULL,NULL,NULL,NULL),(1660,74,'Syrj',0,165,0,0,1,NULL,NULL,NULL,NULL,NULL),(1661,74,'Syrn',0,166,0,0,1,NULL,NULL,NULL,NULL,NULL),(1662,74,'Tagb',0,167,0,0,1,NULL,NULL,NULL,NULL,NULL),(1663,74,'Takr',0,168,0,0,1,NULL,NULL,NULL,NULL,NULL),(1664,74,'Tale',0,169,0,0,1,NULL,NULL,NULL,NULL,NULL),(1665,74,'Talu',0,170,0,0,1,NULL,NULL,NULL,NULL,NULL),(1666,74,'Taml',0,171,0,0,1,NULL,NULL,NULL,NULL,NULL),(1667,74,'Tang',0,172,0,0,1,NULL,NULL,NULL,NULL,NULL),(1668,74,'Tavt',0,173,0,0,1,NULL,NULL,NULL,NULL,NULL),(1669,74,'Telu',0,174,0,0,1,NULL,NULL,NULL,NULL,NULL),(1670,74,'Teng',0,175,0,0,1,NULL,NULL,NULL,NULL,NULL),(1671,74,'Tfng',0,176,0,0,1,NULL,NULL,NULL,NULL,NULL),(1672,74,'Tglg',0,177,0,0,1,NULL,NULL,NULL,NULL,NULL),(1673,74,'Thaa',0,178,0,0,1,NULL,NULL,NULL,NULL,NULL),(1674,74,'Thai',0,179,0,0,1,NULL,NULL,NULL,NULL,NULL),(1675,74,'Tibt',0,180,0,0,1,NULL,NULL,NULL,NULL,NULL),(1676,74,'Tirh',0,181,0,0,1,NULL,NULL,NULL,NULL,NULL),(1677,74,'Ugar',0,182,0,0,1,NULL,NULL,NULL,NULL,NULL),(1678,74,'Vaii',0,183,0,0,1,NULL,NULL,NULL,NULL,NULL),(1679,74,'Visp',0,184,0,0,1,NULL,NULL,NULL,NULL,NULL),(1680,74,'Wara',0,185,0,0,1,NULL,NULL,NULL,NULL,NULL),(1681,74,'Wcho',0,186,0,0,1,NULL,NULL,NULL,NULL,NULL),(1682,74,'Wole',0,187,0,0,1,NULL,NULL,NULL,NULL,NULL),(1683,74,'Xpeo',0,188,0,0,1,NULL,NULL,NULL,NULL,NULL),(1684,74,'Xsux',0,189,0,0,1,NULL,NULL,NULL,NULL,NULL),(1685,74,'Yiii',0,190,0,0,1,NULL,NULL,NULL,NULL,NULL),(1686,74,'Zanb',0,191,0,0,1,NULL,NULL,NULL,NULL,NULL),(1687,74,'Zinh',0,192,0,0,1,NULL,NULL,NULL,NULL,NULL),(1688,74,'Zmth',0,193,0,0,1,NULL,NULL,NULL,NULL,NULL),(1689,74,'Zsye',0,194,0,0,1,NULL,NULL,NULL,NULL,NULL),(1690,74,'Zsym',0,195,0,0,1,NULL,NULL,NULL,NULL,NULL),(1691,74,'Zxxx',0,196,0,0,1,NULL,NULL,NULL,NULL,NULL),(1692,74,'Zyyy',0,197,0,0,1,NULL,NULL,NULL,NULL,NULL),(1693,74,'Zzzz',0,198,0,0,1,NULL,NULL,NULL,NULL,NULL),(1694,75,'langmaterial',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1695,4,'ingest',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1696,23,'ingest',0,7,0,1,1,NULL,'admin',NULL,'2026-02-27 23:18:13',NULL),(1697,76,'new',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1698,76,'upgraded',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1699,76,'revised_corrected',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1700,76,'derived',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1701,76,'deleted',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1702,76,'cancelled_obsolete',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1703,76,'deleted_split',0,6,0,0,1,NULL,NULL,NULL,NULL,NULL),(1704,76,'deleted_replaced',0,7,0,0,1,NULL,NULL,NULL,NULL,NULL),(1705,77,'in_process',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1706,77,'approved',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1707,78,'int_std',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1708,78,'nat_std',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1709,78,'nl_assoc_std',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1710,78,'nl_bib_agency_std',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1711,78,'local_standard',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1712,78,'unknown_standard',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1713,78,'conv_rom_cat_agency',0,6,0,0,1,NULL,NULL,NULL,NULL,NULL),(1714,78,'not_applicable',0,7,0,0,1,NULL,NULL,NULL,NULL,NULL),(1715,79,'ala-lc',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1716,80,'ngo',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1717,80,'sac',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1718,80,'multilocal',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1719,80,'fed',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1720,80,'int_gov',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1721,80,'local',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1722,80,'multistate',0,6,0,0,1,NULL,NULL,NULL,NULL,NULL),(1723,80,'undetermined',0,7,0,0,1,NULL,NULL,NULL,NULL,NULL),(1724,80,'provincial',0,8,0,0,1,NULL,NULL,NULL,NULL,NULL),(1725,80,'unknown',0,9,0,0,1,NULL,NULL,NULL,NULL,NULL),(1726,80,'other',0,10,0,0,1,NULL,NULL,NULL,NULL,NULL),(1727,80,'natc',0,11,0,0,1,NULL,NULL,NULL,NULL,NULL),(1728,81,'tr_consistent',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1729,81,'tr_inconsistent',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1730,81,'not_applicable',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1731,81,'natc',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1732,82,'differentiated',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1733,82,'undifferentiated',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1734,82,'not_applicable',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1735,82,'natc',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1736,83,'fully_established',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1737,83,'memorandum',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1738,83,'provisional',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1739,83,'preliminary',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1740,83,'not_applicable',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1741,83,'natc',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1742,84,'not_modified',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1743,84,'shortened',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1744,84,'missing_characters',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1745,84,'natc',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1746,85,'nat_bib_agency',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1747,85,'ccp',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1748,85,'other',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1749,85,'unknown',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1750,85,'natc',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1751,86,'loc',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1752,86,'lac',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1753,86,'local',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1754,86,'other_unmapped',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1755,87,'oclc',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1756,87,'local',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1757,88,'created',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1758,88,'cancelled',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1759,88,'deleted',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1760,88,'derived',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1761,88,'revised',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1762,88,'updated',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1763,89,'human',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1764,89,'machine',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1765,90,'single',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1766,90,'range',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1767,91,'begin',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1768,91,'end',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1769,92,'standard',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1770,92,'not_before',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1771,92,'not_after',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1772,93,'standard',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1773,93,'not_before',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1774,93,'not_after',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1775,94,'standard',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1776,94,'not_before',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1777,94,'not_after',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1778,95,'assoc_country',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1779,95,'residence',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1780,95,'other_assoc',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1781,95,'place_of_birth',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1782,95,'place_of_death',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1783,96,'is_identified_with',1,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1784,97,'is_hierarchical_with',1,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1785,98,'is_temporal_with',1,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1786,99,'is_related_with',1,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1787,100,'not_specified',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1788,4,'snac',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1789,102,'public_domain',0,0,0,0,1,NULL,NULL,NULL,NULL,NULL),(1790,102,'non_commercial',0,1,0,0,1,NULL,NULL,NULL,NULL,NULL),(1791,102,'non_commercial_no_derivatives',0,2,0,0,1,NULL,NULL,NULL,NULL,NULL),(1792,102,'no_derivatives',0,3,0,0,1,NULL,NULL,NULL,NULL,NULL),(1793,102,'share_a_like',0,4,0,0,1,NULL,NULL,NULL,NULL,NULL),(1794,102,'non_commercial_share_a_like',0,5,0,0,1,NULL,NULL,NULL,NULL,NULL),(1795,76,'deleted_merged',0,8,0,0,1,NULL,NULL,NULL,NULL,NULL),(1796,23,'nmaict',0,8,0,1,1,'admin','admin','2026-02-27 23:18:13','2026-02-27 23:18:13','2026-02-27 23:18:13'),(1797,21,'publish',0,4,0,1,1,'admin','admin','2026-02-27 23:18:13','2026-02-27 23:18:13','2026-02-27 23:18:13');
/*!40000 ALTER TABLE `enumeration_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `repo_id` int NOT NULL,
  `event_type_id` int NOT NULL,
  `outcome_id` int DEFAULT NULL,
  `outcome_note` varchar(17408) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `refid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refid` (`refid`),
  KEY `event_type_id` (`event_type_id`),
  KEY `outcome_id` (`outcome_id`),
  KEY `event_system_mtime_index` (`system_mtime`),
  KEY `event_user_mtime_index` (`user_mtime`),
  KEY `event_suppressed_index` (`suppressed`),
  KEY `repo_id` (`repo_id`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`event_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `event_ibfk_2` FOREIGN KEY (`outcome_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `event_ibfk_3` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,0,1,0,1,295,NULL,NULL,'2026-02-27 23:17:23',NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23',NULL),(2,0,1,0,1,295,NULL,NULL,'2026-02-27 23:17:23',NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23',NULL),(3,0,1,0,1,295,NULL,NULL,'2026-02-27 23:18:03','admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03',NULL),(4,0,1,0,2,286,NULL,NULL,'2026-02-27 23:18:08','admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08',NULL),(5,0,1,0,1,295,NULL,NULL,'2026-03-06 20:48:43','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL),(6,0,1,0,1,295,NULL,NULL,'2026-03-06 20:48:45','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL),(7,0,1,0,1,295,NULL,NULL,'2026-03-06 20:48:46','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_link_rlshp`
--

DROP TABLE IF EXISTS `event_link_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_link_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accession_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `role_id` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `top_container_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `event_link_rlshp_system_mtime_index` (`system_mtime`),
  KEY `event_link_rlshp_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `resource_id` (`resource_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  KEY `event_id` (`event_id`),
  KEY `top_container_id` (`top_container_id`),
  CONSTRAINT `event_link_rlshp_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_10` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_11` FOREIGN KEY (`top_container_id`) REFERENCES `top_container` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_2` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_3` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_4` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_5` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_6` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_7` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_8` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `event_link_rlshp_ibfk_9` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_link_rlshp`
--

LOCK TABLES `event_link_rlshp` WRITE;
/*!40000 ALTER TABLE `event_link_rlshp` DISABLE KEYS */;
INSERT INTO `event_link_rlshp` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,3,0,NULL,NULL,'2026-02-27 23:18:03','2026-02-27 23:18:03',228,0,NULL),(2,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,0,NULL,NULL,'2026-02-27 23:18:08','2026-02-27 23:18:08',229,0,NULL),(3,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,5,0,NULL,NULL,'2026-03-06 20:48:43','2026-03-06 20:48:43',228,0,NULL),(4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,6,0,NULL,NULL,'2026-03-06 20:48:45','2026-03-06 20:48:45',228,0,NULL),(5,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,7,0,NULL,NULL,'2026-03-06 20:48:46','2026-03-06 20:48:46',228,0,NULL);
/*!40000 ALTER TABLE `event_link_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extent`
--

DROP TABLE IF EXISTS `extent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extent` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `deaccession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `portion_id` int NOT NULL,
  `number` varchar(255) NOT NULL,
  `extent_type_id` int NOT NULL,
  `container_summary` text,
  `physical_details` text,
  `dimensions` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `extent_type_id` (`extent_type_id`),
  KEY `extent_system_mtime_index` (`system_mtime`),
  KEY `extent_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `resource_id` (`resource_id`),
  KEY `deaccession_id` (`deaccession_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  CONSTRAINT `extent_ibfk_1` FOREIGN KEY (`extent_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `extent_ibfk_2` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `extent_ibfk_3` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `extent_ibfk_4` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `extent_ibfk_5` FOREIGN KEY (`deaccession_id`) REFERENCES `deaccession` (`id`),
  CONSTRAINT `extent_ibfk_6` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `extent_ibfk_7` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extent`
--

LOCK TABLES `extent` WRITE;
/*!40000 ALTER TABLE `extent` DISABLE KEYS */;
INSERT INTO `extent` VALUES (1,0,1,NULL,NULL,NULL,1,NULL,NULL,923,'1',274,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(2,0,1,NULL,NULL,NULL,2,NULL,NULL,923,'1',274,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(3,0,1,NULL,NULL,NULL,3,NULL,NULL,923,'1',274,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(4,0,1,NULL,NULL,NULL,4,NULL,NULL,923,'1',274,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05'),(5,0,1,NULL,NULL,NULL,5,NULL,NULL,923,'1',274,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05'),(11,0,1,NULL,NULL,NULL,7,NULL,NULL,923,'1',274,'Container Summary','Physical Details','Dimensions','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(12,0,1,NULL,NULL,NULL,7,NULL,NULL,924,'1',278,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(13,0,1,NULL,3,NULL,NULL,NULL,NULL,923,'1',274,'Container Summary','Physical Details','Dimensions','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(14,0,1,NULL,4,NULL,NULL,NULL,NULL,924,'.5',275,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(15,0,1,NULL,4,NULL,NULL,NULL,NULL,924,'.5',274,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47');
/*!40000 ALTER TABLE `extent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_document`
--

DROP TABLE IF EXISTS `external_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_document` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `title` varchar(8704) NOT NULL,
  `location` varchar(8704) NOT NULL,
  `publish` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `location_sha1` varchar(255) DEFAULT NULL,
  `accession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `subject_id` int DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `rights_statement_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `identifier_type_id` int DEFAULT NULL,
  `assessment_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_exdoc_acc` (`accession_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_arc_obj` (`archival_object_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_res` (`resource_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_sub` (`subject_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_age_per` (`agent_person_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_age_fam` (`agent_family_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_age_cor_ent` (`agent_corporate_entity_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_age_sof` (`agent_software_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_rig_sta` (`rights_statement_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_dig_obj` (`digital_object_id`,`location_sha1`),
  UNIQUE KEY `uniq_exdoc_dig_obj_com` (`digital_object_component_id`,`location_sha1`),
  KEY `external_document_system_mtime_index` (`system_mtime`),
  KEY `external_document_user_mtime_index` (`user_mtime`),
  KEY `event_external_document_fk` (`event_id`),
  KEY `external_document_identifier_type_id_fk` (`identifier_type_id`),
  KEY `assessment_external_document_fk` (`assessment_id`),
  CONSTRAINT `assessment_external_document_fk` FOREIGN KEY (`assessment_id`) REFERENCES `event` (`id`),
  CONSTRAINT `event_external_document_fk` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `external_document_ibfk_1` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `external_document_ibfk_10` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `external_document_ibfk_11` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`),
  CONSTRAINT `external_document_ibfk_2` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `external_document_ibfk_3` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `external_document_ibfk_4` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `external_document_ibfk_5` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `external_document_ibfk_6` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `external_document_ibfk_7` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `external_document_ibfk_8` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `external_document_ibfk_9` FOREIGN KEY (`rights_statement_id`) REFERENCES `rights_statement` (`id`),
  CONSTRAINT `external_document_identifier_type_id_fk` FOREIGN KEY (`identifier_type_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_document`
--

LOCK TABLES `external_document` WRITE;
/*!40000 ALTER TABLE `external_document` DISABLE KEYS */;
INSERT INTO `external_document` VALUES (11,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,0,1,'External Document Title','External Document Location',1,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42','3f33975880da9e904e8f2e52f5e40f93af8dd603',NULL,NULL,NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,0,1,'External Document Title 1','Location 1',1,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43','c195d48515783a02fe339feda04ff484d965483f',NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,0,1,'External Document Title 2','Location 2',1,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43','a9caca58448cc9f4dfe81c569623fad4ee6a8415',NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,0,1,'External Document Title 1','Location 1',1,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45','c195d48515783a02fe339feda04ff484d965483f',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,0,1,'External Document Title 2','Location 2',1,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45','a9caca58448cc9f4dfe81c569623fad4ee6a8415',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,0,1,'External Document Title 1','Location 1',1,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46','c195d48515783a02fe339feda04ff484d965483f',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,0,1,'External Document Title 2','Location 2',1,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46','a9caca58448cc9f4dfe81c569623fad4ee6a8415',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,0,1,'Title 1','Location 2',1,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47','c3a482fbffadc1e288e815405960858f0e78ecab',NULL,NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,0,1,'Title 2','Location 2',0,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47','a3e6670171680e612fcf1c883d97832ad0c004a9',NULL,NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,0,1,'Title 1','Location 1',1,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47','c09e655d22b7a3c292a08c3082460a810b3dabc6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,1378,NULL),(30,0,1,'Title 2','Location 2',0,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47','a3e6670171680e612fcf1c883d97832ad0c004a9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,1377,NULL);
/*!40000 ALTER TABLE `external_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_id`
--

DROP TABLE IF EXISTS `external_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_id` (
  `id` int NOT NULL AUTO_INCREMENT,
  `external_id` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `subject_id` int DEFAULT NULL,
  `accession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `collection_management_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `external_id_system_mtime_index` (`system_mtime`),
  KEY `external_id_user_mtime_index` (`user_mtime`),
  KEY `subject_id` (`subject_id`),
  KEY `accession_id` (`accession_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `collection_management_id` (`collection_management_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  KEY `event_id` (`event_id`),
  KEY `location_id` (`location_id`),
  KEY `resource_id` (`resource_id`),
  CONSTRAINT `external_id_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `external_id_ibfk_2` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `external_id_ibfk_3` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `external_id_ibfk_4` FOREIGN KEY (`collection_management_id`) REFERENCES `collection_management` (`id`),
  CONSTRAINT `external_id_ibfk_5` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `external_id_ibfk_6` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`),
  CONSTRAINT `external_id_ibfk_7` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `external_id_ibfk_8` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `external_id_ibfk_9` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_id`
--

LOCK TABLES `external_id` WRITE;
/*!40000 ALTER TABLE `external_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_version`
--

DROP TABLE IF EXISTS `file_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_version` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `use_statement_id` int DEFAULT NULL,
  `checksum_method_id` int DEFAULT NULL,
  `file_uri` varchar(17408) NOT NULL,
  `publish` int DEFAULT NULL,
  `xlink_actuate_attribute_id` int DEFAULT NULL,
  `xlink_show_attribute_id` int DEFAULT NULL,
  `file_format_name_id` int DEFAULT NULL,
  `file_format_version` varchar(255) DEFAULT NULL,
  `file_size_bytes` bigint DEFAULT NULL,
  `checksum` varchar(255) DEFAULT NULL,
  `checksum_method` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `is_representative` int DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `digital_object_one_representative_file_version` (`is_representative`,`digital_object_id`),
  KEY `use_statement_id` (`use_statement_id`),
  KEY `checksum_method_id` (`checksum_method_id`),
  KEY `xlink_actuate_attribute_id` (`xlink_actuate_attribute_id`),
  KEY `xlink_show_attribute_id` (`xlink_show_attribute_id`),
  KEY `file_format_name_id` (`file_format_name_id`),
  KEY `file_version_system_mtime_index` (`system_mtime`),
  KEY `file_version_user_mtime_index` (`user_mtime`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  CONSTRAINT `file_version_ibfk_1` FOREIGN KEY (`use_statement_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `file_version_ibfk_2` FOREIGN KEY (`checksum_method_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `file_version_ibfk_3` FOREIGN KEY (`xlink_actuate_attribute_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `file_version_ibfk_4` FOREIGN KEY (`xlink_show_attribute_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `file_version_ibfk_5` FOREIGN KEY (`file_format_name_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `file_version_ibfk_6` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `file_version_ibfk_7` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_version`
--

LOCK TABLES `file_version` WRITE;
/*!40000 ALTER TABLE `file_version` DISABLE KEYS */;
INSERT INTO `file_version` VALUES (1,0,1,1,NULL,372,NULL,'https://example.com/3',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',1,NULL),(2,0,1,1,NULL,386,NULL,'https://example.com/3/2',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',NULL,NULL),(3,0,1,2,NULL,372,NULL,'https://example.com/2',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',1,NULL),(4,0,1,2,NULL,386,NULL,'https://example.com/2/2',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',NULL,NULL),(7,0,1,4,NULL,372,NULL,'https://example.com/0',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',1,NULL),(8,0,1,4,NULL,386,NULL,'https://example.com/0/2',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-02-27 23:18:07','2026-02-27 23:18:07','2026-02-27 23:18:07',NULL,NULL),(11,0,1,3,NULL,372,NULL,'https://example.com/1',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-09 22:36:35','2026-03-09 22:36:35','2026-03-09 22:36:35',1,NULL),(12,0,1,3,NULL,386,NULL,'https://example.com/1/2',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-09 22:36:35','2026-03-09 22:36:35','2026-03-09 22:36:35',NULL,NULL);
/*!40000 ALTER TABLE `file_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `group_code` varchar(255) NOT NULL,
  `group_code_norm` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_uniq` (`repo_id`,`group_code_norm`),
  KEY `group_system_mtime_index` (`system_mtime`),
  KEY `group_user_mtime_index` (`user_mtime`),
  CONSTRAINT `group_repo_id_fk` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
INSERT INTO `group` VALUES (1,0,1,1,'administrators','administrators','Administrators',NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(2,0,1,1,'searchindex','searchindex','Search index',NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(3,0,1,1,'publicanonymous','publicanonymous','Public Anonymous',NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(4,0,1,1,'staffsystem','staffsystem','Staff System Group',NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(5,10,1,2,'repository-managers','repository-managers','Managers of the test_repo_37 repository','admin','admin','2026-02-27 23:18:03','2026-03-09 13:05:06','2026-02-27 23:18:03'),(6,5,1,2,'repository-archivists','repository-archivists','Archivists of the test_repo_37 repository','admin','admin','2026-02-27 23:18:03','2026-03-09 13:05:06','2026-02-27 23:18:03'),(7,0,1,2,'repository-project-managers','repository-project-managers','Project managers of the test_repo_37 repository','admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03'),(8,0,1,2,'repository-advanced-data-entry','repository-advanced-data-entry','Advanced Data Entry users of the test_repo_37 repository','admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03'),(9,0,1,2,'repository-basic-data-entry','repository-basic-data-entry','Basic Data Entry users of the test_repo_37 repository','admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03'),(10,0,1,2,'repository-viewers','repository-viewers','Viewers of the test_repo_37 repository','admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03');
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_permission`
--

DROP TABLE IF EXISTS `group_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permission_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_permission_permission_id_group_id_index` (`permission_id`,`group_id`),
  KEY `group_permission_permission_id_index` (`permission_id`),
  KEY `group_permission_group_id_index` (`group_id`),
  CONSTRAINT `group_permission_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_permission_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_permission`
--

LOCK TABLES `group_permission` WRITE;
/*!40000 ALTER TABLE `group_permission` DISABLE KEYS */;
INSERT INTO `group_permission` VALUES (25,1,1),(92,1,6),(138,1,9),(26,2,1),(69,2,5),(93,2,6),(31,3,1),(73,3,5),(94,3,6),(117,3,7),(133,3,8),(29,4,1),(62,4,5),(84,4,6),(108,4,7),(74,5,5),(95,5,6),(1,6,1),(2,7,1),(3,8,1),(4,9,1),(45,9,2),(48,9,3),(5,10,1),(6,11,1),(7,12,1),(8,13,1),(46,13,2),(9,14,1),(50,14,5),(10,15,1),(51,15,5),(76,15,6),(98,15,7),(119,15,8),(135,15,9),(11,16,1),(52,16,5),(77,16,6),(99,16,7),(120,16,8),(136,16,9),(12,17,1),(53,17,5),(78,17,6),(100,17,7),(121,17,8),(137,17,9),(13,18,1),(54,18,5),(79,18,6),(101,18,7),(122,18,8),(14,19,1),(55,19,5),(102,19,7),(15,20,1),(59,20,5),(105,20,7),(16,21,1),(17,22,1),(58,22,5),(104,22,7),(18,23,1),(44,23,2),(19,24,1),(43,24,2),(47,24,3),(57,24,5),(81,24,6),(97,24,7),(118,24,8),(134,24,9),(139,24,10),(20,25,1),(21,26,1),(22,27,1),(49,27,4),(23,28,1),(68,28,5),(89,28,6),(113,28,7),(130,28,8),(24,29,1),(27,30,1),(60,30,5),(82,30,6),(106,30,7),(124,30,8),(28,31,1),(61,31,5),(83,31,6),(107,31,7),(125,31,8),(30,32,1),(63,32,5),(85,32,6),(109,32,7),(126,32,8),(32,33,1),(114,33,7),(33,34,1),(34,35,1),(64,35,5),(35,36,1),(56,36,5),(80,36,6),(103,36,7),(123,36,8),(36,37,1),(65,37,5),(86,37,6),(110,37,7),(127,37,8),(37,38,1),(66,38,5),(87,38,6),(111,38,7),(128,38,8),(38,39,1),(67,39,5),(88,39,6),(112,39,7),(129,39,8),(39,40,1),(70,40,5),(90,40,6),(115,40,7),(131,40,8),(40,41,1),(71,41,5),(91,41,6),(116,41,7),(132,41,8),(41,42,1),(72,42,5),(42,43,1),(75,43,5),(96,43,6);
/*!40000 ALTER TABLE `group_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_user`
--

DROP TABLE IF EXISTS `group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_user_group_id_index` (`group_id`),
  KEY `group_user_user_id_index` (`user_id`),
  CONSTRAINT `group_user_group_id_fk` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_user_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_user`
--

LOCK TABLES `group_user` WRITE;
/*!40000 ALTER TABLE `group_user` DISABLE KEYS */;
INSERT INTO `group_user` VALUES (1,1,1),(2,2,2),(3,3,3),(4,4,4);
/*!40000 ALTER TABLE `group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance`
--

DROP TABLE IF EXISTS `instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `resource_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `accession_id` int DEFAULT NULL,
  `instance_type_id` int NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `is_representative` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `resource_one_representative_instance` (`is_representative`,`resource_id`),
  UNIQUE KEY `component_one_representative_instance` (`is_representative`,`archival_object_id`),
  KEY `instance_type_id` (`instance_type_id`),
  KEY `instance_system_mtime_index` (`system_mtime`),
  KEY `instance_user_mtime_index` (`user_mtime`),
  KEY `resource_id` (`resource_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `accession_id` (`accession_id`),
  CONSTRAINT `instance_ibfk_1` FOREIGN KEY (`instance_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `instance_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `instance_ibfk_3` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `instance_ibfk_4` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance`
--

LOCK TABLES `instance` WRITE;
/*!40000 ALTER TABLE `instance` DISABLE KEYS */;
INSERT INTO `instance` VALUES (3,0,1,7,NULL,NULL,353,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL),(4,0,1,7,NULL,NULL,349,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL);
/*!40000 ALTER TABLE `instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_do_link_rlshp`
--

DROP TABLE IF EXISTS `instance_do_link_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instance_do_link_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `digital_object_id` int DEFAULT NULL,
  `instance_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `instance_do_link_rlshp_system_mtime_index` (`system_mtime`),
  KEY `instance_do_link_rlshp_user_mtime_index` (`user_mtime`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `instance_id` (`instance_id`),
  CONSTRAINT `instance_do_link_rlshp_ibfk_1` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `instance_do_link_rlshp_ibfk_2` FOREIGN KEY (`instance_id`) REFERENCES `instance` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_do_link_rlshp`
--

LOCK TABLES `instance_do_link_rlshp` WRITE;
/*!40000 ALTER TABLE `instance_do_link_rlshp` DISABLE KEYS */;
INSERT INTO `instance_do_link_rlshp` VALUES (2,2,4,0,NULL,NULL,'2026-03-06 20:48:47','2026-03-06 20:48:47',0);
/*!40000 ALTER TABLE `instance_do_link_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job` (
  `id` int NOT NULL AUTO_INCREMENT,
  `repo_id` int NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `job_blob` mediumblob NOT NULL,
  `time_submitted` datetime NOT NULL,
  `time_started` datetime DEFAULT NULL,
  `time_finished` datetime DEFAULT NULL,
  `owner_id` int NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `job_params` varchar(255) DEFAULT NULL,
  `job_type` varchar(255) NOT NULL DEFAULT 'unknown_job_type',
  PRIMARY KEY (`id`),
  KEY `job_system_mtime_index` (`system_mtime`),
  KEY `job_user_mtime_index` (`user_mtime`),
  KEY `job_status_idx` (`status`),
  KEY `job_repo_id_fk` (`repo_id`),
  KEY `job_owner_id_fk` (`owner_id`),
  CONSTRAINT `job_owner_id_fk` FOREIGN KEY (`owner_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_repo_id_fk` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_created_record`
--

DROP TABLE IF EXISTS `job_created_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_created_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_id` int NOT NULL,
  `record_uri` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_created_record_system_mtime_index` (`system_mtime`),
  KEY `job_created_record_user_mtime_index` (`user_mtime`),
  KEY `job_created_record_job_id_fk` (`job_id`),
  CONSTRAINT `job_created_record_job_id_fk` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_created_record`
--

LOCK TABLES `job_created_record` WRITE;
/*!40000 ALTER TABLE `job_created_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_created_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_input_file`
--

DROP TABLE IF EXISTS `job_input_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_input_file` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_id` int NOT NULL,
  `file_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_input_file_job_id_fk` (`job_id`),
  CONSTRAINT `job_input_file_job_id_fk` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_input_file`
--

LOCK TABLES `job_input_file` WRITE;
/*!40000 ALTER TABLE `job_input_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_input_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_modified_record`
--

DROP TABLE IF EXISTS `job_modified_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_modified_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_id` int NOT NULL,
  `record_uri` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_modified_record_system_mtime_index` (`system_mtime`),
  KEY `job_modified_record_user_mtime_index` (`user_mtime`),
  KEY `job_modified_record_job_id_fk` (`job_id`),
  CONSTRAINT `job_modified_record_job_id_fk` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_modified_record`
--

LOCK TABLES `job_modified_record` WRITE;
/*!40000 ALTER TABLE `job_modified_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_modified_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lang_material`
--

DROP TABLE IF EXISTS `lang_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lang_material` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `archival_object_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `accession_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lang_material_system_mtime_index` (`system_mtime`),
  KEY `lang_material_user_mtime_index` (`user_mtime`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `resource_id` (`resource_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  KEY `accession_id` (`accession_id`),
  CONSTRAINT `lang_material_ibfk_1` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `lang_material_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `lang_material_ibfk_3` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `lang_material_ibfk_4` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`),
  CONSTRAINT `lang_material_ibfk_5` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lang_material`
--

LOCK TABLES `lang_material` WRITE;
/*!40000 ALTER TABLE `lang_material` DISABLE KEYS */;
INSERT INTO `lang_material` VALUES (1,0,1,NULL,1,NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',NULL),(2,0,1,NULL,2,NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',NULL),(3,0,1,NULL,3,NULL,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',NULL),(4,0,1,NULL,4,NULL,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05',NULL),(5,0,1,NULL,5,NULL,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05',NULL),(9,0,1,NULL,7,NULL,NULL,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL),(10,0,1,NULL,7,NULL,NULL,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL),(11,0,1,NULL,7,NULL,NULL,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL);
/*!40000 ALTER TABLE `lang_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_and_script`
--

DROP TABLE IF EXISTS `language_and_script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `language_and_script` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `lang_material_id` int DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `language_id` (`language_id`),
  KEY `script_id` (`script_id`),
  KEY `language_and_script_system_mtime_index` (`system_mtime`),
  KEY `language_and_script_user_mtime_index` (`user_mtime`),
  KEY `lang_material_id` (`lang_material_id`),
  CONSTRAINT `language_and_script_ibfk_1` FOREIGN KEY (`language_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `language_and_script_ibfk_2` FOREIGN KEY (`script_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `language_and_script_ibfk_3` FOREIGN KEY (`lang_material_id`) REFERENCES `lang_material` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_and_script`
--

LOCK TABLES `language_and_script` WRITE;
/*!40000 ALTER TABLE `language_and_script` DISABLE KEYS */;
INSERT INTO `language_and_script` VALUES (1,0,1,1,515,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(2,0,1,2,515,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(3,0,1,3,515,NULL,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04'),(4,0,1,4,515,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05'),(5,0,1,5,515,NULL,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:05','2026-02-27 23:18:05'),(8,0,1,9,515,1582,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47'),(9,0,1,11,793,1580,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47');
/*!40000 ALTER TABLE `language_and_script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linked_agent_term`
--

DROP TABLE IF EXISTS `linked_agent_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `linked_agent_term` (
  `id` int NOT NULL AUTO_INCREMENT,
  `linked_agents_rlshp_id` int NOT NULL,
  `term_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `term_id` (`term_id`),
  KEY `linked_agent_term_idx` (`linked_agents_rlshp_id`,`term_id`),
  CONSTRAINT `linked_agent_term_ibfk_1` FOREIGN KEY (`linked_agents_rlshp_id`) REFERENCES `linked_agents_rlshp` (`id`),
  CONSTRAINT `linked_agent_term_ibfk_2` FOREIGN KEY (`term_id`) REFERENCES `term` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linked_agent_term`
--

LOCK TABLES `linked_agent_term` WRITE;
/*!40000 ALTER TABLE `linked_agent_term` DISABLE KEYS */;
INSERT INTO `linked_agent_term` VALUES (1,10,21);
/*!40000 ALTER TABLE `linked_agent_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `linked_agents_rlshp`
--

DROP TABLE IF EXISTS `linked_agents_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `linked_agents_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_person_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `accession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `role_id` int DEFAULT NULL,
  `relator_id` int DEFAULT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `rights_statement_id` int DEFAULT NULL,
  `is_primary` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `relator_id` (`relator_id`),
  KEY `linked_agents_rlshp_system_mtime_index` (`system_mtime`),
  KEY `linked_agents_rlshp_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_software_id` (`agent_software_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `accession_id` (`accession_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  KEY `event_id` (`event_id`),
  KEY `resource_id` (`resource_id`),
  KEY `rights_statement_id` (`rights_statement_id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_10` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_11` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_12` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_13` FOREIGN KEY (`rights_statement_id`) REFERENCES `rights_statement` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_2` FOREIGN KEY (`relator_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_3` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_5` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_6` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_7` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_8` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `linked_agents_rlshp_ibfk_9` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `linked_agents_rlshp`
--

LOCK TABLES `linked_agents_rlshp` WRITE;
/*!40000 ALTER TABLE `linked_agents_rlshp` DISABLE KEYS */;
INSERT INTO `linked_agents_rlshp` VALUES (1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,0,'admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03',232,NULL,NULL,0,NULL,NULL),(2,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,NULL,0,'admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08',234,NULL,NULL,0,NULL,NULL),(3,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,4,NULL,1,'admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08',233,NULL,NULL,0,NULL,NULL),(5,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,NULL,0,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',232,NULL,NULL,0,NULL,NULL),(6,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',232,NULL,NULL,0,NULL,NULL),(7,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,NULL,0,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',232,NULL,NULL,0,NULL,NULL),(8,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,0,3,NULL),(9,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,0,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',878,75,'Ms.',0,NULL,0),(10,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,1,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',880,13,NULL,0,NULL,0),(11,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,2,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',879,18,NULL,0,NULL,0);
/*!40000 ALTER TABLE `linked_agents_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `building` varchar(255) NOT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `floor` varchar(255) DEFAULT NULL,
  `room` varchar(255) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `barcode` varchar(255) DEFAULT NULL,
  `classification` varchar(255) DEFAULT NULL,
  `coordinate_1_label` varchar(255) DEFAULT NULL,
  `coordinate_1_indicator` varchar(255) DEFAULT NULL,
  `coordinate_2_label` varchar(255) DEFAULT NULL,
  `coordinate_2_indicator` varchar(255) DEFAULT NULL,
  `coordinate_3_label` varchar(255) DEFAULT NULL,
  `coordinate_3_indicator` varchar(255) DEFAULT NULL,
  `temporary_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `temporary_id` (`temporary_id`),
  KEY `location_system_mtime_index` (`system_mtime`),
  KEY `location_user_mtime_index` (`user_mtime`),
  CONSTRAINT `location_ibfk_1` FOREIGN KEY (`temporary_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (2,0,1,'Research Center','Research Center, Floor 0, Storage Room 0 [707, Range: 1, Section: A, Shelf: 1]','Floor 0','Storage Room 0',NULL,'707',NULL,'Range','1','Section','A','Shelf','1',NULL,'admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_function`
--

DROP TABLE IF EXISTS `location_function`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_function` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `location_id` int DEFAULT NULL,
  `location_function_type_id` int NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `location_function_type_id` (`location_function_type_id`),
  KEY `location_function_system_mtime_index` (`system_mtime`),
  KEY `location_function_user_mtime_index` (`user_mtime`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `location_function_ibfk_1` FOREIGN KEY (`location_function_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `location_function_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_function`
--

LOCK TABLES `location_function` WRITE;
/*!40000 ALTER TABLE `location_function` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_function` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_profile`
--

DROP TABLE IF EXISTS `location_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_profile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `dimension_units_id` int DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `depth` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `location_profile_name_uniq` (`name`),
  KEY `dimension_units_id` (`dimension_units_id`),
  KEY `location_profile_system_mtime_index` (`system_mtime`),
  KEY `location_profile_user_mtime_index` (`user_mtime`),
  CONSTRAINT `location_profile_ibfk_1` FOREIGN KEY (`dimension_units_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_profile`
--

LOCK TABLES `location_profile` WRITE;
/*!40000 ALTER TABLE `location_profile` DISABLE KEYS */;
INSERT INTO `location_profile` VALUES (1,1,1,'Profile 1',1350,'1.1','2.1','3.1','admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08'),(2,1,1,'Profile 0',1350,'1.0','2.0','3.0','admin','admin','2026-02-27 23:18:08','2026-02-27 23:18:08','2026-02-27 23:18:08');
/*!40000 ALTER TABLE `location_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_profile_rlshp`
--

DROP TABLE IF EXISTS `location_profile_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_profile_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int DEFAULT NULL,
  `location_profile_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `location_profile_rlshp_system_mtime_index` (`system_mtime`),
  KEY `location_profile_rlshp_user_mtime_index` (`user_mtime`),
  KEY `location_id` (`location_id`),
  KEY `location_profile_id` (`location_profile_id`),
  CONSTRAINT `location_profile_rlshp_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `location_profile_rlshp_ibfk_2` FOREIGN KEY (`location_profile_id`) REFERENCES `location_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_profile_rlshp`
--

LOCK TABLES `location_profile_rlshp` WRITE;
/*!40000 ALTER TABLE `location_profile_rlshp` DISABLE KEYS */;
INSERT INTO `location_profile_rlshp` VALUES (2,2,1,0,0,NULL,NULL,'2026-02-27 23:18:08','2026-02-27 23:18:08');
/*!40000 ALTER TABLE `location_profile_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metadata_rights_declaration`
--

DROP TABLE IF EXISTS `metadata_rights_declaration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metadata_rights_declaration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accession_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `subject_id` int DEFAULT NULL,
  `license_id` int DEFAULT NULL,
  `file_version_xlink_actuate_attribute_id` int DEFAULT NULL,
  `file_version_xlink_show_attribute_id` int DEFAULT NULL,
  `citation` varchar(255) DEFAULT NULL,
  `descriptive_note` text NOT NULL,
  `file_uri` varchar(255) DEFAULT NULL,
  `xlink_title_attribute` varchar(255) DEFAULT NULL,
  `xlink_role_attribute` varchar(255) DEFAULT NULL,
  `xlink_arcrole_attribute` varchar(255) DEFAULT NULL,
  `last_verified_date` datetime DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `metadata_rights_declaration_system_mtime_index` (`system_mtime`),
  KEY `metadata_rights_declaration_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `resource_id` (`resource_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `metadata_rights_declaration_ibfk_1` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `metadata_rights_declaration_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `metadata_rights_declaration_ibfk_3` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `metadata_rights_declaration_ibfk_4` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `metadata_rights_declaration_ibfk_5` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `metadata_rights_declaration_ibfk_6` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `metadata_rights_declaration_ibfk_7` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `metadata_rights_declaration_ibfk_8` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metadata_rights_declaration`
--

LOCK TABLES `metadata_rights_declaration` WRITE;
/*!40000 ALTER TABLE `metadata_rights_declaration` DISABLE KEYS */;
INSERT INTO `metadata_rights_declaration` VALUES (9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(15,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(16,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(17,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(18,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(19,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(20,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(21,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(22,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',0),(23,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42',0),(24,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42',0),(25,NULL,NULL,NULL,NULL,NULL,NULL,NULL,9,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42',0),(26,NULL,NULL,NULL,NULL,NULL,NULL,NULL,9,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42',0),(27,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,1793,925,931,NULL,'Descriptive Note 1','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42',0),(28,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,1789,925,931,NULL,'Descriptive Note 2','https://creativecommons.org/licenses/by/4.0/','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42',0),(29,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,1789,925,931,NULL,'Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(30,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,1791,927,929,NULL,'Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(31,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,1789,925,931,NULL,'Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(32,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,1791,927,929,NULL,'Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(33,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,1789,925,931,NULL,'Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(34,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,1791,927,929,NULL,'Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-07-18 00:00:00','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(35,NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,1789,925,931,NULL,'Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-08-01 00:00:00','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',0),(36,NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,1791,926,929,NULL,'Descriptive Note','File URI','Xlink Title Attribute','Xlink Role Attribute','Xlink Arcrole Attribute','2025-08-08 00:00:00','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',0);
/*!40000 ALTER TABLE `metadata_rights_declaration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `name_authority_id`
--

DROP TABLE IF EXISTS `name_authority_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `name_authority_id` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `name_person_id` int DEFAULT NULL,
  `name_family_id` int DEFAULT NULL,
  `name_software_id` int DEFAULT NULL,
  `name_corporate_entity_id` int DEFAULT NULL,
  `authority_id` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authority_id` (`authority_id`),
  KEY `name_authority_id_system_mtime_index` (`system_mtime`),
  KEY `name_authority_id_user_mtime_index` (`user_mtime`),
  KEY `name_person_id` (`name_person_id`),
  KEY `name_family_id` (`name_family_id`),
  KEY `name_software_id` (`name_software_id`),
  KEY `name_corporate_entity_id` (`name_corporate_entity_id`),
  CONSTRAINT `name_authority_id_ibfk_1` FOREIGN KEY (`name_person_id`) REFERENCES `name_person` (`id`),
  CONSTRAINT `name_authority_id_ibfk_2` FOREIGN KEY (`name_family_id`) REFERENCES `name_family` (`id`),
  CONSTRAINT `name_authority_id_ibfk_3` FOREIGN KEY (`name_software_id`) REFERENCES `name_software` (`id`),
  CONSTRAINT `name_authority_id_ibfk_4` FOREIGN KEY (`name_corporate_entity_id`) REFERENCES `name_corporate_entity` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `name_authority_id`
--

LOCK TABLES `name_authority_id` WRITE;
/*!40000 ALTER TABLE `name_authority_id` DISABLE KEYS */;
INSERT INTO `name_authority_id` VALUES (7,1,4,NULL,NULL,NULL,'899','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43'),(8,1,5,NULL,NULL,NULL,'889','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43'),(9,1,NULL,NULL,NULL,4,'581','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45'),(10,1,NULL,NULL,NULL,5,'832','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45'),(11,1,NULL,3,NULL,NULL,'805','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46'),(12,1,NULL,4,NULL,NULL,'574','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46');
/*!40000 ALTER TABLE `name_authority_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `name_corporate_entity`
--

DROP TABLE IF EXISTS `name_corporate_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `name_corporate_entity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `agent_corporate_entity_id` int NOT NULL,
  `primary_name` text NOT NULL,
  `subordinate_name_1` text,
  `subordinate_name_2` text,
  `number` varchar(255) DEFAULT NULL,
  `dates` varchar(255) DEFAULT NULL,
  `qualifier` text,
  `source_id` int DEFAULT NULL,
  `rules_id` int DEFAULT NULL,
  `sort_name` text NOT NULL,
  `sort_name_auto_generate` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `authorized` int DEFAULT NULL,
  `is_display_name` int DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `jurisdiction` int DEFAULT '0',
  `conference_meeting` int DEFAULT '0',
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `transliteration_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `corporate_entity_one_authorized` (`authorized`,`agent_corporate_entity_id`),
  UNIQUE KEY `corporate_entity_one_display_name` (`is_display_name`,`agent_corporate_entity_id`),
  KEY `source_id` (`source_id`),
  KEY `rules_id` (`rules_id`),
  KEY `name_corporate_entity_system_mtime_index` (`system_mtime`),
  KEY `name_corporate_entity_user_mtime_index` (`user_mtime`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  CONSTRAINT `name_corporate_entity_ibfk_1` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_corporate_entity_ibfk_2` FOREIGN KEY (`rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_corporate_entity_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `name_corporate_entity`
--

LOCK TABLES `name_corporate_entity` WRITE;
/*!40000 ALTER TABLE `name_corporate_entity` DISABLE KEYS */;
INSERT INTO `name_corporate_entity` VALUES (1,0,1,1,'test_repo_37',NULL,NULL,NULL,NULL,NULL,236,NULL,'test_repo_37',1,'admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03',1,1,NULL,0,0,NULL,NULL,NULL),(4,0,1,3,'Primary 1','Sub 1-1','Sub 1-2','Number','1800-1900','Qualifier 1',236,241,'Primary 1. Sub 1-1. Sub 1-2, Number (Qualifier 1) (1800-1900) (Location 1)',1,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',1,1,'Location 1',0,1,515,1582,1715),(5,0,1,3,'Primary 2','Sub 2-1','Sub 2-2','Number','Dates','Qualifier',237,242,'Primary 2. Sub 2-1. Sub 2-2, Number (Qualifier) (Dates) (Location 2)',1,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,'Location 2',1,0,542,1580,NULL);
/*!40000 ALTER TABLE `name_corporate_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `name_family`
--

DROP TABLE IF EXISTS `name_family`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `name_family` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `agent_family_id` int NOT NULL,
  `family_name` text NOT NULL,
  `prefix` text,
  `dates` varchar(255) DEFAULT NULL,
  `qualifier` text,
  `source_id` int DEFAULT NULL,
  `rules_id` int DEFAULT NULL,
  `sort_name` text NOT NULL,
  `sort_name_auto_generate` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `authorized` int DEFAULT NULL,
  `is_display_name` int DEFAULT NULL,
  `family_type` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `transliteration_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `family_one_authorized` (`authorized`,`agent_family_id`),
  UNIQUE KEY `family_one_display_name` (`is_display_name`,`agent_family_id`),
  KEY `source_id` (`source_id`),
  KEY `rules_id` (`rules_id`),
  KEY `name_family_system_mtime_index` (`system_mtime`),
  KEY `name_family_user_mtime_index` (`user_mtime`),
  KEY `agent_family_id` (`agent_family_id`),
  CONSTRAINT `name_family_ibfk_1` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_family_ibfk_2` FOREIGN KEY (`rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_family_ibfk_3` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `name_family`
--

LOCK TABLES `name_family` WRITE;
/*!40000 ALTER TABLE `name_family` DISABLE KEYS */;
INSERT INTO `name_family` VALUES (3,0,1,2,'Family 1','Prefix 1','1800-1900','Qualifier 1',236,241,'Family 1, Prefix 1 (Qualifier 1) (1800-1900) (Location 1)',1,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',1,1,'Type 1','Location 1',515,1582,1715),(4,0,1,2,'Family 2','Prefix 2','Dates','Qualifier',237,242,'Family 2, Prefix 2 (Qualifier) (Dates) (Location 2)',1,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,'Type 2','Location 2',542,1580,NULL);
/*!40000 ALTER TABLE `name_family` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `name_person`
--

DROP TABLE IF EXISTS `name_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `name_person` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `agent_person_id` int NOT NULL,
  `primary_name` varchar(255) NOT NULL,
  `name_order_id` int NOT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `prefix` text,
  `rest_of_name` text,
  `suffix` text,
  `fuller_form` text,
  `number` varchar(255) DEFAULT NULL,
  `dates` varchar(255) DEFAULT NULL,
  `qualifier` text,
  `source_id` int DEFAULT NULL,
  `rules_id` int DEFAULT NULL,
  `sort_name` text NOT NULL,
  `sort_name_auto_generate` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `authorized` int DEFAULT NULL,
  `is_display_name` int DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `transliteration_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_one_authorized` (`authorized`,`agent_person_id`),
  UNIQUE KEY `person_one_display_name` (`is_display_name`,`agent_person_id`),
  KEY `name_order_id` (`name_order_id`),
  KEY `source_id` (`source_id`),
  KEY `rules_id` (`rules_id`),
  KEY `name_person_system_mtime_index` (`system_mtime`),
  KEY `name_person_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  CONSTRAINT `name_person_ibfk_1` FOREIGN KEY (`name_order_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_person_ibfk_2` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_person_ibfk_3` FOREIGN KEY (`rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_person_ibfk_4` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `name_person`
--

LOCK TABLES `name_person` WRITE;
/*!40000 ALTER TABLE `name_person` DISABLE KEYS */;
INSERT INTO `name_person` VALUES (1,0,1,1,'Administrator',947,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,236,240,'Administrator',1,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23',1,1,NULL,NULL,NULL),(4,0,1,3,'Primary 1',946,'Title','Prefix','Rest 1','Suffix','Fuller Form','Number','1800-1900','Qualifier 1',236,241,'Primary 1, Rest 1, Prefix, Suffix, Title, Number (Fuller Form), 1800-1900 (Qualifier 1)',1,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',1,1,515,1582,1715),(5,0,1,3,'Primary 2',947,'Title','Prefix','Rest 2','Suffix','Fuller','Number','Dates','Qualifier',237,242,'Rest 2 Primary 2, Prefix, Suffix, Title, Number (Fuller), Dates (Qualifier)',1,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,542,1580,NULL);
/*!40000 ALTER TABLE `name_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `name_software`
--

DROP TABLE IF EXISTS `name_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `name_software` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `agent_software_id` int NOT NULL,
  `software_name` text NOT NULL,
  `version` text,
  `manufacturer` text,
  `dates` varchar(255) DEFAULT NULL,
  `qualifier` text,
  `source_id` int DEFAULT NULL,
  `rules_id` int DEFAULT NULL,
  `sort_name` text NOT NULL,
  `sort_name_auto_generate` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `authorized` int DEFAULT NULL,
  `is_display_name` int DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `transliteration_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `software_one_authorized` (`authorized`,`agent_software_id`),
  UNIQUE KEY `software_one_display_name` (`is_display_name`,`agent_software_id`),
  KEY `source_id` (`source_id`),
  KEY `rules_id` (`rules_id`),
  KEY `name_software_system_mtime_index` (`system_mtime`),
  KEY `name_software_user_mtime_index` (`user_mtime`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `name_software_ibfk_1` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_software_ibfk_2` FOREIGN KEY (`rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `name_software_ibfk_3` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `name_software`
--

LOCK TABLES `name_software` WRITE;
/*!40000 ALTER TABLE `name_software` DISABLE KEYS */;
INSERT INTO `name_software` VALUES (1,0,1,1,'ArchivesSpace','SI-v4.1.0',NULL,NULL,NULL,236,240,'ArchivesSpace SI-v4.1.0',1,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23',1,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `name_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '1',
  `resource_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `notes_json_schema_version` int NOT NULL,
  `notes` mediumblob NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `rights_statement_act_id` int DEFAULT NULL,
  `rights_statement_id` int DEFAULT NULL,
  `lang_material_id` int DEFAULT NULL,
  `agent_topic_id` int DEFAULT NULL,
  `agent_place_id` int DEFAULT NULL,
  `agent_occupation_id` int DEFAULT NULL,
  `agent_function_id` int DEFAULT NULL,
  `agent_gender_id` int DEFAULT NULL,
  `used_language_id` int DEFAULT NULL,
  `agent_contact_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `note_system_mtime_index` (`system_mtime`),
  KEY `note_user_mtime_index` (`user_mtime`),
  KEY `resource_id` (`resource_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_software_id` (`agent_software_id`),
  KEY `rights_statement_act_id` (`rights_statement_act_id`),
  KEY `rights_statement_id` (`rights_statement_id`),
  KEY `lang_material_id` (`lang_material_id`),
  CONSTRAINT `note_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `note_ibfk_10` FOREIGN KEY (`rights_statement_id`) REFERENCES `rights_statement` (`id`),
  CONSTRAINT `note_ibfk_11` FOREIGN KEY (`lang_material_id`) REFERENCES `lang_material` (`id`),
  CONSTRAINT `note_ibfk_2` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `note_ibfk_3` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `note_ibfk_4` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`),
  CONSTRAINT `note_ibfk_5` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `note_ibfk_6` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `note_ibfk_7` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `note_ibfk_8` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `note_ibfk_9` FOREIGN KEY (`rights_statement_act_id`) REFERENCES `rights_statement_act` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
INSERT INTO `note` VALUES (11,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_contact_note\",\"persistent_id\":\"ContactPersID1\",\"date_of_contact\":\"Date of Contact\",\"contact_notes\":\"Contact Note 1\"}','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5),(12,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_contact_note\",\"persistent_id\":\"ContactPersID2\",\"date_of_contact\":\"Date of Contact\",\"contact_notes\":\"Contact Note 2\"}','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5),(13,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_citation\",\"persistent_id\":\"CitationPersistentID1\",\"content\":[\"Content 1\"],\"xlink\":{\"actuate\":\"Actuate\",\"arcrole\":\"Arc Role\",\"href\":\"Href\",\"role\":\"Role\",\"show\":\"Show\",\"title\":\"Title\",\"type\":\"Type\"}}','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,NULL),(14,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,NULL),(15,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Text content\"}','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL),(16,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),(17,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),(18,1,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_bioghist\",\"persistent_id\":\"BiogHistPersistentID1\",\"label\":\"Biographical note\",\"subnotes\":[{\"jsonmodel_type\":\"note_abstract\",\"persistent_id\":\"SubPersistentID1\",\"publish\":true,\"content\":[\"Abstract 1 Content 1.\",\"Abstract 1 Content 2.\"],\"subnote_guid\":\"4792a3bd8ccddf69338d5909db7e1be5\"}]}','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,1,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_general_context\",\"persistent_id\":\"GeneralPersistentID1\",\"label\":\"General Context 1\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1.\",\"publish\":false,\"subnote_guid\":\"dccf89fb25264d78b4623df03cb7c56d\"},{\"jsonmodel_type\":\"note_definedlist\",\"title\":\"Defined List\",\"publish\":true,\"items\":[{\"label\":\"Item\",\"value\":\"1\"},{\"label\":\"Item\",\"value\":\"2\"}],\"subnote_guid\":\"152e6d31854f2fa41e03cdbe07be9780\"},{\"jsonmodel_type\":\"note_outline\",\"publish\":true,\"levels\":[{\"jsonmodel_type\":\"note_outline_level\",\"items\":[{\"jsonmodel_type\":\"note_outline_level\",\"items\":[\"Item 1\",\"Item 2\",{\"jsonmodel_type\":\"note_outline_level\",\"items\":[\"Item 3\"],\"subnote_guid\":\"84d459bd14509d87a1512123b041dbb9\"}],\"subnote_guid\":\"1bcea9a37a560d2dd3b9f852580e376b\"}],\"subnote_guid\":\"60fde6abe68322f8cfa8815905797556\"}],\"subnote_guid\":\"0a291c7063b4207a471c8caae16bb00d\"}]}','admin','admin','2026-03-06 20:48:44','2026-03-06 20:48:44','2026-03-06 20:48:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_contact_note\",\"persistent_id\":\"ContactPersID1\",\"date_of_contact\":\"Date of Contact\",\"contact_notes\":\"Contact Note 1\"}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6),(21,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_contact_note\",\"persistent_id\":\"ContactPersID2\",\"date_of_contact\":\"Date of Contact\",\"contact_notes\":\"Contact Note 2\"}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6),(22,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_citation\",\"persistent_id\":\"CitationPersistentID1\",\"content\":[\"Content 1\"],\"xlink\":{\"actuate\":\"Actuate\",\"arcrole\":\"Arc Role\",\"href\":\"Href\",\"role\":\"Role\",\"show\":\"Show\",\"title\":\"Title\",\"type\":\"Type\"}}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,5,NULL,NULL,NULL,NULL,NULL),(23,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,5,NULL,NULL,NULL,NULL,NULL),(24,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Text content\"}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL),(25,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL),(26,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL),(27,1,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_bioghist\",\"persistent_id\":\"BiogHistPersistentID1\",\"label\":\"Biographical note\",\"subnotes\":[{\"jsonmodel_type\":\"note_abstract\",\"persistent_id\":\"SubPersistentID1\",\"publish\":true,\"content\":[\"Abstract 1 Content 1.\",\"Abstract 1 Content 2.\"],\"subnote_guid\":\"243dbbe3a55305dfba71f44c3a621572\"}]}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,1,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_general_context\",\"persistent_id\":\"GeneralPersistentID1\",\"label\":\"General Context 1\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1.\",\"publish\":false,\"subnote_guid\":\"b2e5972e5edac2e8ae6b0bc2dc9ef600\"},{\"jsonmodel_type\":\"note_definedlist\",\"title\":\"Defined List\",\"publish\":true,\"items\":[{\"label\":\"Item\",\"value\":\"1\"},{\"label\":\"Item\",\"value\":\"2\"}],\"subnote_guid\":\"96d0dc06331da8ba65b9434c9b8827ac\"},{\"jsonmodel_type\":\"note_outline\",\"publish\":true,\"levels\":[{\"jsonmodel_type\":\"note_outline_level\",\"items\":[{\"jsonmodel_type\":\"note_outline_level\",\"items\":[\"Item 1\",\"Item 2\",{\"jsonmodel_type\":\"note_outline_level\",\"items\":[\"Item 3\"],\"subnote_guid\":\"7073cc1d097b83848b923ad7a0f13e30\"}],\"subnote_guid\":\"1ec9ae6197ff78f8fe1e5fb4fd72f760\"}],\"subnote_guid\":\"486092ad08cd525cd163f8c7c7ff9705\"}],\"subnote_guid\":\"cf8a07535760e520c32bda745b937f3c\"}]}','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_contact_note\",\"persistent_id\":\"ContactPersID1\",\"date_of_contact\":\"Date of Contact\",\"contact_notes\":\"Contact Note 1\"}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7),(30,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_contact_note\",\"persistent_id\":\"ContactPersID2\",\"date_of_contact\":\"Date of Contact\",\"contact_notes\":\"Contact Note 2\"}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7),(31,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_citation\",\"persistent_id\":\"CitationPersistentID1\",\"content\":[\"Content 1\"],\"xlink\":{\"actuate\":\"Actuate\",\"arcrole\":\"Arc Role\",\"href\":\"Href\",\"role\":\"Role\",\"show\":\"Show\",\"title\":\"Title\",\"type\":\"Type\"}}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,6,NULL,NULL,NULL,NULL,NULL),(32,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,6,NULL,NULL,NULL,NULL,NULL),(33,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Text content\"}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL),(34,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL),(35,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1\"}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL),(36,1,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_bioghist\",\"persistent_id\":\"BiogHistPersistentID1\",\"label\":\"Biographical note\",\"subnotes\":[{\"jsonmodel_type\":\"note_abstract\",\"persistent_id\":\"SubPersistentID1\",\"publish\":true,\"content\":[\"Abstract 1 Content 1.\",\"Abstract 1 Content 2.\"],\"subnote_guid\":\"3dfcd516114cdfafe88168cfd1428b1f\"}]}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,1,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_general_context\",\"persistent_id\":\"GeneralPersistentID1\",\"label\":\"General Context 1\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Content 1.\",\"publish\":false,\"subnote_guid\":\"65beb2cbe643a0abdc25d16290463d44\"},{\"jsonmodel_type\":\"note_definedlist\",\"title\":\"Defined List\",\"publish\":true,\"items\":[{\"label\":\"Item\",\"value\":\"1\"},{\"label\":\"Item\",\"value\":\"2\"}],\"subnote_guid\":\"073d0d473c2aa3d101cb7d3298497725\"},{\"jsonmodel_type\":\"note_outline\",\"publish\":true,\"levels\":[{\"jsonmodel_type\":\"note_outline_level\",\"items\":[{\"jsonmodel_type\":\"note_outline_level\",\"items\":[\"Item 1\",\"Item 2\",{\"jsonmodel_type\":\"note_outline_level\",\"items\":[\"Item 3\"],\"subnote_guid\":\"7c51df64bb6e32e2882b63e5e6891fa6\"}],\"subnote_guid\":\"f26a274b8633b73c5be7cc81c6adbd2a\"}],\"subnote_guid\":\"1bf028663adfd05e74f6a9aad0a84711\"}],\"subnote_guid\":\"8e5e12e13244dee466dbc2b86e6e73ec\"}]}','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_langmaterial\",\"label\":\"Language of Materials label\",\"type\":\"langmaterial\",\"content\":[\"Language of Materials note 1\",\"Language of Materials note 2\"],\"persistent_id\":\"6e566b7fb21f4053b79a6d2b3da2932f\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_rights_statement_act\",\"label\":\"Expiration label\",\"type\":\"expiration\",\"content\":[\"Expiration content\"],\"persistent_id\":\"e312112133d6bdfa84075447ac3947c0\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(40,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_rights_statement\",\"label\":\"Additional Information label\",\"type\":\"additional_information\",\"content\":[\"Additional Information Content 1\",\"Additional Information Content 2\"],\"persistent_id\":\"4f6c1ba9704a54d0c3058f6c3d652e30\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(41,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_rights_statement\",\"label\":\"Materials label\",\"type\":\"materials\",\"content\":[\"Materials content 1\",\"Materials content 2\"],\"persistent_id\":\"9da6a7f46a44bdd5a52e3e09ef700519\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(42,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_singlepart\",\"label\":\"Abstract label\",\"type\":\"abstract\",\"content\":[\"Abstract content\"],\"persistent_id\":\"c27c23b981a97736304d3a4721b58c30\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(43,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Accruals label\",\"type\":\"accruals\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Accruals content\",\"publish\":true,\"subnote_guid\":\"800d6cf862bc89efcb68ee9dcf451ff9\"},{\"jsonmodel_type\":\"note_chronology\",\"title\":\"Chronology note\",\"items\":[{\"event_date\":\"Event Date\",\"place\":\"Event Place\",\"events\":[\"Event Item 1\",\"Event Item 2\"]}],\"publish\":true,\"subnote_guid\":\"77640904a86ac7a34b44c634934381f5\"}],\"persistent_id\":\"e556c1aa3b8c4b526c3ec5e81c75d3f5\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(44,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Appraisal label\",\"type\":\"appraisal\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Appraisal content\",\"publish\":true,\"subnote_guid\":\"d5feb39d054e4428429238894f219705\"},{\"jsonmodel_type\":\"note_definedlist\",\"title\":\"Defined note\",\"items\":[{\"label\":\"Label 1\",\"value\":\"Value 1\"},{\"label\":\"Label 2\",\"value\":\"Value 2\"}],\"publish\":false,\"subnote_guid\":\"650d6feb04af4d15a50af27710dc9e3a\"}],\"persistent_id\":\"3a014c83a12bb70e43bafd54c8edb79f\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(45,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Arrangement label\",\"type\":\"arrangement\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Arrangement content\",\"publish\":false,\"subnote_guid\":\"5dd98b9654d174a7f8b88a4f63e439e4\"},{\"jsonmodel_type\":\"note_orderedlist\",\"title\":\"Ordered note\",\"enumeration\":\"arabic\",\"items\":[\"Item 1\",\"Item 2\"],\"publish\":true,\"subnote_guid\":\"0eded7bb9ef3fffb461aa2b339629cec\"}],\"persistent_id\":\"5d51904c05fc384127dfb1d23b807927\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(46,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_bibliography\",\"label\":\"Bibliography label\",\"content\":[\"Bibliography content\"],\"items\":[\"Bibliography Item 1\",\"Bibliography Item 2\"],\"persistent_id\":\"7ed822786439e44787f9d72ad80632ad\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Biographical Historical label\",\"type\":\"bioghist\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Biographical Historical content 1\",\"publish\":true,\"subnote_guid\":\"233fa29f877afc4fc42bafbe263af7e7\"},{\"jsonmodel_type\":\"note_text\",\"content\":\"Biographical Historical content 2\",\"publish\":false,\"subnote_guid\":\"8521be2a5a82e8142770b1280ce56cb3\"}],\"persistent_id\":\"eacc3805054e8ac88df77a6939277733\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(48,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Conditions Governing Access label\",\"type\":\"accessrestrict\",\"rights_restriction\":{\"begin\":\"2025-08-01\",\"end\":\"2025-08-08\",\"local_access_restriction_type\":[\"RestrictedSpecColl\",\"RestrictedFragileSpecColl\"]},\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Conditions Governing Access content 1\",\"publish\":true,\"subnote_guid\":\"9a9f84b4b06c6ade3764d5a98cb88f21\"},{\"jsonmodel_type\":\"note_text\",\"content\":\"Conditions Governing Access content 2\",\"publish\":false,\"subnote_guid\":\"628c15f4ea49107e76ebb76bdcc69c17\"}],\"persistent_id\":\"e56ddaf7fdfe07b1be6f4199cb9fcfd7\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(49,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Conditions Governing Use label\",\"type\":\"userestrict\",\"rights_restriction\":{\"begin\":\"2025-08-01\",\"end\":\"2025-08-08\",\"local_access_restriction_type\":[]},\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Conditions Governing Use content\",\"publish\":false,\"subnote_guid\":\"8e0844f8628abd9b35f0870e1e4026e4\"}],\"persistent_id\":\"3c81acd120b3a20b5eff61a2ade614c1\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(50,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Custodial History label\",\"type\":\"custodhist\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Custodial History content\",\"publish\":false,\"subnote_guid\":\"96b37b40e199df27a9bd567bfce74510\"}],\"persistent_id\":\"45731a24eff17409489c4411e40467d1\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(51,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Custodial History label\",\"type\":\"custodhist\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Custodial History content\",\"publish\":false,\"subnote_guid\":\"1e396fcaf9aaf5ff0765079a7b08e65b\"}],\"persistent_id\":\"01baee6dca9216853832155b12bda4fe\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(52,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Dimensions label\",\"type\":\"dimensions\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Dimensions content\",\"publish\":true,\"subnote_guid\":\"4de1a842bc8207e92b122647542cbf2f\"}],\"persistent_id\":\"09ebb83ac3d0b319efd0fc5ac35ab06b\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(53,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Existence and Location of Copies label\",\"type\":\"altformavail\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Existence and Location of Copies content\",\"publish\":false,\"subnote_guid\":\"23d1418f3eacc0c696374d681abcaa8e\"}],\"persistent_id\":\"d2e999f92f194ce11178e9d918eb0497\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(54,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Existence and Location of Originals label\",\"type\":\"originalsloc\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Existence and Location of Originals content\",\"publish\":false,\"subnote_guid\":\"ea4273b8b018fc43c8f392d5856e93bd\"}],\"persistent_id\":\"2515bdde04fad0d773a6c203ee3d6b91\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(55,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"File Plan label\",\"type\":\"fileplan\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"File Plan content\",\"publish\":false,\"subnote_guid\":\"5d736f9895d2a23f0b4a8a880c74330a\"}],\"persistent_id\":\"d694b3cc419d4190b691cb9ea0a95681\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(56,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"General label\",\"type\":\"odd\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"General content\",\"publish\":true,\"subnote_guid\":\"33bdc5da27c73b5a80115b78558ae430\"}],\"persistent_id\":\"edd2babcdc1e26cdd0232fdd54286eec\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(57,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Immediate Source of Acquisition label\",\"type\":\"acqinfo\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Immediate Source of Acquisition content\",\"publish\":false,\"subnote_guid\":\"642b9f80a7b031774ae8c7b5dfed52f0\"}],\"persistent_id\":\"ef001116efa9fd744c802ccce33d1ea8\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(58,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_index\",\"label\":\"Index label\",\"content\":[\"Index content 1\",\"Index content 2\"],\"items\":[{\"jsonmodel_type\":\"note_index_item\",\"value\":\"Value 1\",\"type\":\"corporate_entity\",\"reference\":\"Reference 1\",\"reference_text\":\"Reference Text 1\",\"subnote_guid\":\"0d07d9c682d15528514b2d0f591635de\"},{\"jsonmodel_type\":\"note_index_item\",\"value\":\"Value 2\",\"type\":\"family\",\"reference\":\"Reference 2\",\"reference_text\":\"Reference Text 2\",\"subnote_guid\":\"53d2e38f5383c33acbc0f2dc029b1c0f\"}],\"persistent_id\":\"90e857558d06f7d331294f081b238875\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(59,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Legal Status label\",\"type\":\"legalstatus\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Legal Status content\",\"publish\":false,\"subnote_guid\":\"3a906c916279c7cdf2cac60e500d5f3b\"}],\"persistent_id\":\"1beea8e2b1513caee1737e67556e9d96\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(60,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_singlepart\",\"label\":\"Materials Specific Details label\",\"type\":\"materialspec\",\"content\":[\"Materials Specific Details content\"],\"persistent_id\":\"cf436aaf5bc45cf130e6f9929f31c449\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(61,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Other Finding Aids label\",\"type\":\"otherfindaid\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Other Finding Aids content\",\"publish\":false,\"subnote_guid\":\"a7c4b1329824723b4af36bfb79c9a7a3\"}],\"persistent_id\":\"e4cbc7e6937a6b23219a91594e934666\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(62,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Physical Characteristics and Technical Requirements label\",\"type\":\"phystech\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Physical Characteristics and Technical Requirements content\",\"publish\":false,\"subnote_guid\":\"b060e8bab772cdeb7f0bbc42fe85d0cb\"}],\"persistent_id\":\"62668c9686542f43a8c96d61e154a901\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(63,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_singlepart\",\"label\":\"Physical Description label\",\"type\":\"physdesc\",\"content\":[\"Physical Description content\"],\"persistent_id\":\"35776370f5b5bec69d769bf3ee08d639\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(64,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_singlepart\",\"label\":\"Physical Facet label\",\"type\":\"physfacet\",\"content\":[\"Physical Facet content\"],\"persistent_id\":\"886570d21359c03a592bb5237f8f9602\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_singlepart\",\"label\":\"Physical Location label\",\"type\":\"physloc\",\"content\":[\"Physical Location content\"],\"persistent_id\":\"ec3630ac4c8aef80406ac5a2f9187a4f\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(66,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Preferred Citation label\",\"type\":\"prefercite\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Preferred Citation content\",\"publish\":false,\"subnote_guid\":\"bd4746c265254dbf51cc919b8fc8067e\"}],\"persistent_id\":\"fa10f4c105113a90f88fd74406c27811\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(67,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Processing Information label\",\"type\":\"processinfo\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Processing Information content\",\"publish\":true,\"subnote_guid\":\"8808c5a14882568ecbdac6b7e704b5f5\"}],\"persistent_id\":\"bbf12f81d3ed312967e646b263ec6a41\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(68,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Related Materials label\",\"type\":\"relatedmaterial\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Related Materials content\",\"publish\":false,\"subnote_guid\":\"b3b717cb14cae170d52808fc9d9744d8\"}],\"persistent_id\":\"cfaa2b6c8e677ad85ccf9189d9da6868\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(69,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Scope and Contents label\",\"type\":\"scopecontent\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Scope and Contents content\",\"publish\":true,\"subnote_guid\":\"e51202bd726e688d2959e1ab46d6abb4\"}],\"persistent_id\":\"1fe4a701014a1a6e641373839fd11b1a\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(70,1,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,_binary '{\"jsonmodel_type\":\"note_multipart\",\"label\":\"Separated Materials label\",\"type\":\"separatedmaterial\",\"subnotes\":[{\"jsonmodel_type\":\"note_text\",\"content\":\"Separated Materials content\",\"publish\":false,\"subnote_guid\":\"d5e61d57ab23a622897465997285e525\"}],\"persistent_id\":\"164eb2a1182264db599582bce1fe9795\"}','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_persistent_id`
--

DROP TABLE IF EXISTS `note_persistent_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_persistent_id` (
  `id` int NOT NULL AUTO_INCREMENT,
  `note_id` int NOT NULL,
  `persistent_id` varchar(255) NOT NULL,
  `parent_type` varchar(255) NOT NULL,
  `parent_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `note_id` (`note_id`),
  CONSTRAINT `note_persistent_id_ibfk_1` FOREIGN KEY (`note_id`) REFERENCES `note` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_persistent_id`
--

LOCK TABLES `note_persistent_id` WRITE;
/*!40000 ALTER TABLE `note_persistent_id` DISABLE KEYS */;
INSERT INTO `note_persistent_id` VALUES (11,11,'ContactPersID1','agent_contact',5),(12,12,'ContactPersID2','agent_contact',5),(13,13,'CitationPersistentID1','agent_place',4),(14,18,'BiogHistPersistentID1','agent_person',3),(15,18,'SubPersistentID1','agent_person',3),(16,19,'GeneralPersistentID1','agent_person',3),(17,20,'ContactPersID1','agent_contact',6),(18,21,'ContactPersID2','agent_contact',6),(19,22,'CitationPersistentID1','agent_place',5),(20,27,'BiogHistPersistentID1','agent_corporate_entity',3),(21,27,'SubPersistentID1','agent_corporate_entity',3),(22,28,'GeneralPersistentID1','agent_corporate_entity',3),(23,29,'ContactPersID1','agent_contact',7),(24,30,'ContactPersID2','agent_contact',7),(25,31,'CitationPersistentID1','agent_place',6),(26,36,'BiogHistPersistentID1','agent_family',2),(27,36,'SubPersistentID1','agent_family',2),(28,37,'GeneralPersistentID1','agent_family',2),(29,38,'6e566b7fb21f4053b79a6d2b3da2932f','lang_material',10),(30,39,'e312112133d6bdfa84075447ac3947c0','rights_statement_act',2),(31,40,'4f6c1ba9704a54d0c3058f6c3d652e30','rights_statement',3),(32,41,'9da6a7f46a44bdd5a52e3e09ef700519','rights_statement',4),(33,42,'c27c23b981a97736304d3a4721b58c30','resource',7),(34,43,'e556c1aa3b8c4b526c3ec5e81c75d3f5','resource',7),(35,44,'3a014c83a12bb70e43bafd54c8edb79f','resource',7),(36,45,'5d51904c05fc384127dfb1d23b807927','resource',7),(37,46,'7ed822786439e44787f9d72ad80632ad','resource',7),(38,47,'eacc3805054e8ac88df77a6939277733','resource',7),(39,48,'e56ddaf7fdfe07b1be6f4199cb9fcfd7','resource',7),(40,49,'3c81acd120b3a20b5eff61a2ade614c1','resource',7),(41,50,'45731a24eff17409489c4411e40467d1','resource',7),(42,51,'01baee6dca9216853832155b12bda4fe','resource',7),(43,52,'09ebb83ac3d0b319efd0fc5ac35ab06b','resource',7),(44,53,'d2e999f92f194ce11178e9d918eb0497','resource',7),(45,54,'2515bdde04fad0d773a6c203ee3d6b91','resource',7),(46,55,'d694b3cc419d4190b691cb9ea0a95681','resource',7),(47,56,'edd2babcdc1e26cdd0232fdd54286eec','resource',7),(48,57,'ef001116efa9fd744c802ccce33d1ea8','resource',7),(49,58,'90e857558d06f7d331294f081b238875','resource',7),(50,59,'1beea8e2b1513caee1737e67556e9d96','resource',7),(51,60,'cf436aaf5bc45cf130e6f9929f31c449','resource',7),(52,61,'e4cbc7e6937a6b23219a91594e934666','resource',7),(53,62,'62668c9686542f43a8c96d61e154a901','resource',7),(54,63,'35776370f5b5bec69d769bf3ee08d639','resource',7),(55,64,'886570d21359c03a592bb5237f8f9602','resource',7),(56,65,'ec3630ac4c8aef80406ac5a2f9187a4f','resource',7),(57,66,'fa10f4c105113a90f88fd74406c27811','resource',7),(58,67,'bbf12f81d3ed312967e646b263ec6a41','resource',7),(59,68,'cfaa2b6c8e677ad85ccf9189d9da6868','resource',7),(60,69,'1fe4a701014a1a6e641373839fd11b1a','resource',7),(61,70,'164eb2a1182264db599582bce1fe9795','resource',7);
/*!40000 ALTER TABLE `note_persistent_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL,
  `code` varchar(255) NOT NULL,
  `params` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_time_index` (`time`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oai_config`
--

DROP TABLE IF EXISTS `oai_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oai_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oai_repository_name` varchar(255) DEFAULT NULL,
  `oai_record_prefix` varchar(255) DEFAULT NULL,
  `oai_admin_email` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `system_mtime` datetime DEFAULT NULL,
  `user_mtime` datetime DEFAULT NULL,
  `lock_version` int DEFAULT '0',
  `repo_set_codes` text,
  `repo_set_description` varchar(255) DEFAULT NULL,
  `sponsor_set_names` text,
  `sponsor_set_description` varchar(255) DEFAULT NULL,
  `repo_set_name` varchar(255) DEFAULT NULL,
  `sponsor_set_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oai_config`
--

LOCK TABLES `oai_config` WRITE;
/*!40000 ALTER TABLE `oai_config` DISABLE KEYS */;
INSERT INTO `oai_config` VALUES (1,'ArchivesSpace OAI Provider','oai:archivesspace','admin@example.com','admin',NULL,'2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51',0,'[]','','[]','','repository_set','sponsor_set');
/*!40000 ALTER TABLE `oai_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owner_repo_rlshp`
--

DROP TABLE IF EXISTS `owner_repo_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner_repo_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int DEFAULT NULL,
  `repository_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `owner_repo_rlshp_system_mtime_index` (`system_mtime`),
  KEY `owner_repo_rlshp_user_mtime_index` (`user_mtime`),
  KEY `location_id` (`location_id`),
  KEY `repository_id` (`repository_id`),
  CONSTRAINT `owner_repo_rlshp_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `owner_repo_rlshp_ibfk_2` FOREIGN KEY (`repository_id`) REFERENCES `repository` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owner_repo_rlshp`
--

LOCK TABLES `owner_repo_rlshp` WRITE;
/*!40000 ALTER TABLE `owner_repo_rlshp` DISABLE KEYS */;
/*!40000 ALTER TABLE `owner_repo_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parallel_name_corporate_entity`
--

DROP TABLE IF EXISTS `parallel_name_corporate_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parallel_name_corporate_entity` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `name_corporate_entity_id` int NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `jurisdiction` int DEFAULT '0',
  `conference_meeting` int DEFAULT '0',
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `transliteration_id` int DEFAULT NULL,
  `primary_name` text NOT NULL,
  `subordinate_name_1` text,
  `subordinate_name_2` text,
  `number` varchar(255) DEFAULT NULL,
  `dates` varchar(255) DEFAULT NULL,
  `qualifier` text,
  `source_id` int DEFAULT NULL,
  `rules_id` int DEFAULT NULL,
  `sort_name` text NOT NULL,
  `sort_name_auto_generate` int DEFAULT '1',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source_id` (`source_id`),
  KEY `rules_id` (`rules_id`),
  KEY `parallel_name_corporate_entity_system_mtime_index` (`system_mtime`),
  KEY `parallel_name_corporate_entity_user_mtime_index` (`user_mtime`),
  KEY `name_corporate_entity_id` (`name_corporate_entity_id`),
  CONSTRAINT `parallel_name_corporate_entity_ibfk_1` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_corporate_entity_ibfk_2` FOREIGN KEY (`rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_corporate_entity_ibfk_3` FOREIGN KEY (`name_corporate_entity_id`) REFERENCES `name_corporate_entity` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parallel_name_corporate_entity`
--

LOCK TABLES `parallel_name_corporate_entity` WRITE;
/*!40000 ALTER TABLE `parallel_name_corporate_entity` DISABLE KEYS */;
INSERT INTO `parallel_name_corporate_entity` VALUES (2,0,1,4,'Location 2',1,0,515,1582,1715,'Parallel Primary 1','Sub Parallel 1-1','Sub Parallel 1-2','Parallel Number','Parallel Dates','Parallel Qualifier',NULL,NULL,'Parallel Primary 1. Sub Parallel 1-1. Sub Parallel 1-2, Parallel Number (Parallel Qualifier) (Parallel Dates) (Location 2)',1,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45');
/*!40000 ALTER TABLE `parallel_name_corporate_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parallel_name_family`
--

DROP TABLE IF EXISTS `parallel_name_family`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parallel_name_family` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `name_family_id` int NOT NULL,
  `family_type` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `transliteration_id` int DEFAULT NULL,
  `family_name` text NOT NULL,
  `prefix` text,
  `dates` varchar(255) DEFAULT NULL,
  `qualifier` text,
  `source_id` int DEFAULT NULL,
  `rules_id` int DEFAULT NULL,
  `sort_name` text NOT NULL,
  `sort_name_auto_generate` int DEFAULT '1',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source_id` (`source_id`),
  KEY `rules_id` (`rules_id`),
  KEY `parallel_name_family_system_mtime_index` (`system_mtime`),
  KEY `parallel_name_family_user_mtime_index` (`user_mtime`),
  KEY `name_family_id` (`name_family_id`),
  CONSTRAINT `parallel_name_family_ibfk_1` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_family_ibfk_2` FOREIGN KEY (`rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_family_ibfk_3` FOREIGN KEY (`name_family_id`) REFERENCES `name_family` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parallel_name_family`
--

LOCK TABLES `parallel_name_family` WRITE;
/*!40000 ALTER TABLE `parallel_name_family` DISABLE KEYS */;
INSERT INTO `parallel_name_family` VALUES (2,0,1,3,'Type Parallel 1','Location 2',515,1582,1715,'Parallel Family 1','Parallel Prefix 1','Parallel Dates','Parallel Qualifier',NULL,NULL,'Parallel Family 1, Parallel Prefix 1 (Parallel Qualifier) (Parallel Dates) (Location 2)',1,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46');
/*!40000 ALTER TABLE `parallel_name_family` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parallel_name_person`
--

DROP TABLE IF EXISTS `parallel_name_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parallel_name_person` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `name_person_id` int NOT NULL,
  `primary_name` varchar(255) NOT NULL,
  `name_order_id` int NOT NULL,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `transliteration_id` int DEFAULT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `prefix` text,
  `rest_of_name` text,
  `suffix` text,
  `fuller_form` text,
  `number` varchar(255) DEFAULT NULL,
  `dates` varchar(255) DEFAULT NULL,
  `qualifier` text,
  `source_id` int DEFAULT NULL,
  `rules_id` int DEFAULT NULL,
  `sort_name` text NOT NULL,
  `sort_name_auto_generate` int DEFAULT '1',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name_order_id` (`name_order_id`),
  KEY `source_id` (`source_id`),
  KEY `rules_id` (`rules_id`),
  KEY `parallel_name_person_system_mtime_index` (`system_mtime`),
  KEY `parallel_name_person_user_mtime_index` (`user_mtime`),
  KEY `name_person_id` (`name_person_id`),
  CONSTRAINT `parallel_name_person_ibfk_1` FOREIGN KEY (`name_order_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_person_ibfk_2` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_person_ibfk_3` FOREIGN KEY (`rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_person_ibfk_4` FOREIGN KEY (`name_person_id`) REFERENCES `name_person` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parallel_name_person`
--

LOCK TABLES `parallel_name_person` WRITE;
/*!40000 ALTER TABLE `parallel_name_person` DISABLE KEYS */;
INSERT INTO `parallel_name_person` VALUES (2,0,1,4,'Parallel Primary 1',946,515,1582,1715,'Parallel Title','Parallel Prefix','Parallel Rest 1','Parallel Suffix','Parallel Fuller','Parallel Number','Parallel Dates','Parallel Qualifier',NULL,NULL,'Parallel Primary 1, Parallel Rest 1, Parallel Prefix, Parallel Suffix, Parallel Title, Parallel Number (Parallel Fuller), Parallel Dates (Parallel Qualifier)',1,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43');
/*!40000 ALTER TABLE `parallel_name_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parallel_name_software`
--

DROP TABLE IF EXISTS `parallel_name_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parallel_name_software` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `name_software_id` int NOT NULL,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `transliteration_id` int DEFAULT NULL,
  `software_name` text NOT NULL,
  `version` text,
  `manufacturer` text,
  `dates` varchar(255) DEFAULT NULL,
  `qualifier` text,
  `source_id` int DEFAULT NULL,
  `rules_id` int DEFAULT NULL,
  `sort_name` text NOT NULL,
  `sort_name_auto_generate` int DEFAULT '1',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source_id` (`source_id`),
  KEY `rules_id` (`rules_id`),
  KEY `parallel_name_software_system_mtime_index` (`system_mtime`),
  KEY `parallel_name_software_user_mtime_index` (`user_mtime`),
  KEY `name_software_id` (`name_software_id`),
  CONSTRAINT `parallel_name_software_ibfk_1` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_software_ibfk_2` FOREIGN KEY (`rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `parallel_name_software_ibfk_3` FOREIGN KEY (`name_software_id`) REFERENCES `name_software` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parallel_name_software`
--

LOCK TABLES `parallel_name_software` WRITE;
/*!40000 ALTER TABLE `parallel_name_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `parallel_name_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permission_code` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `level` varchar(255) DEFAULT 'repository',
  `system` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_code` (`permission_code`),
  KEY `permission_system_mtime_index` (`system_mtime`),
  KEY `permission_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,'create_job','The ability to create background jobs','repository',0,'admin','admin','2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(2,'cancel_job','The ability to cancel background jobs','repository',0,'admin','admin','2026-02-27 23:16:50','2026-02-27 23:16:50','2026-02-27 23:16:50'),(3,'manage_enumeration_record','The ability to create, modify and delete a controlled vocabulary list record','repository',0,'admin','admin','2026-02-27 23:16:51','2026-02-27 23:16:51','2026-02-27 23:16:51'),(4,'view_agent_contact_record','The ability to view contact details for agent records','repository',0,'admin','admin','2026-02-27 23:16:52','2026-02-27 23:16:52','2026-02-27 23:16:52'),(5,'show_full_agents','The ability to add and edit extended agent attributes','repository',0,'admin','admin','2026-02-27 23:16:54','2026-02-27 23:16:54','2026-02-27 23:16:54'),(6,'administer_system','The ability to act as a system administrator','global',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(7,'manage_users','The ability to manage user accounts while logged in','global',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(8,'become_user','The ability to masquerade as another user','global',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(9,'view_all_records','The ability to view any record in the system','global',1,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(10,'create_repository','The ability to create new repositories','global',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(11,'delete_repository','The ability to delete a repository','global',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(12,'transfer_repository','The ability to transfer the contents of a repository','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(13,'index_system','The ability to read any record for indexing','global',1,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(14,'manage_repository','The ability to manage a given repository','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(15,'update_accession_record','The ability to create and modify accessions records','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(16,'update_resource_record','The ability to create and modify resources records','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(17,'update_digital_object_record','The ability to create and modify digital objects records','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(18,'update_event_record','The ability to create and modify event records','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(19,'delete_event_record','The ability to delete event records','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(20,'suppress_archival_record','The ability to suppress the major archival record types: accessions/resources/digital objects/components/collection management/events','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(21,'transfer_archival_record','The ability to transfer records between different repositories','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(22,'delete_archival_record','The ability to delete the major archival record types: accessions/resources/digital objects/components/collection management/events','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(23,'view_suppressed','The ability to view suppressed records in a given repository','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(24,'view_repository','The ability to view a given repository','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(25,'update_classification_record','The ability to create and modify classification records','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(26,'delete_classification_record','The ability to delete classification records','repository',0,NULL,NULL,'2026-02-27 23:17:23','2026-02-27 23:17:23','2026-02-27 23:17:23'),(27,'mediate_edits','Track concurrent updates to records','global',1,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(28,'import_records','The ability to initiate an importer job','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(29,'cancel_importer_job','The ability to cancel a queued or running importer job','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(30,'manage_subject_record','The ability to create, modify and delete a subject record','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(31,'manage_agent_record','The ability to create, modify and delete an agent record','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(32,'manage_vocabulary_record','The ability to create, modify and delete a vocabulary record','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(33,'merge_agents_and_subjects','The ability to merge agent/subject records','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(34,'merge_archival_record','The ability to merge archival records records','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(35,'manage_rde_templates','The ability to create and delete RDE templates','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(36,'update_container_record','The ability to create and update container records','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(37,'manage_container_record','The ability to delete and bulk update container records','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(38,'manage_container_profile_record','The ability to create, modify and delete a container profile record','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(39,'manage_location_profile_record','The ability to create, modify and delete a location profile record','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(40,'update_assessment_record','The ability to create and modify assessment records','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(41,'delete_assessment_record','The ability to delete assessment records','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(42,'manage_assessment_attributes','The ability to manage assessment attribute definitions','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24'),(43,'manage_custom_report_templates','The ability to manage custom report templates','repository',0,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24');
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preference`
--

DROP TABLE IF EXISTS `preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preference` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `user_uniq` varchar(255) NOT NULL,
  `defaults` mediumblob NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `preference_uniq` (`repo_id`,`user_uniq`),
  KEY `preference_system_mtime_index` (`system_mtime`),
  KEY `preference_user_mtime_index` (`user_mtime`),
  KEY `preference_user_id_fk` (`user_id`),
  CONSTRAINT `preference_repo_id_fk` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`) ON DELETE CASCADE,
  CONSTRAINT `preference_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preference`
--

LOCK TABLES `preference` WRITE;
/*!40000 ALTER TABLE `preference` DISABLE KEYS */;
INSERT INTO `preference` VALUES (1,5,1,1,NULL,'GLOBAL_USER',_binary '{\"show_suppressed\":false,\"publish\":false,\"rde_sort_alpha\":true,\"include_unpublished\":false,\"digital_object_spawn\":false,\"accession_browse_column_1\":\"title\",\"accession_browse_column_2\":\"identifier\",\"accession_browse_column_3\":\"accession_date\",\"accession_browse_column_4\":\"dates\",\"accession_browse_column_5\":\"extents\",\"accession_sort_column\":\"title\",\"accession_sort_direction\":\"asc\",\"resource_browse_column_1\":\"title\",\"resource_browse_column_2\":\"identifier\",\"resource_browse_column_3\":\"level\",\"resource_browse_column_4\":\"dates\",\"resource_browse_column_5\":\"extents\",\"resource_sort_column\":\"title\",\"resource_sort_direction\":\"asc\",\"digital_object_browse_column_1\":\"title\",\"digital_object_browse_column_2\":\"digital_object_id\",\"digital_object_sort_column\":\"title\",\"digital_object_sort_direction\":\"asc\",\"multi_browse_column_1\":\"primary_type\",\"multi_browse_column_2\":\"title\",\"multi_browse_column_3\":\"context\",\"multi_browse_column_4\":\"identifier\",\"multi_browse_column_5\":\"dates\",\"multi_sort_column\":\"score\",\"multi_sort_direction\":\"desc\",\"location_browse_column_1\":\"title\",\"location_browse_column_2\":\"building\",\"location_browse_column_3\":\"floor\",\"location_browse_column_4\":\"room\",\"location_browse_column_5\":\"area\",\"location_browse_column_6\":\"location_profile_display_string_u_ssort\",\"location_browse_column_7\":\"location_holdings\",\"location_sort_column\":\"title\",\"location_sort_direction\":\"asc\",\"agent_browse_column_1\":\"primary_type\",\"agent_browse_column_2\":\"title\",\"agent_browse_column_3\":\"authority_id\",\"agent_browse_column_4\":\"source\",\"agent_browse_column_5\":\"rules\",\"agent_sort_column\":\"title\",\"agent_sort_direction\":\"asc\",\"archival_object_browse_column_1\":\"title\",\"archival_object_browse_column_2\":\"context\",\"archival_object_browse_column_3\":\"identifier\",\"archival_object_browse_column_4\":\"dates\",\"archival_object_browse_column_5\":\"extents\",\"archival_object_sort_column\":\"title\",\"archival_object_sort_direction\":\"asc\",\"assessment_browse_column_1\":\"assessment_id\",\"assessment_browse_column_2\":\"assessment_records\",\"assessment_browse_column_3\":\"assessment_surveyors\",\"assessment_browse_column_4\":\"assessment_completed\",\"assessment_sort_column\":\"assessment_id\",\"assessment_sort_direction\":\"asc\",\"classification_browse_column_1\":\"title\",\"classification_sort_column\":\"title\",\"classification_sort_direction\":\"asc\",\"collection_management_browse_column_1\":\"parent_title\",\"collection_management_browse_column_2\":\"parent_type\",\"collection_management_browse_column_3\":\"processing_priority\",\"collection_management_browse_column_4\":\"processing_status\",\"collection_management_browse_column_5\":\"processing_hours_total\",\"collection_management_sort_column\":\"parent_title\",\"collection_management_sort_direction\":\"asc\",\"container_profile_browse_column_1\":\"title\",\"container_profile_sort_column\":\"title\",\"container_profile_sort_direction\":\"asc\",\"digital_object_component_browse_column_1\":\"title\",\"digital_object_component_browse_column_2\":\"context\",\"digital_object_component_sort_column\":\"title\",\"digital_object_component_sort_direction\":\"asc\",\"event_browse_column_1\":\"event_type\",\"event_browse_column_2\":\"outcome\",\"event_browse_column_3\":\"agents\",\"event_browse_column_4\":\"linked_records\",\"event_sort_column\":\"event_type\",\"event_sort_direction\":\"asc\",\"location_profile_browse_column_1\":\"title\",\"location_profile_sort_column\":\"title\",\"location_profile_sort_direction\":\"asc\",\"repositories_browse_column_1\":\"title\",\"repositories_browse_column_2\":\"publish\",\"repositories_browse_column_3\":\"audit_info\",\"repositories_sort_column\":\"title\",\"repositories_sort_direction\":\"asc\",\"subject_browse_column_1\":\"title\",\"subject_sort_column\":\"title\",\"subject_sort_direction\":\"asc\",\"top_container_browse_column_1\":\"title\",\"top_container_browse_column_2\":\"context\",\"top_container_browse_column_3\":\"type\",\"top_container_browse_column_4\":\"indicator\",\"top_container_browse_column_5\":\"barcode\",\"top_container_browse_column_6\":\"container_profile_display_string_u_sstr\",\"top_container_browse_column_7\":\"location_display_string_u_sstr\",\"top_container_sort_column\":\"title\",\"top_container_sort_direction\":\"asc\",\"top_container_mgmt_browse_column_1\":\"resource_accession\",\"top_container_mgmt_browse_column_2\":\"series\",\"top_container_mgmt_browse_column_3\":\"container_profile\",\"top_container_mgmt_browse_column_4\":\"type\",\"top_container_mgmt_browse_column_5\":\"indicator\",\"top_container_mgmt_browse_column_6\":\"barcode\",\"top_container_mgmt_browse_column_7\":\"internal_note\",\"top_container_mgmt_sort_column\":\"resource_accession\",\"top_container_mgmt_sort_direction\":\"asc\",\"job_browse_column_1\":\"status\",\"job_browse_column_2\":\"job_report_type\",\"job_browse_column_3\":\"job_data\",\"job_browse_column_4\":\"audit_info\",\"job_sort_column\":\"time_submitted\",\"job_sort_direction\":\"desc\",\"locale\":\"en\",\"note_order\":[],\"default_values\":false}',NULL,NULL,'2026-02-27 23:17:24','2026-03-09 13:05:07','2026-03-09 13:05:07');
/*!40000 ALTER TABLE `preference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rde_template`
--

DROP TABLE IF EXISTS `rde_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rde_template` (
  `id` int NOT NULL AUTO_INCREMENT,
  `record_type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `order` blob,
  `visible` blob,
  `defaults` blob,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rde_template_system_mtime_index` (`system_mtime`),
  KEY `rde_template_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rde_template`
--

LOCK TABLES `rde_template` WRITE;
/*!40000 ALTER TABLE `rde_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `rde_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `related_accession_rlshp`
--

DROP TABLE IF EXISTS `related_accession_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `related_accession_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accession_id_0` int DEFAULT NULL,
  `accession_id_1` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `relator_id` int NOT NULL,
  `relator_type_id` int NOT NULL,
  `relationship_target_record_type` varchar(255) NOT NULL,
  `relationship_target_id` int NOT NULL,
  `jsonmodel_type` varchar(255) NOT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relator_id` (`relator_id`),
  KEY `relator_type_id` (`relator_type_id`),
  KEY `related_accession_rlshp_system_mtime_index` (`system_mtime`),
  KEY `related_accession_rlshp_user_mtime_index` (`user_mtime`),
  KEY `accession_id_0` (`accession_id_0`),
  KEY `accession_id_1` (`accession_id_1`),
  CONSTRAINT `related_accession_rlshp_ibfk_1` FOREIGN KEY (`relator_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `related_accession_rlshp_ibfk_2` FOREIGN KEY (`relator_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `related_accession_rlshp_ibfk_3` FOREIGN KEY (`accession_id_0`) REFERENCES `accession` (`id`),
  CONSTRAINT `related_accession_rlshp_ibfk_4` FOREIGN KEY (`accession_id_1`) REFERENCES `accession` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `related_accession_rlshp`
--

LOCK TABLES `related_accession_rlshp` WRITE;
/*!40000 ALTER TABLE `related_accession_rlshp` DISABLE KEYS */;
/*!40000 ALTER TABLE `related_accession_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `related_agents_rlshp`
--

DROP TABLE IF EXISTS `related_agents_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `related_agents_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_person_id_0` int DEFAULT NULL,
  `agent_person_id_1` int DEFAULT NULL,
  `agent_corporate_entity_id_0` int DEFAULT NULL,
  `agent_corporate_entity_id_1` int DEFAULT NULL,
  `agent_software_id_0` int DEFAULT NULL,
  `agent_software_id_1` int DEFAULT NULL,
  `agent_family_id_0` int DEFAULT NULL,
  `agent_family_id_1` int DEFAULT NULL,
  `jsonmodel_type` varchar(255) NOT NULL,
  `description` text,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `relationship_target_record_type` varchar(255) NOT NULL,
  `relationship_target_id` int NOT NULL,
  `relator_id` int NOT NULL,
  `specific_relator_id` int DEFAULT NULL,
  `relationship_uri` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `related_agents_rlshp_system_mtime_index` (`system_mtime`),
  KEY `related_agents_rlshp_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id_0` (`agent_person_id_0`),
  KEY `agent_person_id_1` (`agent_person_id_1`),
  KEY `agent_corporate_entity_id_0` (`agent_corporate_entity_id_0`),
  KEY `agent_corporate_entity_id_1` (`agent_corporate_entity_id_1`),
  KEY `agent_software_id_0` (`agent_software_id_0`),
  KEY `agent_software_id_1` (`agent_software_id_1`),
  KEY `agent_family_id_0` (`agent_family_id_0`),
  KEY `agent_family_id_1` (`agent_family_id_1`),
  KEY `relator_id` (`relator_id`),
  KEY `specific_relator_id` (`specific_relator_id`),
  CONSTRAINT `related_agents_rlshp_ibfk_1` FOREIGN KEY (`agent_person_id_0`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_10` FOREIGN KEY (`specific_relator_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_2` FOREIGN KEY (`agent_person_id_1`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id_0`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_4` FOREIGN KEY (`agent_corporate_entity_id_1`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_5` FOREIGN KEY (`agent_software_id_0`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_6` FOREIGN KEY (`agent_software_id_1`) REFERENCES `agent_software` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_7` FOREIGN KEY (`agent_family_id_0`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_8` FOREIGN KEY (`agent_family_id_1`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `related_agents_rlshp_ibfk_9` FOREIGN KEY (`relator_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `related_agents_rlshp`
--

LOCK TABLES `related_agents_rlshp` WRITE;
/*!40000 ALTER TABLE `related_agents_rlshp` DISABLE KEYS */;
INSERT INTO `related_agents_rlshp` VALUES (1,3,1,NULL,NULL,NULL,NULL,NULL,NULL,'agent_relationship_associative','Description',0,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'agent_person',1,881,NULL,'Relationship URI'),(2,3,1,NULL,NULL,NULL,NULL,NULL,NULL,'agent_relationship_parentchild','Description',1,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'agent_person',1,885,NULL,'Relationship URI'),(3,1,NULL,3,NULL,NULL,NULL,NULL,NULL,'agent_relationship_associative','Description',0,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'agent_person',1,881,NULL,'Relationship URI'),(4,1,NULL,3,NULL,NULL,NULL,NULL,NULL,'agent_relationship_hierarchical','Description',1,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'agent_person',1,1784,NULL,'Relationship URI'),(5,1,NULL,NULL,NULL,NULL,NULL,2,NULL,'agent_relationship_associative','Description',0,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'agent_person',1,881,NULL,'Relationship URI'),(6,1,NULL,NULL,NULL,NULL,NULL,2,NULL,'agent_relationship_hierarchical','Description',1,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'agent_person',1,1784,NULL,'Relationship URI');
/*!40000 ALTER TABLE `related_agents_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repository`
--

DROP TABLE IF EXISTS `repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repository` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `org_code` varchar(255) DEFAULT NULL,
  `parent_institution_name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `contact_persons` text,
  `country_id` int DEFAULT NULL,
  `agent_representation_id` int DEFAULT NULL,
  `hidden` int DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `publish` int DEFAULT NULL,
  `description` text,
  `oai_is_disabled` int DEFAULT '0',
  `oai_sets_available` text,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '1',
  `ark_shoulder` varchar(255) DEFAULT NULL,
  `position` int NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `repo_code` (`repo_code`),
  UNIQUE KEY `position` (`position`),
  KEY `country_id` (`country_id`),
  KEY `repository_system_mtime_index` (`system_mtime`),
  KEY `repository_user_mtime_index` (`user_mtime`),
  KEY `agent_representation_id` (`agent_representation_id`),
  CONSTRAINT `repository_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `repository_ibfk_2` FOREIGN KEY (`agent_representation_id`) REFERENCES `agent_corporate_entity` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository`
--

LOCK TABLES `repository` WRITE;
/*!40000 ALTER TABLE `repository` DISABLE KEYS */;
INSERT INTO `repository` VALUES (1,0,1,'_archivesspace','Global repository',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2026-02-27 23:17:22','2026-02-27 23:17:22','2026-02-27 23:17:22',NULL,NULL,0,NULL,'archivesspace',1,NULL,0),(2,0,1,'test_repo_37','Test repository 392',NULL,NULL,NULL,NULL,NULL,1246,1,0,'admin','admin','2026-02-27 23:18:03','2026-02-27 23:18:03','2026-02-27 23:18:03',0,NULL,0,NULL,'test_repo_37',1,NULL,1);
/*!40000 ALTER TABLE `repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `required_fields`
--

DROP TABLE IF EXISTS `required_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `required_fields` (
  `lock_version` int NOT NULL DEFAULT '0',
  `id` varchar(255) NOT NULL,
  `blob` blob NOT NULL,
  `repo_id` int NOT NULL,
  `record_type` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `required_fields_system_mtime_index` (`system_mtime`),
  KEY `required_fields_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `required_fields`
--

LOCK TABLES `required_fields` WRITE;
/*!40000 ALTER TABLE `required_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `required_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource`
--

DROP TABLE IF EXISTS `resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resource` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `repo_id` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `title` varchar(8704) NOT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `level_id` int NOT NULL,
  `other_level` varchar(255) DEFAULT NULL,
  `resource_type_id` int DEFAULT NULL,
  `publish` int DEFAULT NULL,
  `restrictions` int DEFAULT NULL,
  `repository_processing_note` text,
  `ead_id` varchar(255) DEFAULT NULL,
  `ead_location` varchar(255) DEFAULT NULL,
  `finding_aid_title` text,
  `finding_aid_filing_title` text,
  `finding_aid_date` varchar(255) DEFAULT NULL,
  `finding_aid_author` text,
  `finding_aid_description_rules_id` int DEFAULT NULL,
  `finding_aid_language_note` varchar(255) DEFAULT NULL,
  `finding_aid_sponsor` text,
  `finding_aid_edition_statement` text,
  `finding_aid_series_statement` text,
  `finding_aid_status_id` int DEFAULT NULL,
  `finding_aid_note` text,
  `system_generated` int DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `finding_aid_subtitle` text,
  `finding_aid_sponsor_sha1` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  `finding_aid_language_id` int DEFAULT NULL,
  `finding_aid_script_id` int DEFAULT NULL,
  `is_finding_aid_status_published` int DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `resource_unique_identifier` (`repo_id`,`identifier`),
  UNIQUE KEY `resource_unique_ead_id` (`repo_id`,`ead_id`),
  KEY `level_id` (`level_id`),
  KEY `resource_type_id` (`resource_type_id`),
  KEY `finding_aid_description_rules_id` (`finding_aid_description_rules_id`),
  KEY `finding_aid_status_id` (`finding_aid_status_id`),
  KEY `resource_system_mtime_index` (`system_mtime`),
  KEY `resource_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `resource_finding_aid_sponsor_sha1_index` (`finding_aid_sponsor_sha1`),
  CONSTRAINT `resource_ibfk_2` FOREIGN KEY (`level_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `resource_ibfk_3` FOREIGN KEY (`resource_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `resource_ibfk_4` FOREIGN KEY (`finding_aid_description_rules_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `resource_ibfk_5` FOREIGN KEY (`finding_aid_status_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `resource_ibfk_6` FOREIGN KEY (`repo_id`) REFERENCES `repository` (`id`),
  CONSTRAINT `resource_ibfk_7` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource`
--

LOCK TABLES `resource` WRITE;
/*!40000 ALTER TABLE `resource` DISABLE KEYS */;
INSERT INTO `resource` VALUES (1,0,1,2,NULL,'Test resource 4','[\"EAD\",\"4\",null,null]',889,NULL,NULL,0,0,NULL,'EAD.4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',0,NULL,NULL,NULL,1,515,1582,1),(2,0,1,2,NULL,'Test resource 3','[\"EAD\",\"3\",null,null]',889,NULL,NULL,0,0,NULL,'EAD.3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:04','2026-02-27 23:18:04',0,NULL,NULL,NULL,1,515,1582,1),(3,1,1,2,NULL,'Test resource 2','[\"EAD\",\"2\",null,null]',889,NULL,NULL,0,0,NULL,'EAD.2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'admin','admin','2026-02-27 23:18:04','2026-02-27 23:18:08','2026-02-27 23:18:04',0,NULL,NULL,NULL,1,515,1582,1),(4,1,1,2,NULL,'Test resource 1','[\"EAD\",\"1\",null,null]',889,NULL,NULL,0,0,NULL,'EAD.1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:09','2026-02-27 23:18:05',0,NULL,NULL,NULL,1,515,1582,1),(5,0,1,2,NULL,'Test resource 0','[\"EAD\",\"0\",null,null]',889,NULL,NULL,0,0,NULL,'EAD.0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'admin','admin','2026-02-27 23:18:05','2026-02-27 23:18:07','2026-02-27 23:18:05',0,NULL,NULL,NULL,1,515,1582,1),(7,0,1,2,NULL,'Kitchen Sink resource','[\"EAD\",\"123456\",null,null]',889,NULL,332,0,1,'Repository Processing Note','EAD.123456','http://example.com/EAD.123456','Kitchen Sink resource','Kitchen Sink resource','Finding Aid Date','Finding Aid Author',337,'Language of Description Note','Sponsor','Edition Statement','Series Statement',342,'Finding Aid Note',0,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',0,'Finding Aid Subtitle','fd0b743b62904a6ea1fdc45de0541da77e0fa720',NULL,0,515,1582,1);
/*!40000 ALTER TABLE `resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revision_statement`
--

DROP TABLE IF EXISTS `revision_statement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revision_statement` (
  `id` int NOT NULL AUTO_INCREMENT,
  `resource_id` int DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `description` text,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `publish` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `revision_statement_system_mtime_index` (`system_mtime`),
  KEY `revision_statement_user_mtime_index` (`user_mtime`),
  KEY `resource_id` (`resource_id`),
  CONSTRAINT `revision_statement_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revision_statement`
--

LOCK TABLES `revision_statement` WRITE;
/*!40000 ALTER TABLE `revision_statement` DISABLE KEYS */;
INSERT INTO `revision_statement` VALUES (3,7,'08/12/2025','Revision Description 1','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',1),(4,7,'08/11/2025','Revision Description 2','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',0);
/*!40000 ALTER TABLE `revision_statement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights_restriction`
--

DROP TABLE IF EXISTS `rights_restriction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rights_restriction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `resource_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `restriction_note_type` varchar(255) DEFAULT NULL,
  `begin` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resource_id` (`resource_id`),
  KEY `archival_object_id` (`archival_object_id`),
  CONSTRAINT `rights_restriction_ibfk_1` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `rights_restriction_ibfk_2` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights_restriction`
--

LOCK TABLES `rights_restriction` WRITE;
/*!40000 ALTER TABLE `rights_restriction` DISABLE KEYS */;
INSERT INTO `rights_restriction` VALUES (1,7,NULL,'accessrestrict','2025-08-01','2025-08-08'),(2,7,NULL,'userestrict','2025-08-01','2025-08-08');
/*!40000 ALTER TABLE `rights_restriction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights_restriction_type`
--

DROP TABLE IF EXISTS `rights_restriction_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rights_restriction_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rights_restriction_id` int NOT NULL,
  `restriction_type_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `restriction_type_id` (`restriction_type_id`),
  KEY `rights_restriction_id` (`rights_restriction_id`),
  CONSTRAINT `rights_restriction_type_ibfk_1` FOREIGN KEY (`restriction_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `rights_restriction_type_ibfk_2` FOREIGN KEY (`rights_restriction_id`) REFERENCES `rights_restriction` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights_restriction_type`
--

LOCK TABLES `rights_restriction_type` WRITE;
/*!40000 ALTER TABLE `rights_restriction_type` DISABLE KEYS */;
INSERT INTO `rights_restriction_type` VALUES (1,1,1344),(2,1,1346);
/*!40000 ALTER TABLE `rights_restriction_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights_statement`
--

DROP TABLE IF EXISTS `rights_statement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rights_statement` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `repo_id` int DEFAULT NULL,
  `identifier` varchar(255) NOT NULL,
  `rights_type_id` int NOT NULL,
  `statute_citation` varchar(255) DEFAULT NULL,
  `jurisdiction_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `status_id` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `determination_date` date DEFAULT NULL,
  `license_terms` varchar(255) DEFAULT NULL,
  `other_rights_basis_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rights_type_id` (`rights_type_id`),
  KEY `jurisdiction_id` (`jurisdiction_id`),
  KEY `rights_statement_system_mtime_index` (`system_mtime`),
  KEY `rights_statement_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `resource_id` (`resource_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  KEY `rights_statement_status_id_fk` (`status_id`),
  KEY `rights_statement_other_rights_basis_id_fk` (`other_rights_basis_id`),
  CONSTRAINT `rights_statement_ibfk_1` FOREIGN KEY (`rights_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `rights_statement_ibfk_3` FOREIGN KEY (`jurisdiction_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `rights_statement_ibfk_4` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `rights_statement_ibfk_5` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `rights_statement_ibfk_6` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `rights_statement_ibfk_7` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `rights_statement_ibfk_8` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`),
  CONSTRAINT `rights_statement_other_rights_basis_id_fk` FOREIGN KEY (`other_rights_basis_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `rights_statement_status_id_fk` FOREIGN KEY (`status_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights_statement`
--

LOCK TABLES `rights_statement` WRITE;
/*!40000 ALTER TABLE `rights_statement` DISABLE KEYS */;
INSERT INTO `rights_statement` VALUES (3,0,1,NULL,NULL,7,NULL,NULL,NULL,'3c4872eeafbd78b186ac50855ce0ccaa',1260,NULL,1246,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',1264,'2025-08-01','2025-08-12','2025-08-01',NULL,NULL),(4,0,1,NULL,NULL,7,NULL,NULL,NULL,'0e28e5e47aa73302c1bdb7caa0c095ce',1262,'Statute Citation',1244,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47',NULL,'2025-08-02','2025-08-03','2025-08-01',NULL,NULL);
/*!40000 ALTER TABLE `rights_statement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights_statement_act`
--

DROP TABLE IF EXISTS `rights_statement_act`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rights_statement_act` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rights_statement_id` int NOT NULL,
  `act_type_id` int NOT NULL,
  `restriction_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `act_type_id` (`act_type_id`),
  KEY `restriction_id` (`restriction_id`),
  KEY `rights_statement_act_system_mtime_index` (`system_mtime`),
  KEY `rights_statement_act_user_mtime_index` (`user_mtime`),
  KEY `rights_statement_id` (`rights_statement_id`),
  CONSTRAINT `rights_statement_act_ibfk_1` FOREIGN KEY (`act_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `rights_statement_act_ibfk_2` FOREIGN KEY (`restriction_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `rights_statement_act_ibfk_3` FOREIGN KEY (`rights_statement_id`) REFERENCES `rights_statement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights_statement_act`
--

LOCK TABLES `rights_statement_act` WRITE;
/*!40000 ALTER TABLE `rights_statement_act` DISABLE KEYS */;
INSERT INTO `rights_statement_act` VALUES (2,3,1361,1367,'2025-08-01','2025-08-08','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47');
/*!40000 ALTER TABLE `rights_statement_act` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights_statement_pre_088`
--

DROP TABLE IF EXISTS `rights_statement_pre_088`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rights_statement_pre_088` (
  `id` int NOT NULL DEFAULT '0',
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `repo_id` int DEFAULT NULL,
  `identifier` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `rights_type_id` int NOT NULL,
  `active` int DEFAULT NULL,
  `materials` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ip_status_id` int DEFAULT NULL,
  `ip_expiration_date` date DEFAULT NULL,
  `license_identifier_terms` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `statute_citation` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `jurisdiction_id` int DEFAULT NULL,
  `type_note` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `permissions` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `restrictions` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `restriction_start_date` date DEFAULT NULL,
  `restriction_end_date` date DEFAULT NULL,
  `granted_note` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `created_by` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `last_modified_by` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights_statement_pre_088`
--

LOCK TABLES `rights_statement_pre_088` WRITE;
/*!40000 ALTER TABLE `rights_statement_pre_088` DISABLE KEYS */;
/*!40000 ALTER TABLE `rights_statement_pre_088` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_info`
--

DROP TABLE IF EXISTS `schema_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_info` (
  `version` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_info`
--

LOCK TABLES `schema_info` WRITE;
/*!40000 ALTER TABLE `schema_info` DISABLE KEYS */;
INSERT INTO `schema_info` VALUES (175);
/*!40000 ALTER TABLE `schema_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequence`
--

DROP TABLE IF EXISTS `sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequence` (
  `sequence_name` varchar(255) NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`sequence_name`),
  KEY `sequence_namevalue_idx` (`sequence_name`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequence`
--

LOCK TABLES `sequence` WRITE;
/*!40000 ALTER TABLE `sequence` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL,
  `system_mtime` datetime NOT NULL,
  `expirable` int DEFAULT '1',
  `session_data` blob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `session_system_mtime_index` (`system_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES (29,'9df4a7ee9198b7d546a994739abde2e6ff4ab2bb','2026-03-09 13:01:39',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ3UiB+AGz6Otwg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/rC5Ogl6\nb25lSSIIRVNUBjsGVDoOZXhwaXJhYmxlRg==\n'),(30,'684bccb1d721025257fb203e39b746dc77875c7b','2026-03-09 13:01:39',0,_binary 'BAh7CDoJdXNlckkiEXN0YWZmX3N5c3RlbQY6BkVUOg9sb2dpbl90aW1lSXU6\nCVRpbWUN1IgfgLsKCLgIOg1zdWJtaWNybyIGADoLb2Zmc2V0af6wuToJem9u\nZUkiCEVTVAY7BlQ6DmV4cGlyYWJsZUY=\n'),(31,'5a35bea95e4eafa46f2ad615ac52e0849bad043a','2026-03-09 13:01:04',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ3UiB+ALyceuAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/rC5Ogl6\nb25lSSIIRVNUBjsGVDoOZXhwaXJhYmxlRg==\n'),(34,'d1ccd7796966e5700b6de4e9e66e2d4f04fbee30','2026-03-09 13:01:39',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ3UiB+AKHOtuQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/rC5Ogl6\nb25lSSIIRVNUBjsGVDoOZXhwaXJhYmxlRg==\n'),(36,'aa5f47e9fd6253eb934e7d6e3efef23212139619','2026-03-06 21:34:36',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ3V\niB+AxBVOigg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/rC5Ogl6b25lSSIIRVNU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(37,'bf6d5af94e0d3d3b3645c621f31e9cca5693d1de','2026-03-06 21:38:42',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ3V\niB+AIomimgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/rC5Ogl6b25lSSIIRVNU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(38,'14aa90080e97a4dc602c2aaec272aeb479f44ad2','2026-03-09 13:01:34',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+AjH6jAwg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(39,'1489736d81c676e1ae40b31911e3811b4f77a085','2026-03-09 13:01:04',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+A9NkzBAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(40,'de2d517b511233f805ef3ed288a5dc3a4eb6346c','2026-03-09 13:01:29',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+A9InDBQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(41,'9e34ba25011066d471ffda6957e9e28f843a4f3c','2026-03-09 13:04:13',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+A+H05Cgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(42,'3ea28628028e175d4916daa3bc954cdacc22d741','2026-03-09 13:04:33',0,_binary 'BAh7CDoJdXNlckkiEXN0YWZmX3N5c3RlbQY6BkVUOg9sb2dpbl90aW1lSXU6\nCVRpbWUNLYkfgHjidwoIOg1zdWJtaWNybyIGADoLb2Zmc2V0af7AxzoJem9u\nZUkiCEVEVAY7BlQ6DmV4cGlyYWJsZUY=\n'),(43,'6118b6c7deea3bf319ddfaa28a6416b24dedab57','2026-03-09 13:03:43',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+A7+mICgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(44,'89d9e691b03b0cfb90a57e16af3021c0ed3fb4df','2026-03-09 13:04:08',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+AQtNYDAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(45,'99833d5ec153a4e2809c9761f27359c67e8e5ae7','2026-03-10 12:41:11',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+ACDq3FAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(46,'dc991811b506370d01c6a5bc205f4d48ee1f8be6','2026-03-10 12:41:21',0,_binary 'BAh7CDoJdXNlckkiEXN0YWZmX3N5c3RlbQY6BkVUOg9sb2dpbl90aW1lSXU6\nCVRpbWUNLYkfgIgC7xQIOg1zdWJtaWNybyIGADoLb2Zmc2V0af7AxzoJem9u\nZUkiCEVEVAY7BlQ6DmV4cGlyYWJsZUY=\n'),(47,'8e0c03b422ec0c19b0295ce4550bd1b6292e3595','2026-03-10 12:41:06',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+AJ2gGFQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(48,'a120b39acbb298b3cab02acbbdb6df859bdc4c8d','2026-03-10 12:41:00',0,_binary 'BAh7CDoJdXNlckkiE3NlYXJjaF9pbmRleGVyBjoGRVQ6D2xvZ2luX3RpbWVJ\ndToJVGltZQ0tiR+AWcSWFgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6\nb25lSSIIRURUBjsGVDoOZXhwaXJhYmxlRg==\n'),(49,'90b3c1aed846197fbff52ecd9c31f892f170fa6d','2026-03-09 13:10:18',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0t\niR+ATtsjKQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(50,'779f4f3cc81c971f5760b04c63a10c08e306f38f','2026-03-09 13:24:46',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0t\niR+AepglKQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(51,'aee9649c2ba318721201afa7fc12a71d2b4c36c1','2026-03-09 13:26:43',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0t\niR+Asbm8agg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(52,'812c73aa75c015b5f4881b110516c96c1d5322b2','2026-03-09 13:26:47',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0t\niR+AtB6+agg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(53,'f3bf70e82d1286366d20a55936ed4c3a8acd641e','2026-03-09 13:33:12',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0t\niR+AUnnOhAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(54,'86e6deeb11062ea9e0886dc4666b0b861dcdae53','2026-03-09 13:33:18',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0t\niR+AStvQhAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(55,'910719abf6c26f1a85c52125e1a5d4f87caa7241','2026-03-09 19:52:23',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0z\niR+ANvEXHAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(56,'6ec17b72c76369f8104d81b71e274011e604d0fc','2026-03-09 19:12:41',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0z\niR+AYtKEMgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(57,'1cc11f09dcbd954c85593379133c71e386b504d7','2026-03-09 19:19:32',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0z\niR+A/tX4TQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(58,'be4f27081ea7b8716da9afc3a625183d93af608c','2026-03-09 19:57:24',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0z\niR+ATRHI3Ag6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(60,'b822f804569480fc187ab0c23c6cde5742350a6f','2026-03-09 19:57:54',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ0z\niR+AIoMh5wg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(61,'2ce08f6d15a82d389520951d5547457fedf2099e','2026-03-09 22:12:23',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ02\niR+A/JoyMQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(62,'22d0477e752d9479c88f6579db4b711e299f2308','2026-03-09 22:36:37',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ02\niR+ArKAskgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(63,'c324bdfe3c5470ad2f5e20de2e694b85672d71cd','2026-03-09 22:36:42',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ02\niR+Asok1kgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(64,'c4c37eb5f3d8b609923ff27c603c0770de8cbba0','2026-03-09 22:39:33',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ02\niR+AwVjcnQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(65,'3d4fa6c8d976cb68e2ad4961730815ffbef7d61f','2026-03-09 22:47:19',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ02\niR+ATJ47vQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(66,'44cd128bde274a86082ba41dcd0d5d022ee2f3b7','2026-03-09 23:00:07',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+AxxB/AAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(67,'6b4b24bc5cbc2c3abbeb3d13d5cbeebaed792316','2026-03-09 23:01:27',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+Aaq6YBQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(68,'ef1e7bea9704f1c9df97112f59c2e821fb1268cd','2026-03-09 23:03:57',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+AnWlTDwg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(69,'bdfc453bc31f9accb8f3a100a143dba6269a9bbf','2026-03-09 23:07:58',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+A92eIHwg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(70,'d863dcc4be42cc170bc5f62627c0f285926578ed','2026-03-09 23:11:23',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+AZTYwLQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(71,'7fef9686212a2be942d7ef63b2beb6f1abf87534','2026-03-09 23:13:19',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+AFE4YNQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(72,'214975494f2eace78b3bc75a0afe823a3da085eb','2026-03-09 23:13:34',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+A4DwKNgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(73,'f431d21704ace08fa2de6b72d30a54a104539c84','2026-03-09 23:15:09',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+ARPdRPAg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(74,'a57f6266c93df86f60324c259d62cc4182e68e6e','2026-03-09 23:17:50',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+Ay/7RRgg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(75,'080d2f1167a469036c04acd2acfe20ab583767cb','2026-03-09 23:18:35',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+AEUPlSQg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(76,'b7aea7aa0c40b784d05544ad3fe272b38582fd8a','2026-03-09 23:21:00',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+Aode5Uwg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(77,'a2f37f5ad1e9824f2152a8fb7185e5c3282401e6','2026-03-09 23:23:55',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+AazFUXwg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n'),(78,'6de4f43f1f5c92ce89d604afef9b268d3b5f5c8f','2026-03-09 23:24:51',0,_binary 'BAh7CDoJdXNlckkiCmFkbWluBjoGRVQ6D2xvZ2luX3RpbWVJdToJVGltZQ03\niR+A1gT1Ygg6DXN1Ym1pY3JvIgYAOgtvZmZzZXRp/sDHOgl6b25lSSIIRURU\nBjsGVDoOZXhwaXJhYmxlRg==\n');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spawned_rlshp`
--

DROP TABLE IF EXISTS `spawned_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spawned_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accession_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `spawned_rlshp_system_mtime_index` (`system_mtime`),
  KEY `spawned_rlshp_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `resource_id` (`resource_id`),
  CONSTRAINT `spawned_rlshp_ibfk_1` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `spawned_rlshp_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spawned_rlshp`
--

LOCK TABLES `spawned_rlshp` WRITE;
/*!40000 ALTER TABLE `spawned_rlshp` DISABLE KEYS */;
INSERT INTO `spawned_rlshp` VALUES (1,1,7,0,NULL,NULL,'2026-03-06 20:48:47','2026-03-06 20:48:47',0);
/*!40000 ALTER TABLE `spawned_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structured_date_label`
--

DROP TABLE IF EXISTS `structured_date_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structured_date_label` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_label_id` int NOT NULL,
  `date_certainty_id` int DEFAULT NULL,
  `date_era_id` int DEFAULT NULL,
  `date_calendar_id` int DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `name_person_id` int DEFAULT NULL,
  `name_family_id` int DEFAULT NULL,
  `name_corporate_entity_id` int DEFAULT NULL,
  `name_software_id` int DEFAULT NULL,
  `parallel_name_person_id` int DEFAULT NULL,
  `parallel_name_family_id` int DEFAULT NULL,
  `parallel_name_corporate_entity_id` int DEFAULT NULL,
  `parallel_name_software_id` int DEFAULT NULL,
  `related_agents_rlshp_id` int DEFAULT NULL,
  `agent_place_id` int DEFAULT NULL,
  `agent_occupation_id` int DEFAULT NULL,
  `agent_function_id` int DEFAULT NULL,
  `agent_topic_id` int DEFAULT NULL,
  `agent_gender_id` int DEFAULT NULL,
  `agent_resource_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  `date_type_structured` varchar(255) NOT NULL DEFAULT 'none',
  PRIMARY KEY (`id`),
  KEY `structured_date_label_system_mtime_index` (`system_mtime`),
  KEY `structured_date_label_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `structured_date_label_ibfk_1` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `structured_date_label_ibfk_2` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `structured_date_label_ibfk_3` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `structured_date_label_ibfk_4` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structured_date_label`
--

LOCK TABLES `structured_date_label` WRITE;
/*!40000 ALTER TABLE `structured_date_label` DISABLE KEYS */;
INSERT INTO `structured_date_label` VALUES (16,915,918,258,259,NULL,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'range'),(17,915,920,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'single'),(18,916,918,258,259,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'range'),(19,916,919,258,259,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'single'),(20,915,920,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'single'),(21,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'single'),(22,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0,'single'),(23,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',1,'range'),(24,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'range'),(25,915,920,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'single'),(26,916,918,258,259,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'range'),(27,916,919,258,259,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'single'),(28,915,920,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'single'),(29,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'single'),(30,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0,'single'),(31,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',1,'range'),(32,915,918,258,259,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'range'),(33,915,920,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'single'),(34,916,918,258,259,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'range'),(35,916,919,258,259,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'single'),(36,915,920,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'single'),(37,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'single'),(38,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0,'single'),(39,915,918,258,259,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',1,'range');
/*!40000 ALTER TABLE `structured_date_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structured_date_range`
--

DROP TABLE IF EXISTS `structured_date_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structured_date_range` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structured_date_label_id` int NOT NULL,
  `begin_date_expression` varchar(255) DEFAULT NULL,
  `begin_date_standardized` varchar(255) DEFAULT NULL,
  `begin_date_standardized_type_id` int NOT NULL DEFAULT '1769',
  `end_date_expression` varchar(255) DEFAULT NULL,
  `end_date_standardized` varchar(255) DEFAULT NULL,
  `end_date_standardized_type_id` int NOT NULL DEFAULT '1769',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `structured_date_range_system_mtime_index` (`system_mtime`),
  KEY `structured_date_range_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structured_date_range`
--

LOCK TABLES `structured_date_range` WRITE;
/*!40000 ALTER TABLE `structured_date_range` DISABLE KEYS */;
INSERT INTO `structured_date_range` VALUES (7,16,'1800','1800',1769,'1900','1900',1769,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(8,18,'1800','1800-01-01',1769,'1900','1900-12-31',1769,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(9,23,'1800','1800',1769,'1900','1900',1769,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(10,24,'1800','1800',1769,'1900','1900',1769,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(11,26,'1800','1800-01-01',1769,'1900','1900-12-31',1769,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(12,31,'1800','1800',1769,'1900','1900',1769,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(13,32,'1800','1800',1769,'1900','1900',1769,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(14,34,'1800','1800-01-01',1769,'1900','1900-12-31',1769,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(15,39,'1800','1800',1769,'1900','1900',1769,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `structured_date_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structured_date_single`
--

DROP TABLE IF EXISTS `structured_date_single`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structured_date_single` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structured_date_label_id` int NOT NULL,
  `date_role_id` int NOT NULL,
  `date_expression` varchar(255) DEFAULT NULL,
  `date_standardized` varchar(255) DEFAULT NULL,
  `date_standardized_type_id` int NOT NULL DEFAULT '1769',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `structured_date_single_system_mtime_index` (`system_mtime`),
  KEY `structured_date_single_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structured_date_single`
--

LOCK TABLES `structured_date_single` WRITE;
/*!40000 ALTER TABLE `structured_date_single` DISABLE KEYS */;
INSERT INTO `structured_date_single` VALUES (10,17,1767,'1900','1900',1769,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(11,19,1767,'1800','1800',1770,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(12,20,1767,'1800','1800',1769,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(13,21,1767,'1800','1800',1769,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(14,22,1767,'1800','1900',1769,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(15,25,1767,'1900','1900',1769,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(16,27,1767,'1800','1800',1770,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(17,28,1767,'1800','1800',1769,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(18,29,1767,'1800','1800',1769,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(19,30,1767,'1800','1900',1769,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(20,33,1767,'1900','1900',1769,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(21,35,1767,'1800','1800',1770,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(22,36,1767,'1800','1800',1769,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(23,37,1767,'1800','1800',1769,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0),(24,38,1767,'1800','1900',1769,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `structured_date_single` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_container`
--

DROP TABLE IF EXISTS `sub_container`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_container` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `instance_id` int DEFAULT NULL,
  `type_2_id` int DEFAULT NULL,
  `indicator_2` varchar(255) DEFAULT NULL,
  `type_3_id` int DEFAULT NULL,
  `indicator_3` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `barcode_2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type_2_id` (`type_2_id`),
  KEY `type_3_id` (`type_3_id`),
  KEY `sub_container_system_mtime_index` (`system_mtime`),
  KEY `sub_container_user_mtime_index` (`user_mtime`),
  KEY `instance_id` (`instance_id`),
  CONSTRAINT `sub_container_ibfk_1` FOREIGN KEY (`type_2_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `sub_container_ibfk_2` FOREIGN KEY (`type_3_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `sub_container_ibfk_3` FOREIGN KEY (`instance_id`) REFERENCES `instance` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_container`
--

LOCK TABLES `sub_container` WRITE;
/*!40000 ALTER TABLE `sub_container` DISABLE KEYS */;
INSERT INTO `sub_container` VALUES (2,0,1,3,320,'492',320,'902','admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47','139');
/*!40000 ALTER TABLE `sub_container` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `vocab_id` int NOT NULL,
  `title` varchar(8704) DEFAULT NULL,
  `terms_sha1` varchar(255) NOT NULL,
  `authority_id` varchar(255) DEFAULT NULL,
  `scope_note` text,
  `source_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `is_slug_auto` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `subj_auth_source_uniq` (`vocab_id`,`authority_id`,`source_id`),
  UNIQUE KEY `subj_terms_uniq` (`vocab_id`,`terms_sha1`,`source_id`),
  KEY `source_id` (`source_id`),
  KEY `subject_terms_sha1_index` (`terms_sha1`),
  KEY `subject_system_mtime_index` (`system_mtime`),
  KEY `subject_user_mtime_index` (`user_mtime`),
  CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`source_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `subject_ibfk_2` FOREIGN KEY (`vocab_id`) REFERENCES `vocabulary` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES (1,0,1,1,'uniform_title Term 1 -- uniform_title Term 2','c7f0a0f8b99c325d690c094f6758f9983e3a41cd','AuthID526','Scope Note',358,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',NULL,1),(2,1,1,1,'topical Term 1 -- topical Term 2','b740b34bd485592516f846247681f3e5e9f0d270','AuthID767','Scope Note',360,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:47','2026-03-06 20:48:41',NULL,1),(3,0,1,1,'temporal Term 1 -- temporal Term 2','2f056fe9ff7345fc7f692e1885a523bab0ab205c','AuthID27','Scope Note',361,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',NULL,1),(4,0,1,1,'technique Term 1 -- technique Term 2','25c8b6e2b782b2377d91799dde63ca18097a6e57','AuthID107','Scope Note',1696,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',NULL,1),(5,0,1,1,'style_period Term 1 -- style_period Term 2','5b27d4b174443438999de77fe0263c6b8991c65d','AuthID794','Scope Note',361,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41',NULL,1),(6,0,1,1,'occupation Term 1 -- occupation Term 2','3602c777343d3138ce0eb46808b5c357b47c7ecb','AuthID899','Scope Note',363,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:46','2026-03-06 20:48:41',NULL,1),(7,1,1,1,'geographic Term 1 -- geographic Term 2','9d9685717e402aa1249275f4e8704310aa936bcd','AuthID865','Scope Note',362,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:47','2026-03-06 20:48:41',NULL,1),(8,1,1,1,'genre_form Term 1 -- genre_form Term 2','295d719cee4709ea2773264f8a65abee96ce7f1e','AuthID52','Scope Note',361,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:47','2026-03-06 20:48:42',NULL,1),(9,0,1,1,'function Term 1 -- function Term 2','d7a3eb062bcaf9c49a211a54fec1992394641a75','AuthID389','Scope Note',357,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:46','2026-03-06 20:48:42',NULL,1),(10,0,1,1,'cultural_context Term 1 -- cultural_context Term 2','093387db288dd3268c96a0c47c332b6bf7e56dca','AuthID798','Scope Note',361,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42',NULL,1);
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_agent_subrecord_place_rlshp`
--

DROP TABLE IF EXISTS `subject_agent_subrecord_place_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject_agent_subrecord_place_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject_id` int DEFAULT NULL,
  `agent_function_id` int DEFAULT NULL,
  `agent_occupation_id` int DEFAULT NULL,
  `agent_resource_id` int DEFAULT NULL,
  `agent_topic_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_agent_subrecord_place_rlshp_system_mtime_index` (`system_mtime`),
  KEY `subject_agent_subrecord_place_rlshp_user_mtime_index` (`user_mtime`),
  KEY `subject_id` (`subject_id`),
  KEY `agent_function_id` (`agent_function_id`),
  KEY `agent_occupation_id` (`agent_occupation_id`),
  KEY `agent_topic_id` (`agent_topic_id`),
  CONSTRAINT `subject_agent_subrecord_place_rlshp_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `subject_agent_subrecord_place_rlshp_ibfk_2` FOREIGN KEY (`agent_function_id`) REFERENCES `agent_function` (`id`),
  CONSTRAINT `subject_agent_subrecord_place_rlshp_ibfk_3` FOREIGN KEY (`agent_occupation_id`) REFERENCES `agent_occupation` (`id`),
  CONSTRAINT `subject_agent_subrecord_place_rlshp_ibfk_4` FOREIGN KEY (`agent_topic_id`) REFERENCES `agent_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_agent_subrecord_place_rlshp`
--

LOCK TABLES `subject_agent_subrecord_place_rlshp` WRITE;
/*!40000 ALTER TABLE `subject_agent_subrecord_place_rlshp` DISABLE KEYS */;
INSERT INTO `subject_agent_subrecord_place_rlshp` VALUES (1,7,NULL,1,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:43','2026-03-06 20:48:43'),(2,7,1,NULL,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:43','2026-03-06 20:48:43'),(3,7,NULL,NULL,1,NULL,0,0,NULL,NULL,'2026-03-06 20:48:43','2026-03-06 20:48:43'),(4,7,NULL,2,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:45','2026-03-06 20:48:45'),(5,7,2,NULL,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:45','2026-03-06 20:48:45'),(6,7,NULL,NULL,3,NULL,0,0,NULL,NULL,'2026-03-06 20:48:45','2026-03-06 20:48:45'),(7,7,NULL,3,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:46','2026-03-06 20:48:46'),(8,7,3,NULL,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:46','2026-03-06 20:48:46'),(9,7,NULL,NULL,5,NULL,0,0,NULL,NULL,'2026-03-06 20:48:46','2026-03-06 20:48:46');
/*!40000 ALTER TABLE `subject_agent_subrecord_place_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_agent_subrecord_rlshp`
--

DROP TABLE IF EXISTS `subject_agent_subrecord_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject_agent_subrecord_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject_id` int DEFAULT NULL,
  `agent_function_id` int DEFAULT NULL,
  `agent_occupation_id` int DEFAULT NULL,
  `agent_place_id` int DEFAULT NULL,
  `agent_topic_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_agent_subrecord_rlshp_system_mtime_index` (`system_mtime`),
  KEY `subject_agent_subrecord_rlshp_user_mtime_index` (`user_mtime`),
  KEY `subject_id` (`subject_id`),
  KEY `agent_function_id` (`agent_function_id`),
  KEY `agent_occupation_id` (`agent_occupation_id`),
  KEY `agent_place_id` (`agent_place_id`),
  KEY `agent_topic_id` (`agent_topic_id`),
  CONSTRAINT `subject_agent_subrecord_rlshp_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `subject_agent_subrecord_rlshp_ibfk_2` FOREIGN KEY (`agent_function_id`) REFERENCES `agent_function` (`id`),
  CONSTRAINT `subject_agent_subrecord_rlshp_ibfk_3` FOREIGN KEY (`agent_occupation_id`) REFERENCES `agent_occupation` (`id`),
  CONSTRAINT `subject_agent_subrecord_rlshp_ibfk_4` FOREIGN KEY (`agent_place_id`) REFERENCES `agent_place` (`id`),
  CONSTRAINT `subject_agent_subrecord_rlshp_ibfk_5` FOREIGN KEY (`agent_topic_id`) REFERENCES `agent_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_agent_subrecord_rlshp`
--

LOCK TABLES `subject_agent_subrecord_rlshp` WRITE;
/*!40000 ALTER TABLE `subject_agent_subrecord_rlshp` DISABLE KEYS */;
INSERT INTO `subject_agent_subrecord_rlshp` VALUES (1,7,NULL,NULL,4,NULL,0,0,NULL,NULL,'2026-03-06 20:48:43','2026-03-06 20:48:43'),(2,6,NULL,1,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:43','2026-03-06 20:48:43'),(3,9,1,NULL,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:43','2026-03-06 20:48:43'),(4,2,NULL,NULL,NULL,1,0,0,NULL,NULL,'2026-03-06 20:48:43','2026-03-06 20:48:43'),(5,7,NULL,NULL,5,NULL,0,0,NULL,NULL,'2026-03-06 20:48:45','2026-03-06 20:48:45'),(6,6,NULL,2,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:45','2026-03-06 20:48:45'),(7,9,2,NULL,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:45','2026-03-06 20:48:45'),(8,2,NULL,NULL,NULL,2,0,0,NULL,NULL,'2026-03-06 20:48:45','2026-03-06 20:48:45'),(9,7,NULL,NULL,6,NULL,0,0,NULL,NULL,'2026-03-06 20:48:46','2026-03-06 20:48:46'),(10,6,NULL,3,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:46','2026-03-06 20:48:46'),(11,9,3,NULL,NULL,NULL,0,0,NULL,NULL,'2026-03-06 20:48:46','2026-03-06 20:48:46'),(12,2,NULL,NULL,NULL,3,0,0,NULL,NULL,'2026-03-06 20:48:46','2026-03-06 20:48:46');
/*!40000 ALTER TABLE `subject_agent_subrecord_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_rlshp`
--

DROP TABLE IF EXISTS `subject_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accession_id` int DEFAULT NULL,
  `archival_object_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `digital_object_component_id` int DEFAULT NULL,
  `subject_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `subject_rlshp_system_mtime_index` (`system_mtime`),
  KEY `subject_rlshp_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `archival_object_id` (`archival_object_id`),
  KEY `resource_id` (`resource_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `digital_object_component_id` (`digital_object_component_id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `subject_rlshp_ibfk_1` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `subject_rlshp_ibfk_2` FOREIGN KEY (`archival_object_id`) REFERENCES `archival_object` (`id`),
  CONSTRAINT `subject_rlshp_ibfk_3` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `subject_rlshp_ibfk_4` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `subject_rlshp_ibfk_5` FOREIGN KEY (`digital_object_component_id`) REFERENCES `digital_object_component` (`id`),
  CONSTRAINT `subject_rlshp_ibfk_6` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_rlshp`
--

LOCK TABLES `subject_rlshp` WRITE;
/*!40000 ALTER TABLE `subject_rlshp` DISABLE KEYS */;
INSERT INTO `subject_rlshp` VALUES (1,NULL,NULL,7,NULL,NULL,7,0,NULL,NULL,'2026-03-06 20:48:47','2026-03-06 20:48:47',0),(2,NULL,NULL,7,NULL,NULL,2,1,NULL,NULL,'2026-03-06 20:48:47','2026-03-06 20:48:47',0),(3,NULL,NULL,7,NULL,NULL,8,2,NULL,NULL,'2026-03-06 20:48:47','2026-03-06 20:48:47',0);
/*!40000 ALTER TABLE `subject_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_term`
--

DROP TABLE IF EXISTS `subject_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject_term` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject_id` int NOT NULL,
  `term_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `term_id` (`term_id`),
  KEY `subject_term_idx` (`subject_id`,`term_id`),
  CONSTRAINT `subject_term_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`),
  CONSTRAINT `subject_term_ibfk_2` FOREIGN KEY (`term_id`) REFERENCES `term` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_term`
--

LOCK TABLES `subject_term` WRITE;
/*!40000 ALTER TABLE `subject_term` DISABLE KEYS */;
INSERT INTO `subject_term` VALUES (1,1,1),(2,1,2),(3,2,3),(4,2,4),(5,3,5),(6,3,6),(7,4,7),(8,4,8),(9,5,9),(10,5,10),(11,6,11),(12,6,12),(13,7,13),(14,7,14),(15,8,15),(16,8,16),(17,9,17),(18,9,18),(19,10,19),(20,10,20);
/*!40000 ALTER TABLE `subject_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnote_metadata`
--

DROP TABLE IF EXISTS `subnote_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subnote_metadata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `note_id` int NOT NULL,
  `guid` varchar(255) NOT NULL,
  `publish` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `note_id` (`note_id`),
  CONSTRAINT `subnote_metadata_ibfk_1` FOREIGN KEY (`note_id`) REFERENCES `note` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnote_metadata`
--

LOCK TABLES `subnote_metadata` WRITE;
/*!40000 ALTER TABLE `subnote_metadata` DISABLE KEYS */;
INSERT INTO `subnote_metadata` VALUES (1,18,'4792a3bd8ccddf69338d5909db7e1be5',1),(2,19,'dccf89fb25264d78b4623df03cb7c56d',0),(3,19,'152e6d31854f2fa41e03cdbe07be9780',1),(4,19,'0a291c7063b4207a471c8caae16bb00d',1),(5,19,'60fde6abe68322f8cfa8815905797556',0),(6,19,'1bcea9a37a560d2dd3b9f852580e376b',0),(7,19,'84d459bd14509d87a1512123b041dbb9',0),(8,27,'243dbbe3a55305dfba71f44c3a621572',1),(9,28,'b2e5972e5edac2e8ae6b0bc2dc9ef600',0),(10,28,'96d0dc06331da8ba65b9434c9b8827ac',1),(11,28,'cf8a07535760e520c32bda745b937f3c',1),(12,28,'486092ad08cd525cd163f8c7c7ff9705',0),(13,28,'1ec9ae6197ff78f8fe1e5fb4fd72f760',0),(14,28,'7073cc1d097b83848b923ad7a0f13e30',0),(15,36,'3dfcd516114cdfafe88168cfd1428b1f',1),(16,37,'65beb2cbe643a0abdc25d16290463d44',0),(17,37,'073d0d473c2aa3d101cb7d3298497725',1),(18,37,'8e5e12e13244dee466dbc2b86e6e73ec',1),(19,37,'1bf028663adfd05e74f6a9aad0a84711',0),(20,37,'f26a274b8633b73c5be7cc81c6adbd2a',0),(21,37,'7c51df64bb6e32e2882b63e5e6891fa6',0),(22,43,'800d6cf862bc89efcb68ee9dcf451ff9',1),(23,43,'77640904a86ac7a34b44c634934381f5',1),(24,44,'d5feb39d054e4428429238894f219705',1),(25,44,'650d6feb04af4d15a50af27710dc9e3a',0),(26,45,'5dd98b9654d174a7f8b88a4f63e439e4',0),(27,45,'0eded7bb9ef3fffb461aa2b339629cec',1),(28,47,'233fa29f877afc4fc42bafbe263af7e7',1),(29,47,'8521be2a5a82e8142770b1280ce56cb3',0),(30,48,'9a9f84b4b06c6ade3764d5a98cb88f21',1),(31,48,'628c15f4ea49107e76ebb76bdcc69c17',0),(32,49,'8e0844f8628abd9b35f0870e1e4026e4',0),(33,50,'96b37b40e199df27a9bd567bfce74510',0),(34,51,'1e396fcaf9aaf5ff0765079a7b08e65b',0),(35,52,'4de1a842bc8207e92b122647542cbf2f',1),(36,53,'23d1418f3eacc0c696374d681abcaa8e',0),(37,54,'ea4273b8b018fc43c8f392d5856e93bd',0),(38,55,'5d736f9895d2a23f0b4a8a880c74330a',0),(39,56,'33bdc5da27c73b5a80115b78558ae430',1),(40,57,'642b9f80a7b031774ae8c7b5dfed52f0',0),(41,58,'0d07d9c682d15528514b2d0f591635de',0),(42,58,'53d2e38f5383c33acbc0f2dc029b1c0f',0),(43,59,'3a906c916279c7cdf2cac60e500d5f3b',0),(44,61,'a7c4b1329824723b4af36bfb79c9a7a3',0),(45,62,'b060e8bab772cdeb7f0bbc42fe85d0cb',0),(46,66,'bd4746c265254dbf51cc919b8fc8067e',0),(47,67,'8808c5a14882568ecbdac6b7e704b5f5',1),(48,68,'b3b717cb14cae170d52808fc9d9744d8',0),(49,69,'e51202bd726e688d2959e1ab46d6abb4',1),(50,70,'d5e61d57ab23a622897465997285e525',0);
/*!40000 ALTER TABLE `subnote_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveyed_by_rlshp`
--

DROP TABLE IF EXISTS `surveyed_by_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyed_by_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assessment_id` int NOT NULL,
  `agent_person_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `surveyed_by_rlshp_system_mtime_index` (`system_mtime`),
  KEY `surveyed_by_rlshp_user_mtime_index` (`user_mtime`),
  KEY `assessment_id` (`assessment_id`),
  KEY `agent_person_id` (`agent_person_id`),
  CONSTRAINT `surveyed_by_rlshp_ibfk_1` FOREIGN KEY (`assessment_id`) REFERENCES `assessment` (`id`),
  CONSTRAINT `surveyed_by_rlshp_ibfk_2` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyed_by_rlshp`
--

LOCK TABLES `surveyed_by_rlshp` WRITE;
/*!40000 ALTER TABLE `surveyed_by_rlshp` DISABLE KEYS */;
INSERT INTO `surveyed_by_rlshp` VALUES (1,1,1,0,0,NULL,NULL,'2026-02-27 23:18:09','2026-02-27 23:18:09');
/*!40000 ALTER TABLE `surveyed_by_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_event`
--

DROP TABLE IF EXISTS `system_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_event` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `time` datetime NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_event_time_index` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_event`
--

LOCK TABLES `system_event` WRITE;
/*!40000 ALTER TABLE `system_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telephone`
--

DROP TABLE IF EXISTS `telephone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telephone` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_contact_id` int DEFAULT NULL,
  `number` text NOT NULL,
  `ext` text,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `number_type_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telephone_system_mtime_index` (`system_mtime`),
  KEY `telephone_user_mtime_index` (`user_mtime`),
  KEY `agent_contact_id` (`agent_contact_id`),
  KEY `number_type_id` (`number_type_id`),
  CONSTRAINT `telephone_ibfk_1` FOREIGN KEY (`agent_contact_id`) REFERENCES `agent_contact` (`id`),
  CONSTRAINT `telephone_ibfk_2` FOREIGN KEY (`number_type_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telephone`
--

LOCK TABLES `telephone` WRITE;
/*!40000 ALTER TABLE `telephone` DISABLE KEYS */;
INSERT INTO `telephone` VALUES (4,5,'555-555-5555','555','admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',1336),(5,6,'555-555-5555','555','admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',1336),(6,7,'555-555-5555','555','admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',1336);
/*!40000 ALTER TABLE `telephone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `term`
--

DROP TABLE IF EXISTS `term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `term` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `vocab_id` int NOT NULL,
  `term` varchar(255) NOT NULL,
  `term_type_id` int NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_vocab_id_term_term_type_id_index` (`vocab_id`,`term`,`term_type_id`),
  KEY `term_type_id` (`term_type_id`),
  KEY `term_system_mtime_index` (`system_mtime`),
  KEY `term_user_mtime_index` (`user_mtime`),
  CONSTRAINT `term_ibfk_1` FOREIGN KEY (`term_type_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `term_ibfk_2` FOREIGN KEY (`vocab_id`) REFERENCES `vocabulary` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `term`
--

LOCK TABLES `term` WRITE;
/*!40000 ALTER TABLE `term` DISABLE KEYS */;
INSERT INTO `term` VALUES (1,0,1,1,'uniform_title Term 1',1276,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(2,0,1,1,'uniform_title Term 2',1276,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(3,0,1,1,'topical Term 1',1275,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(4,0,1,1,'topical Term 2',1275,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(5,0,1,1,'temporal Term 1',1274,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(6,0,1,1,'temporal Term 2',1274,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(7,0,1,1,'technique Term 1',1273,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(8,0,1,1,'technique Term 2',1273,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(9,0,1,1,'style_period Term 1',1272,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(10,0,1,1,'style_period Term 2',1272,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(11,0,1,1,'occupation Term 1',1271,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(12,0,1,1,'occupation Term 2',1271,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(13,0,1,1,'geographic Term 1',1269,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(14,0,1,1,'geographic Term 2',1269,'admin','admin','2026-03-06 20:48:41','2026-03-06 20:48:41','2026-03-06 20:48:41'),(15,0,1,1,'genre_form Term 1',1270,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42'),(16,0,1,1,'genre_form Term 2',1270,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42'),(17,0,1,1,'function Term 1',1268,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42'),(18,0,1,1,'function Term 2',1268,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42'),(19,0,1,1,'cultural_context Term 1',1267,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42'),(20,0,1,1,'cultural_context Term 2',1267,'admin','admin','2026-03-06 20:48:42','2026-03-06 20:48:42','2026-03-06 20:48:42'),(21,0,1,1,'Term 1',1268,'admin','admin','2026-03-06 20:48:47','2026-03-06 20:48:47','2026-03-06 20:48:47');
/*!40000 ALTER TABLE `term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `top_container`
--

DROP TABLE IF EXISTS `top_container`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `top_container` (
  `id` int NOT NULL AUTO_INCREMENT,
  `repo_id` int NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `barcode` varchar(255) DEFAULT NULL,
  `ils_holding_id` varchar(255) DEFAULT NULL,
  `ils_item_id` varchar(255) DEFAULT NULL,
  `exported_to_ils` datetime DEFAULT NULL,
  `indicator` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `type_id` int DEFAULT NULL,
  `created_for_collection` varchar(255) DEFAULT NULL,
  `internal_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `top_container_uniq_barcode` (`repo_id`,`barcode`),
  KEY `top_container_indicator_index` (`indicator`),
  KEY `top_container_system_mtime_index` (`system_mtime`),
  KEY `top_container_user_mtime_index` (`user_mtime`),
  KEY `top_container_type_fk` (`type_id`),
  CONSTRAINT `top_container_type_fk` FOREIGN KEY (`type_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top_container`
--

LOCK TABLES `top_container` WRITE;
/*!40000 ALTER TABLE `top_container` DISABLE KEYS */;
INSERT INTO `top_container` VALUES (1,2,1,1,'835','570',NULL,NULL,'596','admin','admin','2026-02-27 23:18:08','2026-03-06 20:48:47','2026-02-27 23:18:08',319,NULL,'Internal Note');
/*!40000 ALTER TABLE `top_container` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `top_container_housed_at_rlshp`
--

DROP TABLE IF EXISTS `top_container_housed_at_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `top_container_housed_at_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `top_container_id` int DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `jsonmodel_type` varchar(255) NOT NULL DEFAULT 'container_location',
  `status` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `top_container_housed_at_rlshp_system_mtime_index` (`system_mtime`),
  KEY `top_container_housed_at_rlshp_user_mtime_index` (`user_mtime`),
  KEY `top_container_id` (`top_container_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `top_container_housed_at_rlshp_ibfk_1` FOREIGN KEY (`top_container_id`) REFERENCES `top_container` (`id`),
  CONSTRAINT `top_container_housed_at_rlshp_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top_container_housed_at_rlshp`
--

LOCK TABLES `top_container_housed_at_rlshp` WRITE;
/*!40000 ALTER TABLE `top_container_housed_at_rlshp` DISABLE KEYS */;
INSERT INTO `top_container_housed_at_rlshp` VALUES (1,1,2,0,0,'container_location','current','2025-08-13','2025-08-15','Note',NULL,NULL,'2026-02-27 23:18:08','2026-02-27 23:18:08');
/*!40000 ALTER TABLE `top_container_housed_at_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `top_container_link_rlshp`
--

DROP TABLE IF EXISTS `top_container_link_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `top_container_link_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `top_container_id` int DEFAULT NULL,
  `sub_container_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `top_container_link_rlshp_system_mtime_index` (`system_mtime`),
  KEY `top_container_link_rlshp_user_mtime_index` (`user_mtime`),
  KEY `top_container_id` (`top_container_id`),
  KEY `sub_container_id` (`sub_container_id`),
  CONSTRAINT `top_container_link_rlshp_ibfk_1` FOREIGN KEY (`top_container_id`) REFERENCES `top_container` (`id`),
  CONSTRAINT `top_container_link_rlshp_ibfk_2` FOREIGN KEY (`sub_container_id`) REFERENCES `sub_container` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top_container_link_rlshp`
--

LOCK TABLES `top_container_link_rlshp` WRITE;
/*!40000 ALTER TABLE `top_container_link_rlshp` DISABLE KEYS */;
INSERT INTO `top_container_link_rlshp` VALUES (2,1,2,0,0,NULL,NULL,'2026-03-06 20:48:47','2026-03-06 20:48:47');
/*!40000 ALTER TABLE `top_container_link_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `top_container_profile_rlshp`
--

DROP TABLE IF EXISTS `top_container_profile_rlshp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `top_container_profile_rlshp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `top_container_id` int DEFAULT NULL,
  `container_profile_id` int DEFAULT NULL,
  `aspace_relationship_position` int DEFAULT NULL,
  `suppressed` int NOT NULL DEFAULT '0',
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `top_container_profile_rlshp_system_mtime_index` (`system_mtime`),
  KEY `top_container_profile_rlshp_user_mtime_index` (`user_mtime`),
  KEY `top_container_id` (`top_container_id`),
  KEY `container_profile_id` (`container_profile_id`),
  CONSTRAINT `top_container_profile_rlshp_ibfk_1` FOREIGN KEY (`top_container_id`) REFERENCES `top_container` (`id`),
  CONSTRAINT `top_container_profile_rlshp_ibfk_2` FOREIGN KEY (`container_profile_id`) REFERENCES `container_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top_container_profile_rlshp`
--

LOCK TABLES `top_container_profile_rlshp` WRITE;
/*!40000 ALTER TABLE `top_container_profile_rlshp` DISABLE KEYS */;
INSERT INTO `top_container_profile_rlshp` VALUES (1,1,5,0,0,NULL,NULL,'2026-02-27 23:18:08','2026-02-27 23:18:08');
/*!40000 ALTER TABLE `top_container_profile_rlshp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `used_language`
--

DROP TABLE IF EXISTS `used_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `used_language` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language_id` int DEFAULT NULL,
  `script_id` int DEFAULT NULL,
  `agent_person_id` int DEFAULT NULL,
  `agent_family_id` int DEFAULT NULL,
  `agent_corporate_entity_id` int DEFAULT NULL,
  `agent_software_id` int DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `lock_version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `language_id` (`language_id`),
  KEY `script_id` (`script_id`),
  KEY `used_language_system_mtime_index` (`system_mtime`),
  KEY `used_language_user_mtime_index` (`user_mtime`),
  KEY `agent_person_id` (`agent_person_id`),
  KEY `agent_family_id` (`agent_family_id`),
  KEY `agent_corporate_entity_id` (`agent_corporate_entity_id`),
  KEY `agent_software_id` (`agent_software_id`),
  CONSTRAINT `used_language_ibfk_1` FOREIGN KEY (`language_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `used_language_ibfk_2` FOREIGN KEY (`script_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `used_language_ibfk_3` FOREIGN KEY (`agent_person_id`) REFERENCES `agent_person` (`id`),
  CONSTRAINT `used_language_ibfk_4` FOREIGN KEY (`agent_family_id`) REFERENCES `agent_family` (`id`),
  CONSTRAINT `used_language_ibfk_5` FOREIGN KEY (`agent_corporate_entity_id`) REFERENCES `agent_corporate_entity` (`id`),
  CONSTRAINT `used_language_ibfk_6` FOREIGN KEY (`agent_software_id`) REFERENCES `agent_software` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `used_language`
--

LOCK TABLES `used_language` WRITE;
/*!40000 ALTER TABLE `used_language` DISABLE KEYS */;
INSERT INTO `used_language` VALUES (1,515,1582,3,NULL,NULL,NULL,'admin','admin','2026-03-06 20:48:43','2026-03-06 20:48:43','2026-03-06 20:48:43',0),(2,515,1582,NULL,NULL,3,NULL,'admin','admin','2026-03-06 20:48:45','2026-03-06 20:48:45','2026-03-06 20:48:45',0),(3,515,1582,NULL,2,NULL,NULL,'admin','admin','2026-03-06 20:48:46','2026-03-06 20:48:46','2026-03-06 20:48:46',0);
/*!40000 ALTER TABLE `used_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `source` varchar(255) DEFAULT NULL,
  `agent_record_id` int DEFAULT NULL,
  `agent_record_type` varchar(255) DEFAULT NULL,
  `is_system_user` int NOT NULL DEFAULT '0',
  `is_hidden_user` int NOT NULL DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `additional_contact` text,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `is_active_user` int DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `user_system_mtime_index` (`system_mtime`),
  KEY `user_user_mtime_index` (`user_mtime`),
  KEY `agent_record_id` (`agent_record_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`agent_record_id`) REFERENCES `agent_person` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,59,1,'admin','Administrator','DBAuth',1,'agent_person',1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-27 23:17:23','2026-03-09 23:24:47','2026-03-09 23:24:47',1),(2,15,1,'search_indexer','Search Indexer','DBAuth',NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-27 23:17:24','2026-03-09 13:05:41','2026-03-09 13:05:41',1),(3,0,1,'public_anonymous','Public Interface Anonymous','local',NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-27 23:17:24','2026-02-27 23:17:24','2026-02-27 23:17:24',1),(4,4,1,'staff_system','Staff System User','DBAuth',NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-27 23:17:24','2026-03-09 13:05:14','2026-03-09 13:05:14',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_defined`
--

DROP TABLE IF EXISTS `user_defined`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_defined` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `json_schema_version` int NOT NULL,
  `accession_id` int DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `digital_object_id` int DEFAULT NULL,
  `boolean_1` int DEFAULT NULL,
  `boolean_2` int DEFAULT NULL,
  `boolean_3` int DEFAULT NULL,
  `integer_1` varchar(255) DEFAULT NULL,
  `integer_2` varchar(255) DEFAULT NULL,
  `integer_3` varchar(255) DEFAULT NULL,
  `real_1` varchar(255) DEFAULT NULL,
  `real_2` varchar(255) DEFAULT NULL,
  `real_3` varchar(255) DEFAULT NULL,
  `string_1` varchar(255) DEFAULT NULL,
  `string_2` varchar(255) DEFAULT NULL,
  `string_3` varchar(255) DEFAULT NULL,
  `string_4` varchar(255) DEFAULT NULL,
  `text_1` text,
  `text_2` text,
  `text_3` text,
  `text_4` text,
  `text_5` text,
  `date_1` date DEFAULT NULL,
  `date_2` date DEFAULT NULL,
  `date_3` date DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  `enum_1_id` int DEFAULT NULL,
  `enum_2_id` int DEFAULT NULL,
  `enum_3_id` int DEFAULT NULL,
  `enum_4_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_defined_system_mtime_index` (`system_mtime`),
  KEY `user_defined_user_mtime_index` (`user_mtime`),
  KEY `accession_id` (`accession_id`),
  KEY `resource_id` (`resource_id`),
  KEY `digital_object_id` (`digital_object_id`),
  KEY `enum_1_id` (`enum_1_id`),
  KEY `enum_2_id` (`enum_2_id`),
  KEY `enum_3_id` (`enum_3_id`),
  KEY `enum_4_id` (`enum_4_id`),
  CONSTRAINT `user_defined_ibfk_1` FOREIGN KEY (`accession_id`) REFERENCES `accession` (`id`),
  CONSTRAINT `user_defined_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `user_defined_ibfk_3` FOREIGN KEY (`digital_object_id`) REFERENCES `digital_object` (`id`),
  CONSTRAINT `user_defined_ibfk_4` FOREIGN KEY (`enum_1_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `user_defined_ibfk_5` FOREIGN KEY (`enum_2_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `user_defined_ibfk_6` FOREIGN KEY (`enum_3_id`) REFERENCES `enumeration_value` (`id`),
  CONSTRAINT `user_defined_ibfk_7` FOREIGN KEY (`enum_4_id`) REFERENCES `enumeration_value` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_defined`
--

LOCK TABLES `user_defined` WRITE;
/*!40000 ALTER TABLE `user_defined` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_defined` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulary`
--

DROP TABLE IF EXISTS `vocabulary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vocabulary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lock_version` int NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `ref_id` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `system_mtime` datetime NOT NULL,
  `user_mtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `ref_id` (`ref_id`),
  KEY `vocabulary_system_mtime_index` (`system_mtime`),
  KEY `vocabulary_user_mtime_index` (`user_mtime`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulary`
--

LOCK TABLES `vocabulary` WRITE;
/*!40000 ALTER TABLE `vocabulary` DISABLE KEYS */;
INSERT INTO `vocabulary` VALUES (1,0,'global','global',NULL,NULL,'2026-02-27 23:16:38','2026-02-27 23:16:51','2026-02-27 23:16:38');
/*!40000 ALTER TABLE `vocabulary` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-10  8:41:21
